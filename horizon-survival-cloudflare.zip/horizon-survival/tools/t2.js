const E = s => 'HZeval(' + JSON.stringify(s) + ')';
module.exports = async (p) => {
  const ev = async s => { const r = await p.eval(E(s)); return r; };
  await ev('startGame(true)'); await p.sleep(1500);
  await p.shot('10_spawn_high');
  // знайти найближчий дуб, дати сокиру, стати поруч і дивитись на стовбур
  console.log(await ev(`(function(){ var best=null,bd=1e9; TREES.forEach(function(tr){ if(tr.kind!=='oak')return; var d=Math.hypot(tr.x-P.x,tr.z-P.z); if(d<bd){bd=d;best=tr;} }); window._tr=best;
    addItem('axe',1); inv.sel=findSlot('axe'); refreshUI();
    P.x=best.x+2.0; P.z=best.z+0.3; P.y=H(P.x,P.z); P.yaw=Math.atan2(-(best.x-P.x),-(best.z-P.z)); P.pitch=-0.12;
    return JSON.stringify({kind:best.kind,x:best.x,z:best.z}); })()`));
  await p.sleep(400);
  console.log('target', await ev('JSON.stringify(ACT.cur && {l:ACT.cur.label, ok:ACT.cur.ok, dur:ACT.cur.dur})'));
  await ev('INP.held=true; INP.pressed=true'); await p.sleep(1300); await p.shot('11_chopping');
  await p.sleep(5000); console.log('after hits', await ev('JSON.stringify({st:_tr.st, hits:_tr.hits, need:TREE_INFO[_tr.kind].hits})'));
  await p.sleep(1000); await p.shot('12_falling');
  await ev('INP.held=false'); await p.sleep(2500); await p.shot('13_fallen');
  console.log('fallen', await ev('JSON.stringify({st:_tr.st, tilt:_tr.it.tilt})'));
  // розрубати стовбур
  await ev(`P.yaw=Math.atan2(-(_tr.inter.x-P.x),-(_tr.inter.z-P.z)); P.pitch=-0.35;`); await p.sleep(300);
  console.log('proc target', await ev('JSON.stringify(ACT.cur && {l:ACT.cur.label, ok:ACT.cur.ok})'));
  await ev('INP.held=true; INP.pressed=true'); await p.sleep(4500); await ev('INP.held=false');
  console.log('processed', await ev('JSON.stringify({st:_tr.st, logs:countItem("log"), sticks:countItem("stick"), trees:STATS.trees})'));
  await p.shot('14_after_process');
};
module.exports.opts = { w: 1280, h: 720, load: 7000 };
