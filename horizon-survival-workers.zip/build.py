#!/usr/bin/env python3
"""Збирає гру в один файл public/index.html і оновлює версію кешу в public/sw.js.
Запуск: python3 build.py"""
import os, hashlib
ROOT = os.path.dirname(os.path.abspath(__file__))
S = os.path.join(ROOT, 'src')
ORDER = ['00_core.js', '01_i18n_uk.js', '01_i18n_en.js', '01_i18n_ru.js', '02_state.js', '03_gl.js', '04_geo.js', '05_icons_base.js',
         '05_audio.js', '06_items.js', '07_world.js', '08_fx_life.js', '09_player.js', '10_survival.js', '11_story.js', '12_ai.js', '13_ui.js', '14_main.js']
rd = lambda f: open(os.path.join(S, f), encoding='utf8').read()
js = '\n'.join(rd(f) for f in ORDER)
open(os.path.join(ROOT, 'all.js'), 'w', encoding='utf8').write(js)
html = rd('head.html') + js + rd('tail.html')
os.makedirs(os.path.join(ROOT, 'public'), exist_ok=True)
open(os.path.join(ROOT, 'public', 'index.html'), 'w', encoding='utf8').write(html)
ver = hashlib.sha1(html.encode('utf8')).hexdigest()[:10]
open(os.path.join(ROOT, 'public', 'sw.js'), 'w', encoding='utf8').write(rd('sw.tpl.js').replace('__VER__', ver))
print('built', len(html), 'bytes, cache version', ver)
