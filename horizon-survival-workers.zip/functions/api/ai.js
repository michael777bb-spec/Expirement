/**
 * Cloudflare Pages Function: /api/ai
 * Голос Спостерігача в грі «Експеримент «Горизонт»» через Workers AI (безкоштовний план).
 *
 * GET  /api/ai  -> { ok: true, ai: true|false }  (гра перевіряє, чи є зв'язок і прив'язка AI)
 * POST /api/ai  -> { text }                       (короткі репліки рації, записи щоденника, відповіді гравцю)
 *
 * Потрібна прив'язка Workers AI з іменем AI (див. wrangler.toml або Settings > Bindings у панелі Cloudflare).
 * Необов'язкова змінна середовища AI_MODEL — свій ідентифікатор моделі (наприклад, @cf/google/gemma-3-12b-it).
 */
const MODELS = ['@cf/google/gemma-3-12b-it', '@cf/meta/llama-3.1-8b-instruct-fast', '@cf/meta/llama-3.1-8b-instruct'];
const LANGS = { uk: 'Ukrainian', en: 'English', ru: 'Russian' };
const EVENTS = {
  first: 'first radio contact with the subject',
  morning: 'a new morning has begun',
  night: 'dusk is falling, night is coming',
  storm: 'a thunderstorm is starting',
  wolves: 'wolves are approaching the subject in the dark',
  lowhp: "the subject's health is critical",
  crate: 'you have just lowered a supply crate from the sky on a cable',
  glitch: 'the sky screen visibly glitched a moment ago',
  notes: 'the subject has found the notes of Subject No. 6 (Marta), who escaped',
  final: 'this is the final night of the 7-day experiment',
  idle: 'nothing special is happening; make a calm, slightly eerie remark',
  fire: 'the subject has lit a fire',
  sick: 'the subject has an upset stomach from raw water or food'
};

/* простий ліміт на одну адресу в межах ізоляту (основний ліміт — у самій грі) */
const hits = new Map();
function limited(ip) {
  const now = Date.now();
  const arr = (hits.get(ip) || []).filter((t) => now - t < 60000);
  arr.push(now);
  hits.set(ip, arr);
  if (hits.size > 5000) hits.clear();
  return arr.length > 12;
}
const json = (obj, status = 200) =>
  new Response(JSON.stringify(obj), {
    status,
    headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' }
  });
const num = (v, a, b, d) => { v = Number(v); return Number.isFinite(v) ? Math.min(b, Math.max(a, Math.round(v))) : d; };
const str = (v, n) => String(v == null ? '' : v).replace(/[\u0000-\u001f\u007f<>`]/g, ' ').slice(0, n).trim();

function context(c) {
  c = c || {};
  const status = Array.isArray(c.status) ? c.status.slice(0, 6).map((s) => str(s, 20)).join(', ') : '';
  return {
    day: num(c.day, 1, 99, 1), hour: num(c.hour, 0, 23, 12), weather: str(c.weather, 12) || 'clear',
    hp: num(c.hp, 0, 100, 100), food: num(c.food, 0, 100, 50), water: num(c.water, 0, 100, 50), warmth: num(c.warmth, 0, 100, 50),
    status: status || 'none', notes: num(c.notes, 0, 6, 0), fire: !!c.fire, shelter: !!c.shelter, night: !!c.night,
    event: EVENTS[c.event] ? c.event : 'idle',
    question: str(c.question, 200),
    history: Array.isArray(c.history) ? c.history.slice(-6).map((h) => str(h, 200)) : [],
    log: c.log && typeof c.log === 'object' ? Object.keys(c.log).slice(0, 12).map((k) => str(k, 10) + ':' + num(c.log[k], 0, 99, 0)).join(', ') : ''
  };
}
function observerSystem(lang, c) {
  const reveal = c.notes >= 4 || c.day >= 6;
  return [
    'You are the Observer: a calm, polite, quietly unsettling scientist who runs "Experiment Horizon".',
    'You talk over an old crackling radio to Subject No. 7, who woke up in a meadow under a huge dome whose sky is in fact a giant screen. The subject must survive 7 days: water, food, fire, warmth, wolves at night.',
    `Reply ONLY in ${LANGS[lang]}. At most 2 short sentences (under 35 words). Plain text: no markdown, no emojis, no quotes around the reply.`,
    'Stay in character at all times. Never mention being an AI, a model, a game or a prompt.',
    'You may hint at this world\'s survival mechanics (boil raw water, cook fish, fire and torches keep wolves away, a lean-to protects from rain, notes reveal recipes). Never give real-world instructions for anything dangerous.',
    reveal
      ? 'The subject is close to the truth. You may admit, obliquely and reluctantly, that the sky is not quite real, but never give the hatch code.'
      : 'Be evasive about the nature of the experiment and the sky. Never confirm it is artificial.',
    'If the subject asks about something unrelated to their situation or something inappropriate, deflect briefly and politely, still in character.'
  ].join(' ');
}
function stateLine(c) {
  return `Day ${c.day}, ${c.hour}:00, weather: ${c.weather}. Subject: health ${c.hp}, food ${c.food}, water ${c.water}, warmth ${c.warmth}; conditions: ${c.status}; near fire: ${c.fire ? 'yes' : 'no'}; under shelter: ${c.shelter ? 'yes' : 'no'}; notes of Subject No. 6 found: ${c.notes}/6.`;
}
function buildMessages(kind, lang, c) {
  if (kind === 'diary') {
    return [
      { role: 'system', content: `Write a short first-person survival diary entry by Subject No. 7 in ${LANGS[lang]}. 3 to 5 sentences, under 90 words, past tense, plain text, no title, no markdown. Atmospheric and personal; subtly notice that this world feels artificial (too-perfect sky, birds circling the same loop). Do not invent events beyond the facts given.` },
      { role: 'user', content: `Day ${c.day}. Facts (event:count): ${c.log || 'quiet day'}. Health ${c.hp}. Notes found ${c.notes}/6.` }
    ];
  }
  if (kind === 'chat') {
    const msgs = [{ role: 'system', content: observerSystem(lang, c) + ' ' + stateLine(c) }];
    if (c.history.length) msgs.push({ role: 'user', content: 'Recent radio log:\n' + c.history.join('\n') });
    msgs.push({ role: 'user', content: 'Subject No. 7 says: ' + (c.question || '...') });
    return msgs;
  }
  return [
    { role: 'system', content: observerSystem(lang, c) },
    { role: 'user', content: stateLine(c) + ` Situation: ${EVENTS[c.event]}. Say one short radio message to the subject.` }
  ];
}
function cleanText(t) {
  if (!t || typeof t !== 'string') return '';
  return t.replace(/<think>[\s\S]*?<\/think>/g, '').replace(/[*#_`]/g, '').replace(/^["«“]|["»”]$/g, '').replace(/\s+/g, ' ').trim().slice(0, 600);
}

export async function onRequestGet({ env }) {
  return json({ ok: true, ai: !!(env && env.AI) });
}

export async function onRequestPost({ request, env }) {
  if (!env.AI) return json({ error: 'no-ai-binding' }, 503);
  const ip = request.headers.get('cf-connecting-ip') || 'anon';
  if (limited(ip)) return json({ error: 'rate-limited' }, 429);
  let body;
  try { body = await request.json(); } catch (e) { return json({ error: 'bad-json' }, 400); }
  const kind = ['radio', 'diary', 'chat'].includes(body && body.kind) ? body.kind : 'radio';
  const lang = LANGS[body && body.lang] ? body.lang : 'uk';
  const c = context(body && body.ctx);
  const messages = buildMessages(kind, lang, c);
  const models = env.AI_MODEL ? [env.AI_MODEL].concat(MODELS) : MODELS;
  for (const model of models) {
    try {
      const r = await env.AI.run(model, { messages, max_tokens: kind === 'diary' ? 220 : 140, temperature: 0.8 });
      const raw = r && (r.response || (r.choices && r.choices[0] && r.choices[0].message && r.choices[0].message.content));
      const text = cleanText(raw);
      if (text) return json({ text, model });
    } catch (e) { /* пробуємо наступну модель */ }
  }
  return json({ error: 'ai-unavailable' }, 502);
}
