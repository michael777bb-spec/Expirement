// Мінімальний драйвер Chrome DevTools Protocol (без залежностей)
const { spawn } = require('child_process'); const http = require('http'); const fs = require('fs');
const PORT = 9333 + Math.floor(Math.random() * 300);
function getJSON(url) { return new Promise((res, rej) => { http.get(url, r => { let d = ''; r.on('data', c => d += c); r.on('end', () => { try { res(JSON.parse(d)); } catch (e) { rej(e); } }); }).on('error', rej); }); }
const sleep = ms => new Promise(r => setTimeout(r, ms));
async function run(url, script, opts = {}) {
  const w = opts.w || 1280, h = opts.h || 720;
  const args = ['--headless=new', '--no-sandbox', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist', '--remote-debugging-port=' + PORT, '--window-size=' + w + ',' + h, '--autoplay-policy=no-user-gesture-required', '--user-data-dir=/tmp/hzprof' + PORT, 'about:blank'];
  const ch = spawn('google-chrome', args, { stdio: 'ignore' });
  let tabs; for (let i = 0; i < 50; i++) { try { tabs = await getJSON('http://127.0.0.1:' + PORT + '/json'); if (tabs.length) break; } catch (e) { } await sleep(200); }
  const tab = tabs.find(t => t.type === 'page');
  const ws = new WebSocket(tab.webSocketDebuggerUrl); await new Promise(r => ws.onopen = r);
  let id = 0; const pend = {}; const logs = [];
  ws.onmessage = ev => { const m = JSON.parse(ev.data); if (m.id && pend[m.id]) { pend[m.id](m); delete pend[m.id]; }
    if (m.method === 'Runtime.consoleAPICalled') logs.push('[' + m.params.type + '] ' + m.params.args.map(a => a.value !== undefined ? a.value : (a.description || a.type)).join(' '));
    if (m.method === 'Runtime.exceptionThrown') logs.push('[EXC] ' + (m.params.exceptionDetails.exception ? m.params.exceptionDetails.exception.description : m.params.exceptionDetails.text));
    if (m.method === 'Log.entryAdded' && m.params.entry.level === 'error') logs.push('[LOG] ' + m.params.entry.text + ' ' + (m.params.entry.url || '')); };
  const send = (method, params = {}) => new Promise(r => { const i = ++id; pend[i] = r; ws.send(JSON.stringify({ id: i, method, params })); });
  await send('Runtime.enable'); await send('Log.enable'); await send('Page.enable');
  if (opts.mobile) await send('Emulation.setDeviceMetricsOverride', { width: w, height: h, deviceScaleFactor: 2, mobile: true }), await send('Emulation.setTouchEmulationEnabled', { enabled: true, maxTouchPoints: 5 });
  else await send('Emulation.setDeviceMetricsOverride', { width: w, height: h, deviceScaleFactor: 1, mobile: false });
  await send('Page.navigate', { url }); await sleep(opts.load || 4000);
  const page = {
    logs, send, sleep,
    eval: async (expr) => { const r = await send('Runtime.evaluate', { expression: expr, returnByValue: true, awaitPromise: true }); if (r.result.exceptionDetails) return 'EXC: ' + (r.result.exceptionDetails.exception ? r.result.exceptionDetails.exception.description : r.result.exceptionDetails.text); return r.result.result.value; },
    shot: async (name) => { const r = await send('Page.captureScreenshot', { format: 'png' }); fs.mkdirSync('shots', { recursive: true }); fs.writeFileSync(require('path').join('shots', name + '.png'), Buffer.from(r.result.data, 'base64')); },
    key: async (code, type) => { await send('Input.dispatchKeyEvent', { type: type || 'keyDown', code, key: code.replace('Key', '').toLowerCase(), windowsVirtualKeyCode: code.startsWith('Key') ? code.charCodeAt(3) : 0 }); },
    click: async (x, y, button = 'left') => { await send('Input.dispatchMouseEvent', { type: 'mousePressed', x, y, button, clickCount: 1 }); await send('Input.dispatchMouseEvent', { type: 'mouseReleased', x, y, button, clickCount: 1 }); },
    tap: async (x, y) => { await send('Input.dispatchTouchEvent', { type: 'touchStart', touchPoints: [{ x, y }] }); await sleep(60); await send('Input.dispatchTouchEvent', { type: 'touchEnd', touchPoints: [] }); }
  };
  try { await script(page); } catch (e) { console.log('SCRIPT ERROR', e.stack); }
  console.log('--- console (' + logs.length + ') ---'); logs.slice(0, 40).forEach(l => console.log(l));
  ws.close(); ch.kill('SIGKILL');
}
module.exports = { run, sleep };
if (require.main === module) { const s = require(require('path').resolve(process.argv[2])); run(process.argv[3] || 'http://127.0.0.1:8765/index.html', s, s.opts || {}).then(() => process.exit(0)); }
