// Локальний сервер: роздає public/ і викликає справжню функцію functions/api/ai.js з імітацією env.AI
import http from 'node:http'; import fs from 'node:fs'; import path from 'node:path';
import * as fn from '../functions/api/ai.js';
const ROOT = path.resolve('public'); const calls = [];
const env = { AI: { run: async (model, inp) => { calls.push({ model, inp }); if (model.includes('gemma')) throw new Error('simulated failure'); const sys = inp.messages[0].content; const lang = /Ukrainian/.test(sys) ? 'uk' : /Russian/.test(sys) ? 'ru' : 'en'; return { response: `**[MOCK ${lang} ${model.split('/').pop()}]** ` + (inp.messages[inp.messages.length - 1].content.slice(0, 60)) }; } } };
const types = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.png': 'image/png', '.svg': 'image/svg+xml', '.webmanifest': 'application/manifest+json' };
http.createServer(async (req, res) => {
  const u = new URL(req.url, 'http://localhost');
  if (u.pathname === '/api/ai') {
    const body = await new Promise(r => { let d = ''; req.on('data', c => d += c); req.on('end', () => r(d)); });
    const request = new Request('http://localhost/api/ai', { method: req.method, headers: { 'content-type': 'application/json', 'cf-connecting-ip': '1.2.3.4' }, body: req.method === 'POST' ? body : undefined });
    const r = req.method === 'POST' ? await fn.onRequestPost({ request, env }) : await fn.onRequestGet({ env });
    res.writeHead(r.status, { 'content-type': 'application/json' }); res.end(await r.text()); return;
  }
  if (u.pathname === '/__calls') { res.writeHead(200, { 'content-type': 'application/json' }); res.end(JSON.stringify(calls.map(c => ({ model: c.model, sys: c.inp.messages[0].content.slice(0, 120), last: c.inp.messages[c.inp.messages.length - 1].content.slice(0, 200), max: c.inp.max_tokens })))); return; }
  let f = path.join(ROOT, u.pathname === '/' ? 'index.html' : u.pathname);
  if (!f.startsWith(ROOT) || !fs.existsSync(f)) { res.writeHead(404); res.end('nf'); return; }
  res.writeHead(200, { 'content-type': types[path.extname(f)] || 'application/octet-stream' }); fs.createReadStream(f).pipe(res);
}).listen(8790, () => console.log('mock on 8790'));
