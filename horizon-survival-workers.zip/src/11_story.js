/* =====================================================================
   СЮЖЕТ: цілі, записки, рюкзак із рацією, ящик з неба, люк, події, фінали
   ===================================================================== */
var GOALS = [
  { id: 'water', ok: function () { return G.flags.drank; } },
  { id: 'gather', ok: function () { return G.flags.gathered || (hasItem('stick') && hasItem('stone') && hasItem('fiber') && (G.flags.gathered = 1)); } },
  { id: 'sharp', ok: function () { return G.flags.c_sharp || hasItem('sharp'); } },
  { id: 'axe', ok: function () { return G.flags.c_axe; } },
  { id: 'tree', ok: function () { return STATS.trees > 0; } },
  { id: 'firelay', ok: function () { return G.flags.firelay; } },
  { id: 'fire', ok: function () { return G.flags.fire; } },
  { id: 'night1', ok: function () { return G.tot >= 1440 + 6 * 60; } },
  { id: 'camp', ok: function () { return G.notes[2]; } },
  { id: 'can', ok: function () { return G.flags.c_can; } },
  { id: 'boil', ok: function () { return G.flags.boiled; } },
  { id: 'food', ok: function () { return G.flags.cookedMeat; } },
  { id: 'shelter', ok: function () { return G.flags.shelter; } },
  { id: 'spear', ok: function () { return G.flags.c_spear; } },
  { id: 'notes', ok: function () { return notesCount() >= 6; } },
  { id: 'hatch', ok: function () { return S.won === 'escape'; }, show: function () { return notesCount() >= 4 || G.notes[6]; } },
  { id: 'days', ok: function () { return G.tot >= 7 * 1440 + 6 * 60; } }
];
function notesCount() { var n = 0; for (var k in G.notes) if (G.notes[k]) n++; return n; }
function goalText(g) { return g.id === 'notes' ? t('g.notes', { n: notesCount() }) : t('g.' + g.id); }
function currentGoal() { for (var i = 0; i < GOALS.length; i++) { var g = GOALS[i]; if (g.show && !g.show()) continue; if (!g.ok()) return g; } return null; }

/* ---------- підказки (один раз за гру) ---------- */
var tipQ = [];
function tip(id) { if (!SET.hints || G.flags['tip_' + id]) return; G.flags['tip_' + id] = 1; tipQ.push(id); }

/* ---------- записки ---------- */
var NOTE_RECIPES = { 1: [], 2: ['drill', 'firelay', 'kit', 'torch'], 3: ['axe', 'spear'], 4: ['rod', 'can'], 5: ['bandage', 'snare', 'bedroll'], 6: [] };
function noteText(n) { return t('note.' + n, { c: n >= 2 && n <= 5 ? G.code.charAt(n - 2) : '' }); }
function readNote(o) {
  var n = o.n, first = !G.notes[n];
  G.notes[n] = true; AU.open();
  if (first) {
    var got = NOTE_RECIPES[n].filter(function (r) { return !G.known[r]; });
    got.forEach(function (r) { G.known[r] = 1; });
    if (n !== 1 && o.item) { showInst(o.item, false); removeInter(o); }
    if (n === 4) AU.splash(0.05);
    setTimeout(function () { toast(t('msg.note', { n: notesCount() }), 'note', 'good'); }, 200);
    got.forEach(function (r, i) { setTimeout(function () { toast(t('msg.recipe', { x: iname(RECIPES.filter(function (q) { return q.id === r; })[0].out[0]) }), 'book', 'good'); }, 900 + i * 700); });
    logDay('note'); if (notesCount() === 2) obsEvent('notes'); tip('note');
    if (notesCount() >= 3) SKY.hatch = Math.max(SKY.hatch, 0.2);
  }
  openOv('note', n);
}
function storyAction(o, h) {
  switch (o.kind) {
    case 'note': return { label: o.bottle && !G.notes[4] ? t('act.bottle') : t(o.n === 1 ? 'act.read' : 'act.note'), icon: 'note', dur: 0, ok: true, fn: function () { readNote(o); } };
    case 'bag': return G.flags.bag ? { label: t('msg.empty'), icon: 'bag', ok: false } : { label: t('act.bag'), icon: 'bag', dur: 0.9, ok: true, fn: openBag };
    case 'crate': return CRATE.st === 'land' && !CRATE.open ? { label: t('act.crate'), icon: 'bag', dur: 1, ok: true, fn: openCrate } : null;
    case 'hatch': return { label: t('act.hatch'), icon: 'keypad', dur: 0, ok: true, fn: function () { if (SKY.hatch < 0.15 && notesCount() < 6) { toast(t('msg.hatchHidden'), 'info'); SKY.glitch = 0.6; G.glitchT = 0.3; AU.glitch(); } else openOv('hatch'); } };
  }
  return null;
}
function openBag() {
  if (!canAdd('radio', 1) || !canAdd('rope', 1)) { toast(t('msg.full'), 'bag', 'bad'); return; }
  addItem('radio', 1); addItem('rope', 1); addItem('sharp', 1); G.flags.bag = 1; G.flags.radio = 1;
  toast(t('msg.bagItems'), 'bag', 'good'); AU.radio(); setTimeout(function () { toast(t('msg.radio'), 'radio'); obsEvent('first', true); tip('radio'); }, 2500);
}
/* ---------- ящик з неба (день 4) ---------- */
var CRATE = { st: 'none', x: 0, y: 0, z: 0, t: 0, open: false };
function crateDrop() {
  var a = P.yaw, x, z, k = 0;
  do { x = P.x - Math.sin(a) * rnd(7, 11) + rnd(-3, 3); z = P.z - Math.cos(a) * rnd(7, 11) + rnd(-3, 3); k++; } while ((blocked(x, z) || inPond(x, z, 1.5) || nearTree(x, z, 2)) && k < 40);
  CRATE.st = 'fall'; CRATE.x = clamp(x, 4, X1 - 4); CRATE.z = clamp(z, -ZLIM + 2, ZLIM - 2); CRATE.y = 22; CRATE.t = 0; CRATE.gy = H(CRATE.x, CRATE.z);
  SKY.glitch = 0.5; G.glitchT = 1.2; AU.motor(); AU.glitch(); toast(t('msg.crate'), 'bag'); logDay('crate');
}
function crateStep(dt) {
  if (CRATE.st === 'fall') {
    CRATE.t += dt; CRATE.y = Math.max(CRATE.gy, 22 - CRATE.t * 2.6);
    var it = STORY_OBJ.crate; it.hid = false; it.x = CRATE.x; it.z = CRATE.z; it.y = CRATE.y; it.ry = CRATE.t * 0.15; writeInst(it);
    lineAdd([CRATE.x, CRATE.y + 0.64, CRATE.z], [CRATE.x, 28, CRATE.z], [0.6, 0.6, 0.62, 0.8]);
    if (CRATE.y <= CRATE.gy) { CRATE.st = 'land'; AU.thud(); PRE.dust(CRATE.x, CRATE.gy + 0.1, CRATE.z, 10); addCol(CRATE.x, CRATE.z, 0.6); var I = STORY_OBJ.crateI; I.x = CRATE.x; I.z = CRATE.z; I.y = CRATE.gy + 0.6; I.on = true; obsEvent('crate'); }
  }
}
function openCrate() {
  var list = [['matches', 1], ['bandage', 2], ['ration', 2], ['can_empty', 1]];
  for (var i = 0; i < list.length; i++) if (!canAdd(list[i][0], list[i][1])) { toast(t('msg.full'), 'bag', 'bad'); return; }
  list.forEach(function (e) { addItem(e[0], e[1]); }); CRATE.open = true; STORY_OBJ.crateI.on = false; AU.open(); toast(t('msg.crateItems'), 'bag', 'good');
}
/* ---------- люк із кодом ---------- */
var KEY = { s: '' };
function keypadPress(d) {
  if (d === 'c') { KEY.s = ''; AU.click(); renderHatch(); return; }
  if (KEY.s.length >= 4) return; KEY.s += d; AU.beep(+d); renderHatch();
  if (KEY.s.length === 4) setTimeout(function () {
    if (KEY.s === G.code) { AU.win(); toast(t('msg.hatchOpen'), 'keypad', 'good'); closeOv(); SKY.glitch = 1; G.glitchT = 1.5; setTimeout(function () { endGame('escape'); }, 1600); }
    else { AU.error(); SKY.glitch = 0.7; G.glitchT = 0.3; toast(t('msg.code_bad'), 'keypad', 'bad'); KEY.s = ''; renderHatch(); }
  }, 350);
}

/* ---------- Спостерігач (рація) ---------- */
var OBS_VAR = { morning: ['obs.morning', 'obs.morning2'], night: ['obs.night', 'obs.night2'], idle: ['obs.idle1', 'obs.idle2', 'obs.idle3', 'obs.idle4'] };
var obsLastAny = -1e9;
function obsEvent(kind, force) {
  if (!G.flags.radio) return;
  var day = dayOf(), key = kind + '@' + day;
  if (!force && (G.obsLast[key] || G.t - obsLastAny < 75)) return;
  G.obsLast[key] = 1; obsLastAny = G.t;
  var fallback = t(OBS_VAR[kind] ? OBS_VAR[kind][Math.floor(Math.random() * OBS_VAR[kind].length)] : 'obs.' + kind);
  AU.radio();
  aiAsk('radio', { event: kind }, function (txt) { radioSay(txt || fallback, !!txt); });
}
function radioSay(text, ai) {
  G.radio.push({ w: 'obs', t: text, d: dayOf(), h: fmtT(G.tot) }); if (G.radio.length > 60) G.radio.shift();
  subtitle(t('radio.obs') + ': ' + text, 7);
  if (UI.ov === 'journal' && UI.arg === 'radio') renderJournal();
}
/* ---------- щоденник дня ---------- */
function logDay(k) { G.dayLog[k] = (G.dayLog[k] || 0) + 1; }
function writeDiary() {
  var d = Math.max(1, dayOf() - (hourOf() < 12 ? 1 : 0)), L = G.dayLog, ctx = { day: d, log: L, hp: Math.round(S.hp), notes: notesCount() };
  var fb = [];
  if (L.tree) fb.push(t('dy.trees', { n: L.tree })); if (L.fish) fb.push(t('dy.fish', { n: L.fish })); if (L.note) fb.push(t('dy.notes'));
  if (L.wolf) fb.push(t('dy.wolf')); if (L.storm) fb.push(t('dy.storm')); else if (L.rain) fb.push(t('dy.rain'));
  if (L.sick) fb.push(t('dy.sick')); if (L.crate) fb.push(t('dy.crate')); if (L.sky) fb.push(t('dy.sky'));
  if (L.cold) fb.push(t('dy.cold')); else if (G.flags.fire) fb.push(t('dy.fire'));
  if (fb.length < 2) fb.push(t('dy.calm')); fb.push(t('dy.end'));
  var entry = { d: d, t: fb.join(' '), ai: false }; G.diary.push(entry); G.dayLog = {};
  aiAsk('diary', ctx, function (txt) { if (txt) { entry.t = txt; entry.ai = true; if (UI.ov === 'journal') renderJournal(); } });
}

/* ---------- події за розкладом ---------- */
var storyT = 0, glitchNext = 90, idleNext = 400, wolfNext = 0;
function storyStep(dt) {
  var h = hourOf(), day = dayOf(), E = G.events;
  // світанок і сутінки
  var dk = day + ':' + (h >= 5.6 && h < 12 ? 'dawn' : h >= 19.4 && h < 23 ? 'dusk' : '');
  if (h >= 5.6 && h < 6.5 && !E['dawn' + day] && day > 1) { E['dawn' + day] = 1; toast(t('msg.dawn', { d: day }), 'sun', 'good'); obsEvent('morning'); }
  if (h >= 19.4 && h < 21 && !E['dusk' + day]) { E['dusk' + day] = 1; toast(t('msg.dusk'), 'moon'); tip('night'); obsEvent(day >= 7 ? 'final' : 'night'); }
  // вовки вночі
  if (ENV.dayK < 0.2 && !S.ended) {
    var want = Math.min(3, day >= 6 ? 3 : day >= 3 ? 2 : 1);
    var alive = WOLVES.filter(function (w) { return !w.dead && w.st !== 'leave'; }).length;
    wolfNext -= dt;
    if (alive < want && wolfNext <= 0) { spawnWolf(); wolfNext = rnd(50, 110); if (!E['howl' + day]) { E['howl' + day] = 1; AU.howl(); toast(t('msg.howl'), 'wolf'); tip('wolf'); if (day >= 2) obsEvent('wolves'); } else if (Math.random() < 0.5) AU.howl(); }
  }
  // збої неба
  glitchNext -= dt;
  if (glitchNext <= 0 && !S.ended) { glitchNext = rnd(Math.max(35, 150 - day * 18), Math.max(70, 260 - day * 25)); if (day >= 2) { SKY.glitch = rnd(0.3, 0.6) + day * 0.05; G.glitchT = rnd(0.15, 0.4); AU.glitch(); if (!E['gl' + day]) { E['gl' + day] = 1; logDay('sky'); if (day >= 3) obsEvent('glitch'); } } }
  if (G.glitchT > 0) { G.glitchT -= dt; if (G.glitchT <= 0) SKY.glitch = 0; }
  // ящик на 4-й день
  if (day >= 4 && (day > 4 || h >= 10) && !E.crate) { E.crate = 1; crateDrop(); }
  crateStep(dt);
  // люк видно краще з записками; під час збою — яскравіше
  var hv = notesCount() >= 6 ? 1 : notesCount() >= 3 ? 0.25 : 0; hv = Math.max(hv, SKY.glitch > 0.2 && notesCount() >= 2 ? 0.8 : 0); if (day >= 7 && notesCount() >= 4) hv = Math.max(hv, 0.6);
  SKY.hatch = lerp(SKY.hatch, hv, Math.min(1, dt * 2));
  // фоновий Спостерігач
  idleNext -= dt; if (idleNext <= 0) { idleNext = rnd(360, 560); if (G.flags.radio) obsEvent('idle'); }
  // фінал: ранок восьмого дня
  if (G.tot >= 7 * 1440 + 6 * 60 && !S.won && !S.ended) { S.won = 'survive'; SKY.offT = 0.01; AU.glitch(); }
  if (SKY.offT) { SKY.offT += dt; SKY.off = clamp(SKY.offT / 6, 0, 1); if (SKY.offT > 7 && !S.ended) endGame('win'); }
}

/* ---------- фінали ---------- */
function endGame(kind) {
  if (S.ended) return; S.ended = true; FISH.st = 'none'; INP.held = false;
  var day = Math.min(8, dayOf()), ic = kind === 'dead' ? 'skull' : 'sun';
  if (kind === 'escape') S.won = 'escape';
  $('endIcon').innerHTML = svgI(ic);
  $('endTitle').textContent = t(kind === 'dead' ? 'end.dead' : kind === 'escape' ? 'end.escape' : 'end.win');
  $('endText').textContent = kind === 'dead' ? t('end.c.' + (['food', 'water', 'cold', 'wolf', 'bleed', 'poison'].indexOf(S.lastCause) >= 0 ? S.lastCause : 'other')) : t(kind === 'escape' ? 'end.escapeText' : 'end.winText');
  $('endStats').textContent = t('end.stats', { d: day, t: STATS.trees, f: STATS.fish, n: notesCount() });
  $('btnLive').classList.toggle('hide', kind !== 'win'); $('btnLoad').classList.toggle('hide', kind !== 'dead' || !store.get(SAVE_KEY, null));
  if (kind === 'dead') { AU.death(); } else { AU.win(); }
  if (kind !== 'dead') store.del(SAVE_KEY);
  setTimeout(function () { openOv('end'); }, kind === 'dead' ? 900 : 300);
}
