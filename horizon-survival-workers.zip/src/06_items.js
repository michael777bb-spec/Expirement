/* =====================================================================
   ПРЕДМЕТИ, РЕЦЕПТИ, ІНВЕНТАР
   ===================================================================== */
(function () {
  var add = {
    bark: '<path d="M4 6c3-1.5 13-1.5 16 0v12c-3 1.5-13 1.5-16 0z" fill="#ece8dc"/><path d="M7 9h4M13 12h4M6 14h3M11 16h5" stroke="#2b2b28" stroke-width="1.4" stroke-linecap="round"/>',
    can_empty: '<path d="M5 7h14l-1.4 12.5a2 2 0 01-2 1.5H8.4a2 2 0 01-2-1.5z" fill="#ece8dc"/><path d="M5 7h14" stroke="#9c958a" stroke-width="2"/><path d="M8 11h3M13 14h3" stroke="#2b2b28" stroke-width="1.3" stroke-linecap="round"/>',
    can_raw: '<path d="M5 7h14l-1.4 12.5a2 2 0 01-2 1.5H8.4a2 2 0 01-2-1.5z" fill="#ece8dc"/><path d="M6 10h12l-.9 8.8a1.4 1.4 0 01-1.4 1.2H8.3a1.4 1.4 0 01-1.4-1.2z" fill="#6f9a8a"/><circle cx="10" cy="14" r="1" fill="#3e6050"/><circle cx="14" cy="16" r=".8" fill="#3e6050"/>',
    can_boil: '<path d="M5 9h14l-1.4 10.5a2 2 0 01-2 1.5H8.4a2 2 0 01-2-1.5z" fill="#ece8dc"/><path d="M6 12h12l-.9 6.8a1.4 1.4 0 01-1.4 1.2H8.3a1.4 1.4 0 01-1.4-1.2z" fill="#5fb1ff"/><path d="M9 7c-1-1.5 1-2.5 0-4M13 7c-1-1.5 1-2.5 0-4M17 7c-1-1.5 1-2.5 0-4" stroke="#cfe3f0" stroke-width="1.4" fill="none" stroke-linecap="round"/>',
    can_tea: '<path d="M5 9h14l-1.4 10.5a2 2 0 01-2 1.5H8.4a2 2 0 01-2-1.5z" fill="#ece8dc"/><path d="M6 12h12l-.9 6.8a1.4 1.4 0 01-1.4 1.2H8.3a1.4 1.4 0 01-1.4-1.2z" fill="#d9a83a"/><circle cx="12" cy="15.5" r="2" fill="#fff"/><circle cx="12" cy="15.5" r=".9" fill="#f2c200"/><path d="M10 7c-1-1.5 1-2.5 0-4M14 7c-1-1.5 1-2.5 0-4" stroke="#cfe3f0" stroke-width="1.4" fill="none" stroke-linecap="round"/>',
    bandage: '<rect x="3" y="8" width="18" height="8" rx="4" fill="#f1ede2"/><path d="M8 8v8M16 8v8" stroke="#cfc8b8" stroke-width="1.2"/><path d="M12 10v4M10 12h4" stroke="#d64545" stroke-width="2" stroke-linecap="round"/>',
    drill: '<path d="M6 4v16" stroke="#8a5a2b" stroke-width="2.6" stroke-linecap="round"/><path d="M4 7c6 3 10 3 16-2" stroke="#8a5a2b" stroke-width="2.2" fill="none" stroke-linecap="round"/><path d="M4.5 7.5C10 12 14 12 19.5 5.5" stroke="#d8c08a" stroke-width="1" fill="none"/><rect x="3" y="18" width="12" height="3" rx="1" fill="#6b431e"/>',
    matches: '<rect x="4" y="9" width="16" height="9" rx="1.5" fill="#d8b04a"/><rect x="4" y="9" width="16" height="3" fill="#b8902a"/><path d="M8 9V4M11 9V3.5M14 9V4" stroke="#e6cd9a" stroke-width="1.4"/><circle cx="8" cy="4" r="1.2" fill="#c0392b"/><circle cx="11" cy="3.5" r="1.2" fill="#c0392b"/><circle cx="14" cy="4" r="1.2" fill="#c0392b"/>',
    firelay: '<path d="M4 20l8-15 8 15" stroke="#8a5a2b" stroke-width="2.4" fill="none" stroke-linecap="round"/><path d="M8 20l4-9 4 9" stroke="#b98a52" stroke-width="2" fill="none" stroke-linecap="round"/><ellipse cx="12" cy="20" rx="8" ry="1.6" fill="#8f979e"/>',
    kit: '<path d="M3 20L12 6l9 14" stroke="#6b431e" stroke-width="2.4" fill="none" stroke-linecap="round"/><path d="M6 20l6-9 6 9z" fill="#4f7a2a"/><path d="M12 6l-2 2.5M12 6l2 2.5" stroke="#c9a46a" stroke-width="1.6" stroke-linecap="round"/>',
    snare: '<path d="M5 20V9M19 20V9M4 9h16" stroke="#8a5a2b" stroke-width="2.2" stroke-linecap="round"/><circle cx="12" cy="14" r="4" fill="none" stroke="#c9a46a" stroke-width="1.8"/><path d="M12 9v1" stroke="#c9a46a" stroke-width="1.8"/>',
    meat: '<path d="M14.5 3.5c3.5 0 6 2.6 6 6 0 4.5-4.5 8.8-9.5 9.5L7 20.5a2.2 2.2 0 01-3-3l1.5-4C6.2 8.4 10 3.5 14.5 3.5z" fill="#c9433f"/><path d="M14 7.5c2 .2 3 1.4 3 3" stroke="#f0a8a0" stroke-width="1.6" fill="none" stroke-linecap="round"/><circle cx="5.3" cy="18.7" r="2" fill="#f1e3c8"/>',
    meat_c: '<path d="M14.5 3.5c3.5 0 6 2.6 6 6 0 4.5-4.5 8.8-9.5 9.5L7 20.5a2.2 2.2 0 01-3-3l1.5-4C6.2 8.4 10 3.5 14.5 3.5z" fill="#8a4a1e"/><path d="M11 8l5 5M9.5 11l4 4M13 6.5l4 4" stroke="#5a2e10" stroke-width="1.3" stroke-linecap="round"/><circle cx="5.3" cy="18.7" r="2" fill="#f1e3c8"/>',
    amanita: '<path d="M3 12.5a9 8 0 0118 0z" fill="#d42a1e"/><rect x="9" y="12.5" width="6" height="8" rx="2.5" fill="#f6f2ea"/><circle cx="8" cy="9.5" r="1.3" fill="#fff"/><circle cx="13" cy="7.5" r="1.1" fill="#fff"/><circle cx="16.5" cy="10.5" r="1" fill="#fff"/><circle cx="11" cy="11" r=".8" fill="#fff"/>',
    plantain: '<path d="M12 21c-4-3-6-8-4-15 3 4 5 9 4 15z" fill="#3f8a2a"/><path d="M12 21c4-3 6-8 4-15-3 4-5 9-4 15z" fill="#4fa23a"/><path d="M12 21V8" stroke="#9fd07a" stroke-width="1" stroke-linecap="round"/>',
    chamomile: '<g fill="#fff"><ellipse cx="12" cy="5.5" rx="2" ry="3.2"/><ellipse cx="12" cy="18.5" rx="2" ry="3.2"/><ellipse cx="5.5" cy="12" rx="3.2" ry="2"/><ellipse cx="18.5" cy="12" rx="3.2" ry="2"/><ellipse cx="7.4" cy="7.4" rx="2" ry="3.2" transform="rotate(-45 7.4 7.4)"/><ellipse cx="16.6" cy="16.6" rx="2" ry="3.2" transform="rotate(-45 16.6 16.6)"/><ellipse cx="16.6" cy="7.4" rx="2" ry="3.2" transform="rotate(45 16.6 7.4)"/><ellipse cx="7.4" cy="16.6" rx="2" ry="3.2" transform="rotate(45 7.4 16.6)"/></g><circle cx="12" cy="12" r="3.3" fill="#f2c200"/>',
    charcoal: '<path d="M4 16l3-8 7-3 6 5-2 8-8 2z" fill="#222"/><path d="M7 8l7-3 1 6z" fill="#3a3a3a"/><path d="M9 14l3 1" stroke="#555" stroke-width="1"/>',
    ration: '<rect x="3" y="7" width="18" height="11" rx="2" fill="#5d6b3a"/><rect x="3" y="7" width="18" height="3.5" rx="1.5" fill="#4a5630"/><rect x="8" y="12" width="8" height="4" rx="1" fill="#e9e3c8"/>',
    rotten: '<path d="M12 8c-3-2-7 0-7 5 0 4 3 8 5 8 1 0 1.5-.5 2-.5s1 .5 2 .5c2 0 5-4 5-8 0-5-4-7-7-5z" fill="#6b6a3a"/><circle cx="9" cy="13" r="1.4" fill="#3a3a1a"/><circle cx="14" cy="16" r="1" fill="#3a3a1a"/><path d="M8 5c1-1 2 0 3-1M14 4c1 1 2 0 3 1" stroke="#9aa04a" stroke-width="1.2" fill="none" stroke-linecap="round"/>',
    radio: '<rect x="4" y="8" width="16" height="12" rx="2" fill="#3a4038"/><circle cx="9" cy="14" r="3" fill="#20241f"/><circle cx="9" cy="14" r="1.2" fill="#5a6458"/><rect x="13.5" y="11" width="4.5" height="2" rx=".5" fill="#9fd07a"/><path d="M15 8l4-6" stroke="#20241f" stroke-width="1.6" stroke-linecap="round"/>',
    /* стани та інтерфейс */
    bleed: '<path d="M12 2c4.2 5.2 7 8.8 7 12.4a7 7 0 01-14 0C5 10.8 7.8 7.2 12 2z" fill="#c62828"/><path d="M8.5 14.4a3.6 3.6 0 003.1 3.6" stroke="#ff9a9a" stroke-width="1.6" fill="none" stroke-linecap="round"/>',
    sick: '<circle cx="12" cy="12" r="9" fill="#9bbf3a"/><circle cx="9" cy="10" r="1.3" fill="#2f3a10"/><circle cx="15" cy="10" r="1.3" fill="#2f3a10"/><path d="M8 16c2.5-2 5.5-2 8 0" stroke="#2f3a10" stroke-width="1.6" fill="none" stroke-linecap="round"/>',
    poison: '<path d="M12 3a8 8 0 00-8 8c0 2.6 1.2 4.4 3 5.6V20h3v-2h4v2h3v-3.4c1.8-1.2 3-3 3-5.6a8 8 0 00-8-8z" fill="#8e44ad"/><circle cx="8.8" cy="11.2" r="2" fill="#2a1035"/><circle cx="15.2" cy="11.2" r="2" fill="#2a1035"/>',
    wet: '<path d="M7 3c2.2 2.8 3.6 4.6 3.6 6.5a3.6 3.6 0 01-7.2 0C3.4 7.6 4.8 5.8 7 3zM16 8c2.8 3.4 4.6 5.8 4.6 8.2a4.6 4.6 0 01-9.2 0c0-2.4 1.8-4.8 4.6-8.2z" fill="#4fa3ff"/>',
    cold: '<path d="M12 2v20M3.3 7l17.4 10M3.3 17L20.7 7" stroke="#9fd4ff" stroke-width="2" stroke-linecap="round"/><path d="M9 3.5l3 2 3-2M9 20.5l3-2 3 2" stroke="#9fd4ff" stroke-width="1.6" fill="none" stroke-linecap="round"/>',
    tired: '<path d="M20 14.5A8.5 8.5 0 119.5 4a7 7 0 0010.5 10.5z" fill="#9a8cff"/><path d="M14 6h4l-4 4h4" stroke="#fff" stroke-width="1.4" fill="none" stroke-linecap="round" stroke-linejoin="round"/>',
    book: '<path d="M4 4.5h6.5a2.5 2.5 0 012.5 2.5V20a2 2 0 00-2-2H4z" fill="#c9a46a"/><path d="M20 4.5h-6.5A2.5 2.5 0 0011 7v13a2 2 0 012-2h7z" fill="#e6cd9a"/><path d="M6.5 8h3.5M6.5 11h3.5M14 8h3.5M14 11h3.5" stroke="#7a5a2a" stroke-width="1.2" stroke-linecap="round"/>',
    gear: '<path d="M12 8.5a3.5 3.5 0 100 7 3.5 3.5 0 000-7z" fill="none" stroke="currentColor" stroke-width="2"/><path d="M12 2.5v3M12 18.5v3M2.5 12h3M18.5 12h3M5.3 5.3l2.1 2.1M16.6 16.6l2.1 2.1M18.7 5.3l-2.1 2.1M7.4 16.6l-2.1 2.1" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/>',
    pause: '<rect x="6" y="5" width="4" height="14" rx="1.2" fill="currentColor"/><rect x="14" y="5" width="4" height="14" rx="1.2" fill="currentColor"/>',
    jump: '<path d="M12 4l7 7h-4v8H9v-8H5z" fill="currentColor"/>',
    eat: '<path d="M7 3v8a2 2 0 002 2v8M5 3v5M9 3v5M16 3c-2 1-3 4-3 7h3v11" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"/>',
    info: '<circle cx="12" cy="12" r="9" fill="none" stroke="currentColor" stroke-width="2"/><path d="M12 11v6M12 7.5v.5" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"/>',
    note: '<path d="M6 3h9l4 4v14H6z" fill="#f4e9c4"/><path d="M15 3v4h4" fill="#d9c98f"/><path d="M8.5 10h8M8.5 13h8M8.5 16h5" stroke="#8a7440" stroke-width="1.4" stroke-linecap="round"/>',
    keypad: '<rect x="5" y="2.5" width="14" height="19" rx="2" fill="#3a4048"/><rect x="7" y="4.5" width="10" height="3.5" rx=".8" fill="#7fd0a0"/><g fill="#c9d0d6"><circle cx="9" cy="11" r="1.2"/><circle cx="12" cy="11" r="1.2"/><circle cx="15" cy="11" r="1.2"/><circle cx="9" cy="14.5" r="1.2"/><circle cx="12" cy="14.5" r="1.2"/><circle cx="15" cy="14.5" r="1.2"/><circle cx="9" cy="18" r="1.2"/><circle cx="12" cy="18" r="1.2"/><circle cx="15" cy="18" r="1.2"/></g>',
    wolf: '<path d="M4 4l3 6-1 6 6 5 6-5-1-6 3-6-5 3h-6z" fill="#6f6a64"/><circle cx="9.5" cy="12" r="1.2" fill="#ffd23f"/><circle cx="14.5" cy="12" r="1.2" fill="#ffd23f"/><path d="M11 17h2l-1 1.4z" fill="#222"/>',
    rain: '<path d="M7 14a4.5 4.5 0 01.6-9A6 6 0 0119 7a3.6 3.6 0 01-.4 7z" fill="#9aa8b8"/><path d="M8 17l-1 3M12 17l-1 3M16 17l-1 3" stroke="#4fa3ff" stroke-width="1.8" stroke-linecap="round"/>',
    storm: '<path d="M7 13a4.5 4.5 0 01.6-9A6 6 0 0119 6a3.6 3.6 0 01-.4 7z" fill="#6c7684"/><path d="M13 13l-3 5h3l-2 4" stroke="#ffd23f" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round"/>',
    cloud: '<path d="M7 18a4.5 4.5 0 01.6-9A6 6 0 0119 11a3.6 3.6 0 01-.4 7z" fill="#c9d3dd"/>',
    fog: '<path d="M4 8h16M3 12h18M5 16h14" stroke="#c9d3dd" stroke-width="2.4" stroke-linecap="round"/>',
    send: '<path d="M3 11.5L21 3l-6 18-3.5-7z" fill="currentColor"/>',
    signal: '<path d="M5 19a10 10 0 010-14M19 5a10 10 0 010 14M8 16a6 6 0 010-8M16 8a6 6 0 010 8" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round"/><circle cx="12" cy="12" r="2" fill="currentColor"/>',
    save: '<path d="M5 3h11l3 3v15H5z" fill="currentColor" opacity=".9"/><rect x="8" y="3" width="7" height="5" fill="#0b1520"/><rect x="8" y="13" width="8" height="6" rx="1" fill="#0b1520"/>'
  };
  add.bag = '<path d="M9 6V4.5a3 3 0 016 0V6" stroke="#6b4a22" stroke-width="1.8" fill="none"/><rect x="4.5" y="6" width="15" height="15.5" rx="4" fill="#a5763e"/><path d="M7.5 6.5v14M16.5 6.5v14" stroke="#7a5328" stroke-width="1.6"/><rect x="8" y="12.5" width="8" height="6" rx="1.6" fill="#8a6030"/><path d="M8 14h8" stroke="#d9b47a" stroke-width="1.1"/>';
  for (var k in add) ICON[k] = add[k];
  ICON.mush = ICON.mushroom; ICON.mush_c = ICON.mushroom_c;
})();
function svgI(n, cls) { var b = ICON[n]; return b ? '<svg class="si' + (cls ? ' ' + cls : '') + '" viewBox="0 0 24 24" aria-hidden="true">' + b + '</svg>' : ''; }

/* властивості: s — розмір стосу, f/w — сита/вода, h — здоров'я, raw — ризик хвороби, rot — псується за N ігрових годин,
   cook — у що перетворюється на вогні, dur — міцність, vm — модель у руці, use — що робить «Використати» */
var ITEMS = {
  stick: { s: 32, vm: 'stick' }, stone: { s: 16, vm: 'stone' }, sharp: { s: 16, vm: 'sharp' }, fiber: { s: 32, vm: 'fiber' },
  rope: { s: 16, vm: 'rope' }, log: { s: 12, vm: 'log' }, bark: { s: 16, vm: 'bark' },
  apple: { s: 16, f: 11, w: 5, rot: 110, vm: 'apple' }, berry: { s: 24, f: 5, w: 6, rot: 48, vm: 'berry' },
  mush: { s: 16, f: 7, raw: 0.12, rot: 60, cook: 'mush_c', vm: 'mush' }, mush_c: { s: 16, f: 20, rot: 60, vm: 'cooked' },
  amanita: { s: 16, f: 3, poison: 1, vm: 'amanita' },
  fish: { s: 12, f: 8, raw: 0.45, rot: 34, cook: 'fish_c', vm: 'fish' }, fish_c: { s: 12, f: 38, h: 4, rot: 60, vm: 'cooked' },
  meat: { s: 12, f: 10, raw: 0.55, rot: 34, cook: 'meat_c', vm: 'meat' }, meat_c: { s: 12, f: 45, h: 5, rot: 60, vm: 'cooked' },
  rotten: { s: 24, f: 3, raw: 0.85, vm: 'charcoal' },
  ration: { s: 8, f: 42, w: -4, vm: 'ration' },
  plantain: { s: 16, use: 'heal', vm: 'herb' }, chamomile: { s: 16, vm: 'flower' }, charcoal: { s: 16, use: 'charcoal', vm: 'charcoal' },
  bandage: { s: 8, use: 'bandage', vm: 'bandage' },
  can_empty: { s: 1, vm: 'can' }, can_raw: { s: 1, w: 30, raw: 0.4, ret: 'can_empty', boil: 'can_boil', vm: 'can' },
  can_boil: { s: 1, w: 35, ret: 'can_empty', vm: 'can' }, can_tea: { s: 1, w: 30, warm: 15, cure: 1, ret: 'can_empty', vm: 'can' },
  axe: { s: 1, dur: 60, vm: 'axe', tool: 1 }, spear: { s: 1, dur: 28, vm: 'spear', tool: 1 }, rod: { s: 1, dur: 22, vm: 'rod', tool: 1 },
  drill: { s: 1, dur: 6, vm: 'drill', tool: 1 }, matches: { s: 1, dur: 6, vm: 'matches', tool: 1 },
  torch: { s: 4, use: 'torch', vm: 'torch' }, firelay: { s: 2, use: 'place', vm: 'firelay' }, kit: { s: 1, use: 'place', vm: 'kit' },
  snare: { s: 4, use: 'place', vm: 'snare' }, bedroll: { s: 1, use: 'sleep', vm: 'bedroll' }, radio: { s: 1, use: 'radio', vm: 'radio' }
};
for (var _id in ITEMS) ITEMS[_id].id = _id;
function iname(id) { return t('it.' + id); }
function idesc(id) { return t('itd.' + id); }

/* рецепти 2×2 за формою (порожні краї не важать, але розташування важить) */
var RECIPES = [
  { id: 'sharp', pat: ['T', 'T'], key: { T: 'stone' }, out: ['sharp', 1], time: 2.4, fail: 0.3 },
  { id: 'rope', pat: ['FF', 'F.'], key: { F: 'fiber' }, out: ['rope', 1], time: 2, fail: 0 },
  { id: 'axe', pat: ['KR', 'S.'], key: { K: 'sharp', R: 'rope', S: 'stick' }, out: ['axe', 1], time: 4, fail: 0 },
  { id: 'spear', pat: ['K', 'S'], key: { K: 'sharp', S: 'stick' }, out: ['spear', 1], time: 3, fail: 0 },
  { id: 'rod', pat: ['S.', 'SR'], key: { S: 'stick', R: 'rope' }, out: ['rod', 1], time: 3, fail: 0 },
  { id: 'drill', pat: ['SR', '.S'], key: { S: 'stick', R: 'rope' }, out: ['drill', 1], time: 3, fail: 0 },
  { id: 'firelay', pat: ['SS', 'FL'], key: { S: 'stick', F: 'fiber', L: 'log' }, out: ['firelay', 1], time: 3, fail: 0 },
  { id: 'torch', pat: ['F', 'S'], key: { F: 'fiber', S: 'stick' }, out: ['torch', 1], time: 2, fail: 0, need: 'fire' },
  { id: 'bandage', pat: ['FP'], key: { F: 'fiber', P: 'plantain' }, out: ['bandage', 1], time: 2, fail: 0 },
  { id: 'can', pat: ['BB', '.R'], key: { B: 'bark', R: 'rope' }, out: ['can_empty', 1], time: 4, fail: 0.15 },
  { id: 'snare', pat: ['R.', 'SS'], key: { R: 'rope', S: 'stick' }, out: ['snare', 1], time: 3, fail: 0 },
  { id: 'bedroll', pat: ['RR', 'FF'], key: { R: 'rope', F: 'fiber' }, out: ['bedroll', 1], time: 5, fail: 0 },
  { id: 'kit', pat: ['LL', 'SR'], key: { L: 'log', S: 'stick', R: 'rope' }, out: ['kit', 1], time: 6, fail: 0 }
];
RECIPES.forEach(function (r) {
  r.grid = r.pat.map(function (row) { return row.split('').map(function (ch) { return ch === '.' ? null : r.key[ch]; }); });
  r.items = []; r.grid.forEach(function (row) { row.forEach(function (id) { if (id) r.items.push(id); }); });
});
function gridSig(g) {
  var r0 = 9, r1 = -1, c0 = 9, c1 = -1;
  g.forEach(function (row, r) { row.forEach(function (id, c) { if (id) { r0 = Math.min(r0, r); r1 = Math.max(r1, r); c0 = Math.min(c0, c); c1 = Math.max(c1, c); } }); });
  if (r1 < 0) return '';
  var o = []; for (var r = r0; r <= r1; r++) { var s = []; for (var c = c0; c <= c1; c++) s.push((g[r] && g[r][c]) || '.'); o.push(s.join(',')); }
  return o.join('/');
}
RECIPES.forEach(function (r) { r.sig = gridSig(r.grid); });
function curRecipe() {
  var cells = inv.craft.map(function (s) { return s ? s.id : null; });
  if (cells.filter(Boolean).length < 2) return null;
  var sig = gridSig([[cells[0], cells[1]], [cells[2], cells[3]]]);
  for (var i = 0; i < RECIPES.length; i++) if (RECIPES[i].sig === sig) return RECIPES[i];
  return null;
}

/* ---------- інвентар ---------- */
var inv = { slots: new Array(36).fill(null), craft: new Array(4).fill(null), sel: 0 };
function mkStack(id, n) { var s = { id: id, n: n }; var d = ITEMS[id]; if (d.dur) s.d = d.dur; if (d.rot) s.b = G.tot; return s; }
function cloneSt(s, n) { var o = { id: s.id, n: n }; if (s.d !== undefined) o.d = s.d; if (s.b !== undefined) o.b = s.b; return o; }
function stackable(a, b) { return a && b && a.id === b.id && ITEMS[a.id].s > 1 && a.d === undefined; }
function canAdd(id, n) {
  var st = ITEMS[id].s, left = n;
  for (var i = 0; i < 36; i++) { var s = inv.slots[i]; if (!s) left -= st; else if (s.id === id && st > 1) left -= (st - s.n); if (left <= 0) return true; }
  return left <= 0;
}
function addItem(id, n) {
  n = n === undefined ? 1 : n; var st = ITEMS[id].s, left = n, i, s;
  if (st > 1) for (i = 0; i < 36 && left > 0; i++) { s = inv.slots[i]; if (s && s.id === id && s.n < st) { var tk = Math.min(left, st - s.n); s.n += tk; left -= tk; if (s.b !== undefined) s.b = Math.min(s.b, G.tot); } }
  for (i = 0; i < 36 && left > 0; i++) { if (!inv.slots[i]) { var tk2 = Math.min(left, st); inv.slots[i] = mkStack(id, tk2); left -= tk2; } }
  if (typeof refreshUI === 'function') refreshUI();
  return left === 0;
}
function putStack(st) { // повернути конкретний стос (з міцністю/свіжістю)
  if (st.d === undefined && ITEMS[st.id].s > 1) { for (var i = 0; i < 36 && st.n > 0; i++) { var s = inv.slots[i]; if (s && s.id === st.id && s.n < ITEMS[s.id].s) { var tk = Math.min(st.n, ITEMS[s.id].s - s.n); s.n += tk; st.n -= tk; if (st.b !== undefined) s.b = Math.min(s.b === undefined ? st.b : s.b, st.b); } } }
  if (st.n > 0) { var e = inv.slots.indexOf(null); if (e < 0) return false; inv.slots[e] = st; }
  return true;
}
function countItem(id) { var c = 0; for (var i = 0; i < 36; i++) { var s = inv.slots[i]; if (s && s.id === id) c += s.n; } return c; }
function hasItem(id) { return countItem(id) > 0; }
function findSlot(id) { if (inv.slots[inv.sel] && inv.slots[inv.sel].id === id) return inv.sel; for (var i = 0; i < 36; i++) if (inv.slots[i] && inv.slots[i].id === id) return i; return -1; }
function removeItem(id, n) {
  n = n === undefined ? 1 : n;
  for (var i = 35; i >= 0 && n > 0; i--) { var s = inv.slots[i]; if (s && s.id === id) { var tk = Math.min(n, s.n); s.n -= tk; n -= tk; if (s.n <= 0) inv.slots[i] = null; } }
  if (typeof refreshUI === 'function') refreshUI();
}
function removeAt(i, n) { var s = inv.slots[i]; if (!s) return; s.n -= (n || 1); if (s.n <= 0) inv.slots[i] = null; if (typeof refreshUI === 'function') refreshUI(); }
function consumeCraft() { for (var i = 0; i < 4; i++) { var s = inv.craft[i]; if (s) { s.n--; if (s.n <= 0) inv.craft[i] = null; } } }
/* знос інструмента: повертає true, якщо зламався */
function wearTool(id, amount) {
  var i = findSlot(id); if (i < 0) return false;
  var s = inv.slots[i]; s.d = (s.d === undefined ? ITEMS[id].dur : s.d) - (amount || 1);
  if (s.d <= 0) { inv.slots[i] = null; toast(t('msg.broke', { x: iname(id) }), id, 'bad'); AU.snap(); if (typeof refreshUI === 'function') refreshUI(); return true; }
  if (typeof refreshUI === 'function') refreshUI(); return false;
}
/* свіжість: стоси псуються з часом */
function freshK(s) { var d = ITEMS[s.id]; if (!d.rot || s.b === undefined) return 1; return clamp(1 - (G.tot - s.b) / (d.rot * 60), 0, 1); }
function spoilTick() {
  var ch = false;
  function chk(arr) { for (var i = 0; i < arr.length; i++) { var s = arr[i]; if (s && ITEMS[s.id].rot && s.b !== undefined && G.tot - s.b > ITEMS[s.id].rot * 60) { arr[i] = { id: 'rotten', n: s.n }; ch = true; } } }
  chk(inv.slots); chk(inv.craft);
  if (ch) { toast(t('msg.spoiled'), 'rotten', 'bad'); if (typeof refreshUI === 'function') refreshUI(); }
}
