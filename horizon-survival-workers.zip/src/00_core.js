'use strict';
/* =====================================================================
   ГОРИЗОНТ: ВИЖИВАННЯ — ядро: утиліти, налаштування, якість, збереження
   Код навмисно без новітнього синтаксису (?. ?? ...obj), щоб працювати
   у старих браузерах (Safari 11+, Chrome 61+, Firefox 60+).
   ===================================================================== */
/* поліфіли для старих браузерів */
if (window.Element && !Element.prototype.matches) Element.prototype.matches = Element.prototype.msMatchesSelector || Element.prototype.webkitMatchesSelector;
if (window.Element && !Element.prototype.closest) Element.prototype.closest = function (s) { var el = this; while (el && el.nodeType === 1) { if (el.matches(s)) return el; el = el.parentElement; } return null; };
if (!Array.prototype.fill) Array.prototype.fill = function (v) { for (var i = 0; i < this.length; i++) this[i] = v; return this; };
if (!Array.prototype.findIndex) Array.prototype.findIndex = function (f) { for (var i = 0; i < this.length; i++) if (f(this[i], i, this)) return i; return -1; };
if (window.Float32Array && !Float32Array.prototype.fill) Float32Array.prototype.fill = Array.prototype.fill;
if (!Math.hypot) Math.hypot = function () { var s = 0; for (var i = 0; i < arguments.length; i++) s += arguments[i] * arguments[i]; return Math.sqrt(s); };
var $ = function (id) { return document.getElementById(id); };
var rnd = function (a, b) { return a + Math.random() * (b - a); };
var clamp = function (v, a, b) { return v < a ? a : v > b ? b : v; };
var lerp = function (a, b, t) { return a + (b - a) * t; };
var smooth = function (a, b, x) { var t = clamp((x - a) / (b - a), 0, 1); return t * t * (3 - 2 * t); };
var pad2 = function (n) { n = Math.floor(n); return (n < 10 ? '0' : '') + n; };
var TAU = Math.PI * 2;
var now = function () { return (window.performance && performance.now) ? performance.now() : Date.now(); };

/* детермінований генератор (світ однаковий після завантаження збереження) */
function mulberry32(a) {
  return function () {
    a |= 0; a = (a + 0x6D2B79F5) | 0;
    var t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
if (!Math.imul) Math.imul = function (a, b) { var ah = (a >>> 16) & 0xffff, al = a & 0xffff, bh = (b >>> 16) & 0xffff, bl = b & 0xffff; return ((al * bl) + (((ah * bl + al * bh) << 16) >>> 0) | 0); };
var RNG = mulberry32(7);
var rr = function (a, b) { return a + RNG() * (b - a); };
var rpick = function (arr) { return arr[Math.floor(RNG() * arr.length)]; };

/* значення шуму для рельєфу та розкладки */
function hash2(x, z) { var s = Math.sin(x * 127.1 + z * 311.7) * 43758.5453; return s - Math.floor(s); }
function vnoise(x, z) {
  var ix = Math.floor(x), iz = Math.floor(z), fx = x - ix, fz = z - iz;
  fx = fx * fx * (3 - 2 * fx); fz = fz * fz * (3 - 2 * fz);
  var a = hash2(ix, iz), b = hash2(ix + 1, iz), c = hash2(ix, iz + 1), d = hash2(ix + 1, iz + 1);
  return a + (b - a) * fx + (c - a) * fz + (a - b - c + d) * fx * fz;
}
function fbm2(x, z) { return vnoise(x, z) * 0.55 + vnoise(x * 2.1 + 5.3, z * 2.1 + 1.7) * 0.3 + vnoise(x * 4.3 + 9.1, z * 4.3 + 3.3) * 0.15; }

/* безпечне сховище (у приватному режимі Safari localStorage кидає винятки) */
var store = {
  get: function (k, d) { try { var v = window.localStorage.getItem(k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } },
  set: function (k, v) { try { window.localStorage.setItem(k, JSON.stringify(v)); return true; } catch (e) { return false; } },
  del: function (k) { try { window.localStorage.removeItem(k); } catch (e) { } }
};
var SAVE_KEY = 'hz.save.v1', SET_KEY = 'hz.settings.v1';

/* пристрій */
var IS_TOUCH = ('ontouchstart' in window) || (navigator.maxTouchPoints > 0) || (navigator.msMaxTouchPoints > 0);
var COARSE = false; try { COARSE = !!(window.matchMedia && matchMedia('(pointer:coarse)').matches); } catch (e) { }
var IS_IOS = /iP(hone|ad|od)/.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);

/* налаштування */
var SET = { lang: 'uk', quality: 'auto', sens: 1, vol: 0.8, ai: true, invertY: false, fps: false, touch: 'auto', hints: true };
(function () { var s = store.get(SET_KEY, null); if (s) for (var k in s) if (k in SET) SET[k] = s[k]; })();
function saveSettings() { store.set(SET_KEY, SET); }
var touchMode = SET.touch === 'on' ? true : SET.touch === 'off' ? false : (IS_TOUCH && (COARSE || IS_IOS));

/* рівні якості: автоматично за пристроєм + динамічна роздільність під час гри */
var QP = {
  low: { scale: 0.62, minScale: 0.45, maxDpr: 1, grass: 0.3, fb: 2, part: 0.45, aa: false, fog: 1.25, rain: 220, shadows: false, view: 95 },
  medium: { scale: 0.85, minScale: 0.55, maxDpr: 1.5, grass: 0.6, fb: 3, part: 0.75, aa: false, fog: 1.08, rain: 420, shadows: true, view: 140 },
  high: { scale: 1, minScale: 0.7, maxDpr: 2, grass: 1, fb: 5, part: 1, aa: true, fog: 1, rain: 700, shadows: true, view: 200 }
};
function detectQuality() {
  var mem = navigator.deviceMemory || 4, cores = navigator.hardwareConcurrency || 4;
  var small = Math.min(screen.width || innerWidth, screen.height || innerHeight) < 500;
  if (mem <= 2 || cores <= 2) return 'low';
  if (IS_TOUCH || small || mem <= 4) return 'medium';
  return 'high';
}
var QL = SET.quality === 'auto' ? detectQuality() : SET.quality;
var URLQ = (location.search.match(/[?&]q=(low|medium|high)/) || [])[1]; if (URLQ) QL = URLQ;
var FIXRES = /[?&]fixed=1/.test(location.search);
if (!QP[QL]) QL = 'medium';
var Q = QP[QL];
