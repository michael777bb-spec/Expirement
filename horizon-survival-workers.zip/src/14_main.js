/* =====================================================================
   ГОЛОВНЕ: рендер, керування, збереження, запуск
   ===================================================================== */
var RES = { scale: Q.scale, acc: 0, n: 0, w: 0, h: 0 };
function resize() {
  var dpr = Math.min(window.devicePixelRatio || 1, Q.maxDpr), w = Math.max(320, Math.floor(innerWidth * dpr * RES.scale)), h = Math.max(200, Math.floor(innerHeight * dpr * RES.scale));
  if (w !== RES.w || h !== RES.h) { canvas.width = w; canvas.height = h; RES.w = w; RES.h = h; }
}
function dynRes(dt) {
  if (FIXRES) return;
  RES.acc += dt; RES.n++;
  if (RES.acc > 2.5) {
    var avg = RES.acc / RES.n; RES.acc = 0; RES.n = 0;
    if (avg > 1 / 27 && RES.scale > Q.minScale) RES.scale = Math.max(Q.minScale, RES.scale - 0.08);
    else if (avg < 1 / 52 && RES.scale < Q.scale) RES.scale = Math.min(Q.scale, RES.scale + 0.05);
  }
}
/* підсвітка цілі */
var HL = null;
function setHL(it) {
  if (HL === it) return;
  if (HL && HL.g.ib) HL.g.ib.tint(HL.i, 1, 1, 1, 0);
  HL = it; if (HL && HL.g.ib) HL.g.ib.tint(HL.i, 1.22, 1.22, 1.12, 0.07);
}
var GHOST = {};
function render(dt) {
  resize();
  var sh = P.shake > 0 ? P.shake : 0, bobA = P.moving && P.onGround ? 1 : 0;
  CAM.x = P.x + (sh ? (Math.random() - 0.5) * sh * 0.12 : 0); CAM.z = P.z + (sh ? (Math.random() - 0.5) * sh * 0.12 : 0);
  CAM.y = P.y + EYE + Math.sin(P.bob * 2) * 0.03 * bobA + (sh ? (Math.random() - 0.5) * sh * 0.1 : 0);
  CAM.yaw = P.yaw; CAM.pitch = P.pitch; CAM.roll = S.poison ? Math.sin(G.t * 0.8) * 0.04 * S.poison : (S.warm < 15 ? Math.sin(G.t * 40) * 0.003 : 0);
  CAM.fov = lerp(CAM.fov, P.running ? 1.33 : 1.25, Math.min(1, dt * 5));
  camUpdate(RES.w, RES.h); GLP.frame++;
  gl.viewport(0, 0, RES.w, RES.h); gl.clearColor(ENV.fog[0], ENV.fog[1], ENV.fog[2], 1); gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
  var u = useProg(PR.lit);
  gl.uniform1f(u.uDet, 1); drawMesh(TERRAIN); gl.uniform1f(u.uDet, 0);
  var tg = TARGET && TARGET.ref ? (TARGET.ref.it && TARGET.kind !== 'tree' ? TARGET.ref.it : TARGET.kind === 'tree' && TARGET.ref.st === 0 ? TARGET.ref.it : null) : (TARGET && TARGET.item ? TARGET.item : null);
  setHL(G.started ? tg : null);
  for (var k in GROUPS) {
    var g = GROUPS[k]; if (!g.ib || k === 'shadow' || !g.items.length) continue;
    if (!g.mesh.cull) gl.disable(gl.CULL_FACE);
    drawMesh(g.mesh, g.ib);
    if (!g.mesh.cull) gl.enable(gl.CULL_FACE);
  }
  gl.disable(gl.CULL_FACE);
  var maxD = Q.view * 0.42;
  for (var i = 0; i < GRASS.length; i++) { var m = GRASS[i], bs = m.bs; if (Math.abs(bs[0] - CAM.x) - 10 > maxD) continue; if (!inView(bs)) continue; drawMesh(m); }
  gl.enable(gl.CULL_FACE);
  FIRES.forEach(function (f) { var me = f.st === 'lay' ? M_FIRELAY : f.st === 'ash' ? M_ASH : M_PIT; drawMesh(me, null, f.rows, f.st === 'embers' ? [1, 0.8, 0.7, 0.25] : null); });
  SHELTERS.forEach(function (s) { gl.disable(gl.CULL_FACE); drawMesh(M_SHELTER, null, s.rows); gl.enable(gl.CULL_FACE); });
  SNARES.forEach(function (s) { drawMesh(s.caught ? M_SNARE_C : M_SNARE, null, s.rows); });
  DROPS.forEach(function (d) { var mdl = VM[ITEMS[d.id].vm] || VM.stone; mat34(tmp12, 0, d.x, H(d.x, d.z) + 0.08, d.z, d.x, 1.6, 1.6, 1.6, 0, 0, 1); drawMesh(mdl, null, tmp12); });
  wolvesDraw(); rabbitsDraw(); birdsDraw(G.t); fishDraw();
  if (FISH.st !== 'none' && !FISH.spear) { mat34(tmp12, 0, FISH.x, WATER_Y + (FISH.st === 'bite' ? -0.05 : Math.sin(G.t * 3) * 0.01), FISH.z, 0, 1, 1, 1, 0, 0, 1); drawMesh(M_BOBBER, null, tmp12); }
  if (PLACE.on) { var gm = PLACE.id === 'kit' ? M_SHELTER : PLACE.id === 'snare' ? M_SNARE : M_FIRELAY; mat34(tmp12, 0, PLACE.x, H(PLACE.x, PLACE.z), PLACE.z, PLACE.ry, 1, 1, 1, 0, 0, 1); gl.disable(gl.CULL_FACE); drawMesh(gm, null, tmp12, PLACE.ok ? [0.6, 1.4, 0.6, 0.35] : [1.5, 0.5, 0.5, 0.35]); gl.enable(gl.CULL_FACE); }
  // записка на стовпі (текстура)
  var ut = useProg(PR.tex); gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, NOTE_TEX); gl.uniform1i(ut.uTex, 0);
  gl.disable(gl.CULL_FACE); bindAttr(0, NOTE_MESH.bp, 3, gl.FLOAT, false); aEn(1, false); aEn(2, false); bindAttr(7, NOTE_MESH.bu, 2, gl.FLOAT, false); constRows(STORY_OBJ.paperRows); gl.drawArrays(gl.TRIANGLES, 0, NOTE_MESH.n); gl.enable(gl.CULL_FACE);
  drawSky();
  // плями тіней
  var sg = GROUPS.shadow; if (sg && sg.ib) { var ud = useProg(PR.dec); gl.uniform1f(ud.uA, (0.15 + 0.4 * ENV.dayK) * (1 - ENV.dark * 0.6)); gl.enable(gl.BLEND); gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA); gl.depthMask(false); gl.enable(gl.POLYGON_OFFSET_FILL); gl.polygonOffset(-1, -4); gl.disable(gl.CULL_FACE); drawMeshDec(sg); gl.enable(gl.CULL_FACE); gl.disable(gl.POLYGON_OFFSET_FILL); gl.depthMask(true); gl.disable(gl.BLEND); }
  // вода
  useProg(PR.wat); gl.enable(gl.BLEND); gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA); gl.depthMask(false); gl.disable(gl.CULL_FACE);
  WATERM.forEach(function (w) { if (!inView(w.bs)) return; bindAttr(0, w.bp, 3, gl.FLOAT, false); aEn(1, false); aEn(2, false); aEn(7, false); gl.drawArrays(gl.TRIANGLES, 0, w.n); });
  gl.enable(gl.CULL_FACE); gl.depthMask(true); gl.disable(gl.BLEND);
  ptDraw(); rainDraw(dt); linesDraw();
  if (G.started) viewmodelDraw(dt);
}
function drawMeshDec(g) { // тіні: ті ж екземпляри, але прозорий шейдер (альфа з кольору екземпляра)
  var ib = g.ib; if (!ib._a) { for (var i = 0; i < ib.n; i++) ib.c[i * 4 + 3] = 255; ib.dc = true; ib._a = 1; }
  drawMesh(g.mesh, ib);
}

/* ---------- кадр ---------- */
var lastT = now(), errN = 0;
function frozen() { return UI.ov === 'pause' || UI.ov === 'settings' || UI.ov === 'help' || UI.ov === 'journal' || UI.ov === 'note' || UI.ov === 'hatch'; }
function frame() {
  requestAnimationFrame(frame);
  var tn = now(), dt = Math.min(0.05, (tn - lastT) / 1000); lastT = tn; if (dt <= 0) return;
  G.t += dt;
  try {
    if (G.started && !S.ended && !frozen()) {
      if (!G.sleeping) {
        G.tot += dt * TS;
        if (P.swingT > (P._ls || 0)) P.swingDur = P.swingT; P.swingT = Math.max(0, P.swingT - dt); P._ls = P.swingT;
        if (P.shake > 0) P.shake = Math.max(0, P.shake - dt);
        if (P.torch > 0) { P.torch -= dt * (WX.rain > 0.3 && !underRoof(P.x, P.z) ? 2 : 1); if (P.torch <= 0) { P.torch = 0; toast(t(WX.rain > 0.3 ? 'msg.torchRain' : 'msg.torchOut'), 'torch'); } }
        movePlayer(dt); actionsStep(dt); fishStep(dt); statsStep(dt);
      }
      treesUpdate(dt); weatherStep(dt); firesStep(dt); respawnStep(dt); storyStep(dt); wolvesUpdate(dt); rabbitsUpdate(dt); fishUpdate(dt); craftStep(dt); tipStep(dt);
      if (UI.ov === 'fire' && UI.arg && UI.arg.cook) { var cb = $('cookBar'); if (cb) cb.style.width = Math.round(100 * UI.arg.cook.t / UI.arg.cook.dur) + '%'; }
      autosaveT -= dt; if (autosaveT <= 0) { autosaveT = 60; saveGame(true); }
    } else if (!G.started) {
      P.yaw += dt * 0.05; P.pitch = 0.08; G.tot += dt * 2; treesUpdate(dt); weatherStep(dt); firesStep(dt); fishUpdate(dt);
    } else if (S.ended && SKY.offT) { SKY.offT += dt; SKY.off = clamp(SKY.offT / 6, 0, 1); }
    envStep(dt); ptUpdate(dt); ripUpdate(dt);
    render(dt); dynRes(dt);
    if (G.started) hudStep(dt);
  } catch (e) { errN++; if (errN < 4) console.error(e); if (errN === 30) { try { saveGame(true); } catch (e2) { } toast(t('err.crash'), 'info', 'bad'); } }
}
var autosaveT = 60;

/* ---------- збереження ---------- */
function saveGame(silent) {
  if (!G.started || S.ended) return false;
  var d = {
    v: 1, G: G, S: S, STATS: STATS, P: { x: P.x, z: P.z, y: P.y, yaw: P.yaw, pitch: P.pitch, torch: P.torch },
    inv: { slots: inv.slots, sel: inv.sel },
    trees: TREES.map(function (tr) { return [tr.st === 1 ? 2 : tr.st, tr.hits, tr.proc, +(tr.dx || 0).toFixed(3), +(tr.dz || 0).toFixed(3), Math.round(tr.bark), Math.round(tr.appleT)]; }),
    nodes: NODES.map(function (n) { return n.t < 0 ? -1 : Math.round(n.t); }),
    fires: FIRES.map(function (f) { return [+f.x.toFixed(2), +f.z.toFixed(2), f.st, Math.round(f.fuel), f.coal ? 1 : 0, Math.round(f.emb || 0)]; }),
    shelters: SHELTERS.map(function (s) { return [s.x, s.z, s.ry]; }), snares: SNARES.map(function (s) { return [s.x, s.z, s.ry, s.set, s.caught ? 1 : 0, s.uses]; }),
    drops: DROPS.map(function (d2) { return [d2.x, d2.z, d2.id, d2.n]; }), crate: CRATE, wx: { type: WX.type, cloud: WX.cloud, rain: WX.rain, dark: WX.dark, fog: WX.fog, wind: WX.wind }
  };
  var ok = store.set(SAVE_KEY, d);
  if (!silent && ok) toast(t('msg.saved'), 'save', 'good');
  return ok;
}
function applySaveState(d) {
  G = d.G; S = d.S; STATS = d.STATS; for (var k in d.P) P[k] = d.P[k];
  inv.slots = d.inv.slots; inv.sel = d.inv.sel || 0; while (inv.slots.length < 36) inv.slots.push(null);
}
function applySaveWorld(d) {
  (d.trees || []).forEach(function (a, i) {
    var tr = TREES[i]; if (!tr) return; tr.hits = a[1]; tr.proc = a[2]; tr.bark = a[5]; tr.appleT = a[6];
    if (tr.kind === 'apple' && G.tot - tr.appleT < 30 * 60) tr.apples.forEach(function (ap) { ap.hid = true; writeInst(ap); });
    if (a[0] >= 2) {
      tr.st = a[0]; tr.dx = a[3]; tr.dz = a[4]; tr.col.on = false; showInst(tr.stump, true); showInst(tr.shadow, false); tr.apples.forEach(function (ap) { showInst(ap, false); });
      tr.it.tilt = Math.PI / 2 - 0.06; tr.it.dx = tr.dx; tr.it.dz = tr.dz; tr.landed = true; tr.fallT = 9; writeInst(tr.it);
      if (tr.st === 2) { var mid = (tr.kind === 'pine' ? 1.9 : tr.kind === 'birch' ? 1.6 : 1.5) * tr.s; tr.inter.x = tr.x + tr.dx * mid; tr.inter.z = tr.z + tr.dz * mid; tr.inter.y = H(tr.inter.x, tr.inter.z) + 0.4; tr.inter.r = 2.2; }
      else { showInst(tr.it, false); removeInter(tr.inter); tr.goneT = 1; }
    }
  });
  (d.nodes || []).forEach(function (t0, i) { var n = NODES[i]; if (!n || t0 < 0) return; n.t = t0; showInst(n.it, n.kind === 'bush'); n.extra.forEach(function (e) { showInst(e, false); }); n.inter.on = false; });
  (d.fires || []).forEach(function (a) { var f = addFire(a[0], a[1], a[2], a[3]); f.coal = !!a[4]; f.emb = a[5]; });
  (d.shelters || []).forEach(function (a) { addShelter(a[0], a[1], a[2]); });
  (d.snares || []).forEach(function (a) { var s = addSnare(a[0], a[1], a[2], a[5]); s.set = a[3]; s.caught = !!a[4]; });
  (d.drops || []).forEach(function (a) { addNodeDrop(a[0], a[1], a[2], a[3]); });
  if (d.crate) { for (var k in d.crate) CRATE[k] = d.crate[k]; if (CRATE.st === 'fall') CRATE.st = 'none', G.events.crate = 0; if (CRATE.st === 'land') { var it = STORY_OBJ.crate; it.hid = false; it.x = CRATE.x; it.z = CRATE.z; it.y = CRATE.gy; writeInst(it); addCol(CRATE.x, CRATE.z, 0.6); var I = STORY_OBJ.crateI; I.x = CRATE.x; I.z = CRATE.z; I.y = CRATE.gy + 0.6; I.on = !CRATE.open; } }
  if (d.wx) for (var w in d.wx) WX[w] = d.wx[w];
  for (var n = 2; n <= 6; n++) if (G.notes[n]) { var o = STORY_OBJ['note' + n]; if (o) { if (o.item) showInst(o.item, false); removeInter(o); } }
}

/* ---------- керування ---------- */
function isTyping(e) { var tg = e.target; return tg && (tg.tagName === 'INPUT' || tg.tagName === 'TEXTAREA'); }
document.addEventListener('keydown', function (e) {
  if (!G.started) return;
  if (isTyping(e)) { if (e.key === 'Enter' && e.target.id === 'rIn') radioSend(e.target.value); if (e.key === 'Escape') e.target.blur(); return; }
  var k = e.code || e.key;
  if (k === 'KeyM') { SET.vol = SET.vol > 0 ? 0 : 0.8; AU.vol(SET.vol); saveSettings(); return; }
  if (['Space', 'ArrowUp', 'ArrowDown', 'Tab'].indexOf(k) >= 0) e.preventDefault();
  if (UI.ov) {
    if (UI.ov === 'end') return;
    if (k === 'Escape' || k === 'Tab' || (k === 'KeyI' && UI.ov === 'inv') || (k === 'KeyJ' && UI.ov === 'journal') || (k === 'KeyE' && UI.ov !== 'journal')) { e.preventDefault(); closeOv(); }
    return;
  }
  if (S.ended) return;
  keys[k] = true;
  if (k === 'KeyE' || k === 'KeyF') { if (!INP.held) INP.pressed = true; INP.held = true; }
  else if (k === 'Space') INP.jump = true;
  else if (k === 'Tab' || k === 'KeyI') openOv('inv');
  else if (k === 'KeyJ') openOv('journal');
  else if (k === 'KeyQ') useHeld();
  else if (k === 'Escape') { if (PLACE.on) cancelPlace(); else openOv('pause'); }
  else if (k.indexOf('Digit') === 0) { var n = +k.slice(5); if (n >= 1 && n <= 9) { inv.sel = n - 1; FISH.st = 'none'; if (PLACE.on) cancelPlace(); refreshUI(); AU.click(); } }
});
document.addEventListener('keyup', function (e) { var k = e.code || e.key; keys[k] = false; if (k === 'KeyE' || k === 'KeyF') INP.held = false; });
window.addEventListener('blur', function () { keys = {}; INP.held = false; });
window.addEventListener('wheel', function (e) { if (!G.started || UI.ov) return; inv.sel = (inv.sel + (e.deltaY > 0 ? 1 : 8)) % 9; FISH.st = 'none'; if (PLACE.on) cancelPlace(); refreshUI(); }, { passive: true });
var MS = { down: false, btn: 0, mx: 0, my: 0, moved: 0, drag: false };
function locked() { return document.pointerLockElement === canvas || document.mozPointerLockElement === canvas; }
document.addEventListener('mousemove', function (e) {
  if (!G.started || UI.ov || touchMode) return;
  var dx = e.movementX || e.mozMovementX || 0, dy = e.movementY || e.mozMovementY || 0;
  if (locked()) { look(dx, dy, 0.0022); INP.lookX += dx; INP.lookY += dy; }
  else if (MS.down) { if (!dx && !dy) { dx = e.clientX - MS.mx; dy = e.clientY - MS.my; } MS.moved += Math.abs(dx) + Math.abs(dy); MS.mx = e.clientX; MS.my = e.clientY; if (MS.moved > 6) { MS.drag = true; look(dx, dy, 0.0034); INP.lookX += dx; INP.lookY += dy; } }
});
canvas.addEventListener('mousedown', function (e) {
  if (touchMode || UI.ov || !G.started || S.ended) return;
  AU.init();
  if (!locked()) {
    MS.down = true; MS.btn = e.button; MS.mx = e.clientX; MS.my = e.clientY; MS.moved = 0; MS.drag = false;
    try { var r = canvas.requestPointerLock && canvas.requestPointerLock(); if (r && r.catch) r.catch(function () { }); } catch (err) { }
    return;
  }
  primaryDown(e.button);
});
window.addEventListener('mouseup', function (e) {
  if (MS.down && !MS.drag && !locked() && G.started && !UI.ov) primaryDown(MS.btn), setTimeout(function () { INP.held = false; }, 120);
  MS.down = false; if (e.button === 0) INP.held = false;
});
canvas.addEventListener('contextmenu', function (e) { e.preventDefault(); });
function primaryDown(btn) {
  if (btn === 2) { if (PLACE.on) cancelPlace(); else useHeld(); return; }
  if (PLACE.on) { confirmPlace(); return; }
  if (ACT.cur && ACT.cur.ok) { INP.pressed = true; INP.held = true; }
  else if (FISH.st !== 'none') hookFish();
  else useHeld();
}
/* сенсор: джойстик, огляд, кнопки (touch-події — сумісно зі старим iOS) */
var TCH = { look: null, lx: 0, ly: 0, joy: null, jcx: 0, jcy: 0 };
canvas.addEventListener('touchstart', function (e) {
  if (!G.started || UI.ov) return; if (e.cancelable) e.preventDefault(); AU.init();
  for (var i = 0; i < e.changedTouches.length; i++) { var tc = e.changedTouches[i]; if (TCH.look === null) { TCH.look = tc.identifier; TCH.lx = tc.clientX; TCH.ly = tc.clientY; } }
}, { passive: false });
function moveJoy(tc) { var dx = (tc.clientX - TCH.jcx) / 52, dy = (tc.clientY - TCH.jcy) / 52, l = Math.sqrt(dx * dx + dy * dy); if (l > 1) { dx /= l; dy /= l; } joy.x = dx; joy.y = dy; $('knob').style.transform = 'translate(' + dx * 40 + 'px,' + dy * 40 + 'px)'; $('knob').style.webkitTransform = $('knob').style.transform; P.run = P.runLock || l > 1.25; }
$('joy').addEventListener('touchstart', function (e) { if (e.cancelable) e.preventDefault(); var tc = e.changedTouches[0]; TCH.joy = tc.identifier; var r = $('joy').getBoundingClientRect(); TCH.jcx = r.left + r.width / 2; TCH.jcy = r.top + r.height / 2; moveJoy(tc); AU.init(); }, { passive: false });
window.addEventListener('touchmove', function (e) {
  for (var i = 0; i < e.changedTouches.length; i++) {
    var tc = e.changedTouches[i];
    if (tc.identifier === TCH.look) { var dx = tc.clientX - TCH.lx, dy = tc.clientY - TCH.ly; look(dx, dy, 0.0058); INP.lookX += dx; INP.lookY += dy; TCH.lx = tc.clientX; TCH.ly = tc.clientY; if (e.cancelable) e.preventDefault(); }
    else if (tc.identifier === TCH.joy) { moveJoy(tc); if (e.cancelable) e.preventDefault(); }
  }
}, { passive: false });
function touchEnd(e) { for (var i = 0; i < e.changedTouches.length; i++) { var tc = e.changedTouches[i]; if (tc.identifier === TCH.look) TCH.look = null; if (tc.identifier === TCH.joy) { TCH.joy = null; joy.x = joy.y = 0; $('knob').style.transform = $('knob').style.webkitTransform = 'translate(0,0)'; P.run = !!P.runLock; } } }
window.addEventListener('touchend', touchEnd); window.addEventListener('touchcancel', touchEnd);
function tbtn(id, down, up) {
  var el = $(id);
  el.addEventListener('touchstart', function (e) { if (e.cancelable) e.preventDefault(); e.stopPropagation(); AU.init(); down(); }, { passive: false });
  el.addEventListener('touchend', function (e) { if (e.cancelable) e.preventDefault(); if (up) up(); }, { passive: false });
  el.addEventListener('mousedown', function (e) { e.preventDefault(); down(); }); el.addEventListener('mouseup', function () { if (up) up(); });
}
tbtn('tAct', function () { if (PLACE.on) { confirmPlace(); return; } if (FISH.st !== 'none' && !(ACT.cur && ACT.cur.ok && TARGET && TARGET.kind === 'water')) { hookFish(); return; } if (ACT.cur && ACT.cur.ok) { INP.pressed = true; INP.held = true; } else if (ACT.cur) AU.error(); }, function () { INP.held = false; });
tbtn('tUse', function () { useHeld(); });
tbtn('tJump', function () { INP.jump = true; });
tbtn('tRun', function () { P.runLock = !P.runLock; P.run = P.runLock; $('tRun').className = P.runLock ? 'on' : ''; });
function setTouch(on) { touchMode = on; $('touch').classList.toggle('hide', !(on && G.started)); document.body.classList.toggle('touch', on); }

/* ---------- кнопки інтерфейсу ---------- */
function onClick(id, fn) { var el = $(id); if (el) el.addEventListener('click', fn); }
function wireUI() {
  document.addEventListener('click', function (e) { var x = e.target.closest ? e.target.closest('[data-close]') : null; if (x) closeOv(); });
  onClick('btnJournal', function () { if (G.started && !UI.ov) openOv('journal'); });
  onClick('btnInv', function () { if (G.started && !UI.ov) openOv('inv'); });
  onClick('btnPause', function () { if (G.started && !UI.ov) openOv('pause'); });
  onClick('pSave', function () { saveGame(false); });
  onClick('pSet', function () { openOv('settings'); });
  onClick('pHelp', function () { openOv('help'); });
  onClick('pMenu', function () { saveGame(true); location.reload(); });
  onClick('btnPlace', confirmPlace); onClick('btnPlaceX', cancelPlace);
  onClick('btnSet', function () { openOv('settings'); });
  onClick('btnHelp', function () { openOv('help'); });
  onClick('btnSci', function () { toast(t('start.soon'), 'scroll'); });
  onClick('btnFs', toggleFs);
  onClick('btnCont', function () { startGame(false); });
  onClick('btnNew2', function () { newGame(); });
  onClick('btnLoad', function () { location.reload(); });
  onClick('btnLive', function () { closeOvSilent(); S.ended = false; SKY.offT = 0; SKY.off = 0; G.flags.post = 1; G.tot = Math.max(G.tot, 7 * 1440 + 6.6 * 60); toast(t('btn.live'), 'sun'); });
  onClick('btnInstall', function () { if (window._bip) { window._bip.prompt(); window._bip = null; $('btnInstall').classList.add('hide'); } });
  $('langBtns').addEventListener('click', function (e) { var b = e.target.closest('[data-lang]'); if (!b) return; LANG = SET.lang = b.getAttribute('data-lang'); saveSettings(); applyLang(); AU.click(); });
  $('ovFire').addEventListener('click', fireClick); $('ovJournal').addEventListener('click', journalClick);
  $('ovSettings').addEventListener('click', settingsClick); $('ovSettings').addEventListener('input', settingsInput); $('ovSettings').addEventListener('change', settingsInput);
  $('kpad').addEventListener('click', function (e) { var b = e.target.closest('[data-k]'); if (b) keypadPress(b.getAttribute('data-k')); });
  bindInv();
}
function toggleFs() {
  try {
    var d = document, el = d.documentElement;
    if (d.fullscreenElement || d.webkitFullscreenElement) { (d.exitFullscreen || d.webkitExitFullscreen).call(d); return; }
    var p = (el.requestFullscreen || el.webkitRequestFullscreen || el.msRequestFullscreen).call(el); if (p && p.then) p.then(function () { try { screen.orientation.lock('landscape').catch(function () { }); } catch (e) { } }).catch(function () { });
  } catch (e) { }
}
window.addEventListener('beforeinstallprompt', function (e) { e.preventDefault(); window._bip = e; var b = $('btnInstall'); if (b) b.classList.remove('hide'); });
document.addEventListener('visibilitychange', function () { if (document.hidden && G.started && !S.ended) { saveGame(true); if (!UI.ov) openOv('pause'); } });
window.addEventListener('pagehide', function () { if (G.started && !S.ended) saveGame(true); });

/* ---------- запуск ---------- */
function newGame() { var seed = Math.floor(Math.random() * 1e9) + 1; store.del(SAVE_KEY); store.set('hz.autostart', seed); location.reload(); }
function startGame(fresh) {
  AU.init(); AU.vol(SET.vol); G.started = true;
  $('start').classList.add('hide'); $('hud').classList.remove('hide'); setTouch(touchMode); document.body.classList.add('playing');
  if (fresh) {
    P.x = SPAWN.x; P.z = SPAWN.z; P.yaw = SPAWN.yaw; P.pitch = -0.05; P.y = H(P.x, P.z);
    addItem('apple', 2);
    setTimeout(function () { toast(t('start.lead').split('.')[0] + '…', 'leaf'); }, 1200);
    tip('move'); setTimeout(function () { tip('pick'); }, 9000); setTimeout(function () { tip('craft'); }, 26000); setTimeout(function () { tip('water'); }, 60000);
  } else { toast(t('start.continue'), 'save'); }
  P.y = H(P.x, P.z); refreshUI(); applyLang();
  if (!touchMode) { try { var r = canvas.requestPointerLock && canvas.requestPointerLock(); if (r && r.catch) r.catch(function () { }); } catch (e) { } }
  aiProbe();
}
function boot() {
  injectIcons();
  var save = store.get(SAVE_KEY, null), auto = store.get('hz.autostart', null);
  if (save && (!save.G || save.v !== 1)) save = null;
  freshState(save ? save.G.seed : (auto || Math.floor(Math.random() * 1e9) + 1));
  if (save) applySaveState(save);
  if (!glInit()) { var eb = $('errBox'); eb.textContent = t('err.webgl'); eb.style.display = 'block'; $('btnNew').disabled = true; $('btnCont').disabled = true; applyLang(); return; }
  canvas.addEventListener('webglcontextlost', function (e) { e.preventDefault(); try { saveGame(true); } catch (er) { } toast(t('err.lost'), 'info'); }, false);
  canvas.addEventListener('webglcontextrestored', function () { location.reload(); }, false);
  glPrograms(); buildViewModels(); buildSky(); buildTerrain(); buildNature(); buildPOI();
  M_FIRELAY = mdlFireLay(); M_PIT = mdlFirePit(false); M_ASH = mdlFirePit(true); M_SHELTER = mdlShelter(false); M_SNARE = mdlSnare(false); M_SNARE_C = mdlSnare(true); M_BOBBER = mdlBobber();
  finalizeGroups(); lifeInit(); ptInit(); rainInit();
  if (save) applySaveWorld(save);
  if (!save) { P.x = SPAWN.x - 2; P.z = SPAWN.z + 3; }
  P.y = H(P.x, P.z);
  wireUI(); applyLang(); setTouch(touchMode); $('fps').classList.toggle('hide', !SET.fps);
  window.addEventListener('resize', resize); resize();
  requestAnimationFrame(frame);
  if (auto && !save) { store.del('hz.autostart'); setTimeout(function () { startGame(true); }, 50); }
  // для старту нової гри без збереження кнопка «Нова гра» запускає одразу
  $('btnNew').onclick = function (e) { e.stopImmediatePropagation(); if (store.get(SAVE_KEY, null)) { if (confirm(t('start.newConfirm'))) newGame(); } else startGame(true); };
}
var M_BOBBER = null;
window.HZ = { G: function () { return G; }, S: function () { return S; }, P: function () { return P; }, inv: inv, TREES: TREES, NODES: NODES, FIRES: FIRES, WOLVES: WOLVES, give: addItem, act: function () { return ACT.cur; }, target: function () { return TARGET; }, chop: chopTree, start: startGame, openOv: openOv, closeOv: closeOv, save: saveGame, endGame: endGame, setTime: function (m) { G.tot = m; }, WX: WX, SKY: SKY, step: function (k, v) { INP[k] = v; }, keys: keys, useHeld: useHeld, confirmPlace: confirmPlace, startPlace: startPlace, crateDrop: crateDrop, spawnWolf: spawnWolf, RES: RES };
window.HZeval = function (s) { return eval(s); };
try { boot(); } catch (e) { console.error(e); var eb = $('errBox'); if (eb) { eb.textContent = t('err.webgl') + ' (' + e.message + ')'; eb.style.display = 'block'; } }
