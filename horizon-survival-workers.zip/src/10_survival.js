/* =====================================================================
   ВИЖИВАННЯ: час, погода, освітлення, показники, стани, вогонь, сон
   ===================================================================== */
var TS = 1 / 0.75; // ігрових хвилин за 1 с реального часу (доба ≈ 18 хв)
function hourOf() { return (G.tot % 1440) / 60; }
function dayOf() { return Math.floor(G.tot / 1440) + 1; }
function isNight() { var h = hourOf(); return h >= 20.5 || h < 5.3; }

/* ---------- погода: розклад по днях (сюжет) + плавні переходи ---------- */
var WPLAN = {
  1: [[0, 'clear']], 2: [[0, 'clear'], [14, 'cloudy'], [18.5, 'rain'], [23, 'cloudy']],
  3: [[0, 'cloudy'], [5, 'fog'], [9.5, 'clear'], [12.5, 'cloudy'], [15, 'storm'], [19, 'rain'], [22, 'cloudy']],
  4: [[0, 'clear']], 5: [[0, 'fog'], [9, 'clear'], [17, 'cloudy'], [21, 'rain']], 6: [[0, 'rain'], [4, 'cloudy'], [10, 'clear']],
  7: [[0, 'clear'], [12, 'cloudy'], [16, 'rain'], [19.5, 'storm'], [23.5, 'rain']]
};
var WT = { clear: { cloud: 0.25, rain: 0, dark: 0, fog: 0, wind: 0.6 }, cloudy: { cloud: 0.75, rain: 0, dark: 0.35, fog: 0, wind: 1.1 }, rain: { cloud: 0.95, rain: 0.75, dark: 0.68, fog: 0.15, wind: 1.4 }, storm: { cloud: 1, rain: 1, dark: 0.9, fog: 0.1, wind: 2.3 }, fog: { cloud: 0.55, rain: 0, dark: 0.3, fog: 1, wind: 0.2 } };
var WX = { type: 'clear', cloud: 0.25, rain: 0, dark: 0, fog: 0, wind: 0.6, light: 8 };
function weatherType() {
  var d = dayOf(), h = hourOf(), plan = WPLAN[d];
  if (!plan) { var r = mulberry32(G.seed + d * 31), seq = [[0, 'clear']]; var a = r(); if (a < 0.3) seq.push([10 + r() * 6, 'cloudy'], [15 + r() * 4, 'rain'], [21, 'cloudy']); else if (a < 0.5) seq.push([0, 'fog'], [9, 'clear']); plan = seq; }
  var tp = 'clear'; for (var i = 0; i < plan.length; i++) if (h >= plan[i][0]) tp = plan[i][1];
  return tp;
}
function weatherStep(dt) {
  var tp = weatherType();
  if (tp !== WX.type) {
    var was = WX.type; WX.type = tp;
    if (tp === 'rain' && was !== 'storm') { toast(t('msg.rain'), 'rain'); tip('rain'); logDay('rain'); }
    if (tp === 'storm') { toast(t('msg.storm'), 'storm', 'bad'); obsEvent('storm'); logDay('storm'); }
    if (tp === 'fog') toast(t('msg.fog'), 'fog');
    if ((tp === 'clear' || tp === 'cloudy') && (was === 'rain' || was === 'storm')) toast(t('msg.rainStop'), 'cloud');
  }
  var T = WT[tp], k = Math.min(1, dt * 0.12);
  ['cloud', 'rain', 'dark', 'fog', 'wind'].forEach(function (p) { WX[p] = lerp(WX[p], T[p], k); });
  if (tp === 'storm') { WX.light -= dt; if (WX.light <= 0) { WX.light = rnd(5, 14); lightning(); } }
}
function lightning() {
  SKY.flash = 1; var dist = rnd(0.2, 2.6); setTimeout(function () { AU.thunder(); }, dist * 1000);
  if (Math.random() < 0.3) { SKY.glitch = 0.95; G.glitchT = 0.4; }
}

/* ---------- освітлення за часом доби та погодою ---------- */
function envStep(dt) {
  var dayF = (G.tot % 1440) / 1440, a = (dayF - 0.25) * TAU;
  var sx = Math.cos(a) * 0.8, sy = Math.sin(a), sz = -0.55, sl = Math.sqrt(sx * sx + sy * sy + sz * sz); sx /= sl; sy /= sl; sz /= sl;
  ENV.sunVec = [sx, sy, sz];
  var dayK = smooth(-0.12, 0.28, sy), gold = Math.exp(-Math.pow(sy * 3.5, 2)), dark = WX.dark;
  ENV.dayK = dayK; ENV.gold = gold; ENV.dark = dark; ENV.cloud = WX.cloud; ENV.rain = WX.rain;
  var sunI = clamp(sy * 2.5, 0, 1) * (1 - dark * 0.8), warmT = clamp(sy * 3, 0, 1);
  var sc = cmix([1, 0.58, 0.32], [1, 0.94, 0.84], warmT);
  if (sy > -0.03) { ENV.sunDir = [sx, Math.max(sy, 0.12), sz]; ENV.sunCol = cmul(sc, 1.05 * sunI); }
  else { var mk = clamp(-sy * 3, 0, 1) * (1 - dark * 0.85); ENV.sunDir = [-sx, Math.max(-sy, 0.2), -sz]; ENV.sunCol = cmul([0.3, 0.36, 0.55], 0.42 * mk); }
  var dl = Math.sqrt(ENV.sunDir[0] * ENV.sunDir[0] + ENV.sunDir[1] * ENV.sunDir[1] + ENV.sunDir[2] * ENV.sunDir[2]); ENV.sunDir = ENV.sunDir.map(function (v) { return v / dl; });
  var amb = cmix([0.055, 0.07, 0.115], [0.48, 0.55, 0.66], dayK), gray = (amb[0] + amb[1] + amb[2]) / 3;
  amb = cmix(amb, [gray * 1.05, gray * 1.05, gray * 1.1], dark * 0.8); amb = cmul(amb, 1 - dark * 0.22);
  ENV.sky = amb; ENV.gnd = cmul(cmix([0.03, 0.035, 0.04], [0.3, 0.27, 0.19], dayK), 1 - dark * 0.3);
  if (SKY.flash > 0) { ENV.sky = cmix(ENV.sky, [1, 1, 1.1], SKY.flash * 0.6); SKY.flash = Math.max(0, SKY.flash - dt * 3.5); }
  var fog = skyHorizon(dayK, gold, dark);
  if (WX.fog > 0.02) fog = cmix(fog, cmix([0.08, 0.09, 0.1], [0.72, 0.74, 0.76], dayK), WX.fog * 0.75);
  ENV.fog = fog; ENV.horz = fog; ENV.zen = cmix([0.02, 0.04, 0.1], cmix([0.25, 0.45, 0.8], [0.45, 0.47, 0.5], dark), dayK);
  ENV.fogD = (0.0072 + WX.fog * 0.04 + WX.rain * 0.011 + (1 - dayK) * 0.004) * Q.fog;
  ENV.wind = [0.1 + WX.wind * 0.12, 1.2 + WX.wind * 0.5, 1];
  ENV.time = G.t;
  // точкові вогні: найближчі до камери
  var L = [];
  FIRES.forEach(function (f) { if (f.st === 'lit' || f.st === 'embers') { var fl = f.st === 'lit' ? 0.85 + 0.15 * Math.sin(G.t * 17 + f.x) * Math.sin(G.t * 7.3 + f.z) : 0.25; var pw = f.st === 'lit' ? Math.min(1, f.fuel / 30) : 0.3; L.push([f.x, f.y + 0.8, f.z, f.st === 'lit' ? 15 : 5, 1.5 * fl * pw, 0.75 * fl * pw, 0.32 * fl * pw]); } });
  if (P.torch > 0) { var tp = P.torchPos || [P.x, P.y + 1.6, P.z], tf = (0.9 + 0.1 * Math.sin(G.t * 20)) * Math.min(1, P.torch / 8); L.push([tp[0], tp[1], tp[2], 11, 1.25 * tf, 0.68 * tf, 0.3 * tf]); }
  if (CRATE.st === 'fall' || CRATE.st === 'land') L.push([CRATE.x, CRATE.y + 1, CRATE.z, 6, 0.8, 0.15, 0.1]);
  L.sort(function (p, q) { return Math.hypot(p[0] - CAM.x, p[2] - CAM.z) - Math.hypot(q[0] - CAM.x, q[2] - CAM.z); });
  for (var i = 0; i < 4; i++) { var l = L[i]; if (l) { ENV.pl.set([l[0], l[1], l[2], l[3]], i * 4); ENV.pc.set([l[4], l[5], l[6]], i * 3); } else { ENV.pl.set([0, -100, 0, 1], i * 4); ENV.pc.set([0, 0, 0], i * 3); } }
  // звуки середовища
  var nearestFire = 1e9; FIRES.forEach(function (f) { if (f.st === 'lit') nearestFire = Math.min(nearestFire, Math.hypot(f.x - P.x, f.z - P.z)); });
  var nearestPond = 1e9; PONDS.forEach(function (p) { nearestPond = Math.min(nearestPond, Math.hypot(p.x - P.x, p.z - P.z) - p.r); });
  AU.setLoop('wind', 0.02 + WX.wind * 0.035); AU.setLoop('rain', WX.rain * 0.09); AU.setLoop('rain2', WX.rain * 0.07);
  AU.setLoop('fire', nearestFire < 12 ? 0.11 * (1 - nearestFire / 12) : 0); AU.setLoop('water', nearestPond < 10 ? 0.03 * (1 - Math.max(0, nearestPond) / 10) : 0);
  AU.setLoop('crick', (1 - dayK) * (1 - WX.rain) * 0.012);
}

/* ---------- показники та стани ---------- */
function harm(n, cause) { S.hp = Math.max(0, S.hp - n); S.hurtT = 0.5; S.lastCause = cause || S.lastCause; }
function setSick() { if (S.sick) return; S.sick = G.tot + 22 * 60; toast(t('msg.sick'), 'sick', 'bad'); AU.hurt(); tip('sick'); logDay('sick'); obsEvent('sick'); }
function setPoison() { S.poison = 1; toast(t('msg.poisoned'), 'poison', 'bad'); AU.hurt(); logDay('sick'); }
var warnF = {};
function warn(k, cond, msg, ic) { if (cond && !warnF[k]) { warnF[k] = 1; toast(t(msg), ic, 'bad'); } }
function statsStep(dt) {
  var run = P.running, sickK = S.sick ? 1.75 : 1, night = ENV.dayK < 0.3, roof = underRoof(P.x, P.z);
  var depth = waterDepth(P.x, P.z);
  S.food = clamp(S.food - dt * (0.055 + (run ? 0.04 : 0)) * sickK, 0, 100);
  S.water = clamp(S.water - dt * (0.088 + (run ? 0.06 : 0) + (ENV.dayK > 0.8 && WX.cloud < 0.4 ? 0.015 : 0)) * sickK, 0, 100);
  S.energy = clamp(S.energy - dt * (0.042 + (run ? 0.09 : 0) + (S.sick ? 0.02 : 0)), 0, 100);
  if (run) S.stamina = Math.max(0, S.stamina - dt * 17); else S.stamina = Math.min(100, S.stamina + dt * (S.energy > 15 ? 13 : 5));
  // волога
  var underTree = nearTree(P.x, P.z, 2.6);
  if (WX.rain > 0.05 && !roof) S.wet = clamp(S.wet + dt * 0.03 * WX.rain * (underTree ? 0.3 : 1), 0, 1);
  if (depth > 0.15) S.wet = clamp(Math.max(S.wet, clamp(depth * 1.6, 0, 1)), 0, 1);
  var fire = nearFire(6), fireD = 99; FIRES.forEach(function (f) { if (f.st === 'lit') fireD = Math.min(fireD, Math.hypot(f.x - P.x, f.z - P.z)); });
  if (fireD < 4.5) S.wet = Math.max(0, S.wet - dt * 0.045); else if (WX.rain < 0.05 && depth < 0.1) S.wet = Math.max(0, S.wet - dt * (ENV.dayK > 0.6 ? 0.012 : 0.006));
  // тепло: тенденція від середовища
  var d = dayOf(), base = night ? (d === 1 ? -0.3 : d === 6 ? -0.62 : -0.44) : (ENV.dayK > 0.6 ? 0.5 : 0.1);
  base -= WX.rain * (roof ? 0.1 : 0.38) + Math.max(0, WX.wind - 1) * 0.12 + S.wet * 0.45;
  if (fireD < 7) base += 2.6 * (1 - fireD / 7) + (fireD < 3 ? 0.6 : 0);
  if (P.torch > 0) base += 0.45; if (roof) base += 0.3; if (run) base += 0.15;
  S.warm = clamp(S.warm + base * dt, 0, 100);
  // здоров'я
  var dmg = 0;
  if (S.food <= 0) { dmg += 0.42; S.lastCause = 'food'; }
  if (S.water <= 0) { dmg += 0.58; S.lastCause = 'water'; }
  if (S.warm <= 0) { dmg += 0.35; S.lastCause = 'cold'; }
  if (S.bleed) { dmg += 0.42; S.bleed += dt; S.lastCause = 'bleed'; if (S.bleed > 150) { S.bleed = 0; toast(t('msg.bleedStop'), 'bleed'); } }
  if (S.poison) { dmg += 0.38 * S.poison; S.poison = Math.max(0, S.poison - dt * 0.0045); S.lastCause = 'poison'; if (!S.poison) toast(t('msg.poisonGone'), 'poison', 'good'); }
  if (S.sick && G.tot > S.sick) { S.sick = 0; toast(t('msg.cured'), 'sick', 'good'); }
  if (dmg) { S.hp = Math.max(0, S.hp - dmg * dt); S.hurtT = Math.max(S.hurtT, 0.15); }
  else if (S.food > 40 && S.water > 40 && S.warm > 35 && !S.sick) S.hp = Math.min(100, S.hp + dt * 0.22);
  if (S.hurtT > 0) S.hurtT -= dt;
  warn('food', S.food < 18, 'msg.hungry', 'food'); if (S.food > 35) warnF.food = 0;
  warn('water', S.water < 18, 'msg.thirsty', 'drop'); if (S.water > 35) warnF.water = 0;
  warn('cold', S.warm < 30, 'msg.coldWarn', 'cold'); if (S.warm > 50) warnF.cold = 0; if (S.warm < 30) tip('cold');
  warn('tired', S.energy < 14, 'msg.tiredWarn', 'tired'); if (S.energy > 40) warnF.tired = 0;
  warn('wet', S.wet > 0.85, 'msg.wetWarn', 'wet'); if (S.wet < 0.3) warnF.wet = 0;
  if (depth > 0.2 && !warnF.water2) { warnF.water2 = 1; toast(t('msg.water'), 'wet'); } if (depth < 0.05) warnF.water2 = 0;
  if (S.hp < 30 && !warnF.lowhp) { warnF.lowhp = 1; obsEvent('lowhp'); } if (S.hp > 60) warnF.lowhp = 0;
  // пара з рота на холоді
  if ((S.warm < 45 || (night && WX.rain < 0.1)) && Math.random() < dt * 0.6) { var f = fwd(); PRE.breath(P.x, P.y + EYE, P.z, f[0], f[2]); }
  if (S.hp <= 0 && !S.ended) endGame('dead');
}

/* ---------- вогнища ---------- */
function firesStep(dt) {
  var roofRain = WX.rain;
  FIRES.forEach(function (f) {
    if (f.st === 'lit') {
      var wetK = underRoof(f.x, f.z) ? 1 : 1 + roofRain * 1.2;
      f.fuel -= dt * wetK;
      var far = Math.hypot(f.x - CAM.x, f.z - CAM.z) > 70;
      if (!far) {
        var k = Math.min(1, f.fuel / 40) * 0.6 + 0.4, rate = (QL === 'low' ? 14 : 30) * dt;
        for (var i = 0; i < rate; i++) PRE.flame(f.x, f.y + 0.15, f.z, k);
        if (Math.random() < dt * 4) PRE.ember(f.x, f.y + 0.4, f.z);
        if (Math.random() < dt * (QL === 'low' ? 2 : 5)) PRE.smoke(f.x, f.y + 1.1, f.z, roofRain > 0.3 ? 1.6 : 1);
        if (Math.random() < dt * 0.8 && Math.hypot(f.x - P.x, f.z - P.z) < 10) AU.crackle();
      }
      if (f.cook) { f.cook.t += dt; if (Math.random() < dt * 3) PRE.steam(f.x, f.y + 0.6, f.z); if (f.cook.t >= f.cook.dur) finishCook(f); }
      if (f.fuel <= 0) { f.st = 'embers'; f.fuel = 0; f.emb = 90; f.cook = null; if (Math.hypot(f.x - P.x, f.z - P.z) < 30) toast(t('msg.fireOut'), 'campfire', 'bad'); }
    } else if (f.st === 'embers') {
      f.emb -= dt * (1 + roofRain); if (Math.random() < dt * 2) PRE.smoke(f.x, f.y + 0.3, f.z, 0.6); if (Math.random() < dt * 1.5) PRE.ember(f.x, f.y + 0.15, f.z);
      if (f.emb <= 0) { f.st = 'ash'; }
    }
  });
}
function finishCook(f) {
  var c = f.cook; f.cook = null;
  if (c.kind === 'cook') { if (!giveItems([[ITEMS[c.id].cook, 1]])) return; toast(t('msg.cooked', { x: iname(ITEMS[c.id].cook) }), ITEMS[c.id].cook, 'good'); STATS.cooked++; G.flags.cooked = 1; if (c.id === 'fish' || c.id === 'meat') G.flags.cookedMeat = 1; }
  else if (c.kind === 'boil') { var i = inv.slots.findIndex(function (s) { return s && s.id === 'can_raw'; }); if (i >= 0) { inv.slots[i] = mkStack('can_boil', 1); toast(t('msg.boiled'), 'can_boil', 'good'); G.flags.boiled = 1; } }
  else if (c.kind === 'tea') { var j = inv.slots.findIndex(function (s) { return s && s.id === 'can_boil'; }); if (j >= 0 && hasItem('chamomile')) { removeItem('chamomile', 1); inv.slots[j] = mkStack('can_tea', 1); toast(t('msg.tea'), 'can_tea', 'good'); } }
  AU.crackle(); refreshUI(); if (UI.ov === 'fire') renderFire();
}
function fireAction(f, h) {
  if (f.st === 'lay') {
    if (hasItem('matches')) return { label: t('act.lightM'), icon: 'matches', dur: 0.8, ok: true, fn: function () { igniteFire(f, 'matches'); } };
    if (hasItem('drill')) return { label: t('act.light'), icon: 'drill', dur: 3.2, ok: true, fn: function () { igniteFire(f, 'drill'); }, drill: true };
    return { label: t('act.lightNeed'), icon: 'drill', ok: false };
  }
  if (f.st === 'ash' && !f.coal) return { label: t('act.coal'), icon: 'charcoal', dur: 0.8, ok: true, fn: function () { if (giveItems([['charcoal', 2]])) { f.coal = true; toast(t('msg.coal'), 'charcoal'); } } };
  if (f.st === 'ash' && (hasItem('drill') || hasItem('matches')) && hasItem('stick')) return { label: t('fire.light'), icon: 'drill', dur: hasItem('matches') ? 0.8 : 3.2, ok: true, fn: function () { removeItem('stick', 1); f.st = 'lay'; igniteFire(f, hasItem('matches') ? 'matches' : 'drill'); } };
  return { label: t('act.fire'), icon: 'campfire', dur: 0, ok: true, fn: function () { openOv('fire', f); } };
}
function igniteFire(f, how) {
  var roof = underRoof(f.x, f.z);
  if (WX.rain > 0.3 && !roof) { toast(t('msg.fireRain'), 'rain', 'bad'); AU.error(); return 'stop'; }
  if (how === 'drill') { if (wearTool('drill') && false) return; if (Math.random() < 0.3 + WX.wind * 0.08) { toast(t('msg.fireFail'), 'drill'); AU.drillTick(); return 'stop'; } }
  else wearTool('matches');
  f.st = 'lit'; f.fuel = Math.max(f.fuel, 240); AU.ignite(); PRE.spark(f.x, f.y + 0.3, f.z, 12);
  toast(t('msg.fireLit'), 'campfire', 'good'); G.flags.fire = 1; STATS.fires++; obsEvent('fire'); tip('cook');
  if (UI.ov === 'fire') renderFire();
  return 'stop';
}
function addFuel(f, id) {
  if (!hasItem(id)) return; removeItem(id, 1);
  if (f.st === 'embers' || f.st === 'ash') { if (f.st === 'ash') return; f.st = 'lit'; f.fuel = 0; }
  f.fuel = Math.min(900, f.fuel + (id === 'log' ? 240 : 60)); AU.crackle(); PRE.spark(f.x, f.y + 0.3, f.z, 6); toast(t('msg.fuel'), 'campfire');
}
function startCook(f, kind, id) {
  if (f.cook || f.st !== 'lit') return;
  if (kind === 'cook') { if (!hasItem(id)) return; removeItem(id, 1); f.cook = { kind: kind, id: id, t: 0, dur: id === 'mush' ? 5 : 8 }; }
  else if (kind === 'boil') f.cook = { kind: kind, t: 0, dur: 7 };
  else if (kind === 'tea') f.cook = { kind: kind, t: 0, dur: 5 };
  AU.crackle(); renderFire();
}

/* ---------- ресурси знову виростають ---------- */
var respT = 0;
function respawnStep(dt) {
  respT -= dt; if (respT > 0) return; respT = 2;
  NODES.forEach(function (n) {
    if (n.t < 0) return;
    if (G.tot - n.t > n.resp && Math.hypot(n.x - P.x, n.z - P.z) > 10) { n.t = -1; showInst(n.it, true); n.extra.forEach(function (e) { showInst(e, true); }); n.inter.on = true; }
  });
  TREES.forEach(function (tr) { if (tr.kind === 'apple' && tr.st === 0 && tr.appleT > 0 && G.tot - tr.appleT > 30 * 60) { tr.appleT = -1e9; tr.apples.forEach(function (a) { showInst(a, true); }); } });
  // сильця: щогодини шанс упіймати зайця (краще на світанку й у сутінках)
  SNARES.forEach(function (s) { if (s.caught) return; var hrs = Math.floor((G.tot - s.set) / 60); if (hrs > (s.chk || 0)) { s.chk = hrs; var h = hourOf(), k = (h > 5 && h < 9) || (h > 18 && h < 22) ? 0.2 : 0.09; if (Math.random() < k) s.caught = true; } });
  spoilTick();
}

/* ---------- сон ---------- */
function trySleep(where) {
  if (S.ended || G.sleeping) return;
  var night = isNight();
  if (!night && S.energy > 70) { toast(t('msg.sleepNo'), 'tired'); AU.error(); return; }
  G.sleeping = true; AU.sleep(); if (FISH) FISH.st = 'none';
  fadeBlack(function () {
    var h = hourOf(), target;
    if (night) target = h >= 20 ? (dayOf()) * 1440 + 6.5 * 60 : (dayOf() - 1) * 1440 + 6.5 * 60; else target = G.tot + 180;
    var dm = target - G.tot, hrs = dm / 60, secs = dm / TS;
    var roof = underRoof(P.x, P.z) || where === 'shelter', bed = where === 'bedroll' || hasItem('bedroll');
    var fireOk = FIRES.some(function (f) { return f.st === 'lit' && f.fuel > secs * 0.55 && Math.hypot(f.x - P.x, f.z - P.z) < 6; });
    var wolfRisk = night && dayOf() >= 2 && !fireOk ? (roof ? 0.18 : 0.45) : 0, woke = Math.random() < wolfRisk;
    if (woke) { var part = rnd(0.3, 0.7); dm *= part; hrs *= part; secs *= part; }
    FIRES.forEach(function (f) { if (f.st === 'lit') { f.fuel -= secs; if (f.fuel <= 0) { f.fuel = 0; f.st = 'ash'; } } });
    P.torch = Math.max(0, P.torch - secs);
    G.tot += dm; G.t += secs;
    S.food = Math.max(3, S.food - hrs * 2.4); S.water = Math.max(3, S.water - hrs * 3.4);
    S.energy = clamp(S.energy + hrs * (bed && roof ? 14 : bed || roof ? 12 : 9), 0, 100);
    if (S.sick && G.tot > S.sick) S.sick = 0; if (S.poison) S.poison = Math.max(0, S.poison - hrs * 0.3); if (S.bleed) { S.bleed = 0; harm(10, 'bleed'); }
    var msg = t(night ? 'msg.sleepOk' : 'msg.nap'), cls = 'good';
    if (night && !fireOk) { var loss = bed && roof ? 12 : roof ? 25 : bed ? 30 : 52; S.warm = Math.max(5, S.warm - loss); if (loss > 20) { harm(loss > 40 ? 16 : 7, 'cold'); msg = t('msg.sleepCold'); cls = 'bad'; logDay('cold'); } }
    else S.warm = Math.max(S.warm, 70);
    if (WX.rain > 0.3 && !roof) { S.wet = 1; msg = t('msg.sleepRain'); cls = 'bad'; }
    if (S.food > 30 && S.water > 30) S.hp = clamp(S.hp + hrs * 2.5, 0, 100);
    if (woke) { msg = t('msg.sleepWolves'); cls = 'bad'; spawnWolf(); var w = WOLVES[WOLVES.length - 1]; w.x = P.x + 6; w.z = clamp(P.z + 3, -ZLIM, ZLIM); w.st = 'attack'; harm(10, 'wolf'); S.bleed = Math.random() < 0.4 ? 1 : 0; }
    G.sleeping = false; toast(msg, woke ? 'wolf' : 'bedroll', cls);
    if (night && !woke) { writeDiary(); G.flags.slept = 1; }
    if (S.hp <= 0) endGame('dead'); else saveGame(true);
  }, 900);
}
