/* =====================================================================
   РУШІЙ: WebGL 1 (працює на старих телефонах і без інтернету)
   - один шейдер освітлення для всього (сонце, небо, до 4 точкових вогнів,
     туман, вітер для листя/трави), інстансинг через ANGLE_instanced_arrays
     з запасним шляхом, частинки, лінії, вода, небо-екран, плями тіней.
   ===================================================================== */
var gl = null, EXT = {}, GLP = { maxPoint: 64, frame: 0 };
var canvas = $('c');
function glInit() {
  var o = { antialias: !!Q.aa, alpha: false, depth: true, stencil: false, premultipliedAlpha: false, preserveDrawingBuffer: false, powerPreference: 'high-performance' };
  try { gl = canvas.getContext('webgl', o) || canvas.getContext('experimental-webgl', o); } catch (e) { gl = null; }
  if (!gl) return false;
  EXT.inst = /[?&]noinst=1/.test(location.search) ? null : gl.getExtension('ANGLE_instanced_arrays');
  var pr = gl.getParameter(gl.ALIASED_POINT_SIZE_RANGE); GLP.maxPoint = pr ? Math.min(96, pr[1]) : 32;
  gl.enable(gl.DEPTH_TEST); gl.depthFunc(gl.LEQUAL); gl.enable(gl.CULL_FACE); gl.cullFace(gl.BACK);
  return true;
}

/* ---------- математика (column-major як у WebGL) ---------- */
function m4() { var m = new Float32Array(16); m[0] = m[5] = m[10] = m[15] = 1; return m; }
function m4persp(o, fovy, asp, n, f) {
  var t = 1 / Math.tan(fovy / 2), nf = 1 / (n - f);
  o.fill(0); o[0] = t / asp; o[5] = t; o[10] = (f + n) * nf; o[11] = -1; o[14] = 2 * f * n * nf; return o;
}
function m4mul(o, a, b) {
  var r = new Float32Array(16);
  for (var c = 0; c < 4; c++) for (var rr2 = 0; rr2 < 4; rr2++) {
    r[c * 4 + rr2] = a[rr2] * b[c * 4] + a[4 + rr2] * b[c * 4 + 1] + a[8 + rr2] * b[c * 4 + 2] + a[12 + rr2] * b[c * 4 + 3];
  }
  o.set(r); return o;
}
/* вид камери: обертання yaw (навколо Y), pitch (X), roll (Z) */
function m4view(o, x, y, z, yaw, pitch, roll) {
  var cy = Math.cos(yaw), sy = Math.sin(yaw), cp = Math.cos(pitch), sp = Math.sin(pitch), cr = Math.cos(roll || 0), sr = Math.sin(roll || 0);
  // світова матриця камери W = T * Ry * Rx * Rz ; вид = W^-1
  var R = [
    cy * cr + sy * sp * sr, cp * sr, -sy * cr + cy * sp * sr,
    -cy * sr + sy * sp * cr, cp * cr, sy * sr + cy * sp * cr,
    sy * cp, -sp, cy * cp
  ]; // рядки = осі камери (right, up, back) у світових
  o[0] = R[0]; o[4] = R[1]; o[8] = R[2];
  o[1] = R[3]; o[5] = R[4]; o[9] = R[5];
  o[2] = R[6]; o[6] = R[7]; o[10] = R[8];
  o[3] = 0; o[7] = 0; o[11] = 0; o[15] = 1;
  o[12] = -(R[0] * x + R[1] * y + R[2] * z);
  o[13] = -(R[3] * x + R[4] * y + R[5] * z);
  o[14] = -(R[6] * x + R[7] * y + R[8] * z);
  return R;
}
/* 3×4 матриця екземпляра: T * Rtilt * Ry * S (нахил — падіння дерева в напрямку dx,dz) */
function mat34(out, off, x, y, z, ry, sx, sy, sz, tilt, dx, dz) {
  var c = Math.cos(ry), s = Math.sin(ry);
  // Ry*S
  var a00 = c * sx, a01 = 0, a02 = s * sz;
  var a10 = 0, a11 = sy, a12 = 0;
  var a20 = -s * sx, a21 = 0, a22 = c * sz;
  if (tilt) {
    // вісь k = (dz,0,-dx), формула Родрігеса
    var kx = dz, kz = -dx, kl = Math.sqrt(kx * kx + kz * kz) || 1; kx /= kl; kz /= kl;
    var ct = Math.cos(tilt), st = Math.sin(tilt), vt = 1 - ct;
    var r00 = ct + kx * kx * vt, r01 = -kz * st, r02 = kx * kz * vt;
    var r10 = kz * st, r11 = ct, r12 = -kx * st;
    var r20 = kz * kx * vt, r21 = kx * st, r22 = ct + kz * kz * vt;
    var b00 = r00 * a00 + r01 * a10 + r02 * a20, b01 = r00 * a01 + r01 * a11 + r02 * a21, b02 = r00 * a02 + r01 * a12 + r02 * a22;
    var b10 = r10 * a00 + r11 * a10 + r12 * a20, b11 = r10 * a01 + r11 * a11 + r12 * a21, b12 = r10 * a02 + r11 * a12 + r12 * a22;
    var b20 = r20 * a00 + r21 * a10 + r22 * a20, b21 = r20 * a01 + r21 * a11 + r22 * a21, b22 = r20 * a02 + r21 * a12 + r22 * a22;
    a00 = b00; a01 = b01; a02 = b02; a10 = b10; a11 = b11; a12 = b12; a20 = b20; a21 = b21; a22 = b22;
  }
  out[off] = a00; out[off + 1] = a01; out[off + 2] = a02; out[off + 3] = x;
  out[off + 4] = a10; out[off + 5] = a11; out[off + 6] = a12; out[off + 7] = y;
  out[off + 8] = a20; out[off + 9] = a21; out[off + 10] = a22; out[off + 11] = z;
}
/* загальна 3×4 з довільних кутів (для предмета в руці та частин тварин) */
function mat34e(out, off, x, y, z, rx, ry, rz, s) {
  var cx = Math.cos(rx), sx = Math.sin(rx), cy = Math.cos(ry), sy = Math.sin(ry), cz = Math.cos(rz), sz = Math.sin(rz);
  // R = Ry * Rx * Rz
  var m00 = cy * cz + sy * sx * sz, m01 = -cy * sz + sy * sx * cz, m02 = sy * cx;
  var m10 = cx * sz, m11 = cx * cz, m12 = -sx;
  var m20 = -sy * cz + cy * sx * sz, m21 = sy * sz + cy * sx * cz, m22 = cy * cx;
  s = s || 1;
  out[off] = m00 * s; out[off + 1] = m01 * s; out[off + 2] = m02 * s; out[off + 3] = x;
  out[off + 4] = m10 * s; out[off + 5] = m11 * s; out[off + 6] = m12 * s; out[off + 7] = y;
  out[off + 8] = m20 * s; out[off + 9] = m21 * s; out[off + 10] = m22 * s; out[off + 11] = z;
}
/* добуток двох 3×4 (a*b) */
function mul34(out, a, b) {
  var r = new Float32Array(12);
  for (var i = 0; i < 3; i++) {
    for (var j = 0; j < 3; j++) r[i * 4 + j] = a[i * 4] * b[j] + a[i * 4 + 1] * b[4 + j] + a[i * 4 + 2] * b[8 + j];
    r[i * 4 + 3] = a[i * 4] * b[3] + a[i * 4 + 1] * b[7] + a[i * 4 + 2] * b[11] + a[i * 4 + 3];
  }
  out.set(r); return out;
}

/* ---------- шейдери ---------- */
var HP = '#ifdef GL_FRAGMENT_PRECISION_HIGH\nprecision highp float;\n#else\nprecision mediump float;\n#endif\n';
var ATTR = ['aPos', 'aNor', 'aCol', 'aR0', 'aR1', 'aR2', 'aIC', 'aUV'];
function compile(type, src) {
  var s = gl.createShader(type); gl.shaderSource(s, src); gl.compileShader(s);
  if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) { var log = gl.getShaderInfoLog(s); throw new Error('shader: ' + log + '\n' + src.slice(0, 400)); }
  return s;
}
function mkProg(vs, fs, defs) {
  defs = defs || '';
  var p = gl.createProgram();
  gl.attachShader(p, compile(gl.VERTEX_SHADER, defs + vs));
  gl.attachShader(p, compile(gl.FRAGMENT_SHADER, HP + defs + fs));
  for (var i = 0; i < ATTR.length; i++) gl.bindAttribLocation(p, i, ATTR[i]);
  gl.linkProgram(p);
  if (!gl.getProgramParameter(p, gl.LINK_STATUS)) throw new Error('link: ' + gl.getProgramInfoLog(p));
  var u = {}, n = gl.getProgramParameter(p, gl.ACTIVE_UNIFORMS);
  for (var k = 0; k < n; k++) { var inf = gl.getActiveUniform(p, k); u[inf.name.replace(/\[0\]$/, '')] = gl.getUniformLocation(p, inf.name); }
  return { p: p, u: u, f: -1 };
}
var LIT_VS = [
  'attribute vec3 aPos; attribute vec3 aNor; attribute vec4 aCol;',
  'attribute vec4 aR0; attribute vec4 aR1; attribute vec4 aR2; attribute vec4 aIC;',
  'uniform mat4 uVP; uniform float uTime; uniform vec3 uWind;',
  'varying vec3 vC; varying vec3 vN; varying vec3 vW; varying float vE;',
  'void main(){',
  ' vec4 p = vec4(aPos,1.0);',
  ' vec3 w = vec3(dot(aR0,p), dot(aR1,p), dot(aR2,p));',
  ' float s = aCol.a * uWind.x;',
  ' float ph = uTime*uWind.y + w.x*0.21 + w.z*0.17;',
  ' w.x += (sin(ph) + 0.35*sin(ph*2.7)) * s * uWind.z; w.z += cos(ph*0.83) * s * 0.6;',
  ' vN = vec3(dot(aR0.xyz,aNor), dot(aR1.xyz,aNor), dot(aR2.xyz,aNor));',
  ' vC = aCol.rgb * aIC.rgb * 2.0; vE = aIC.a; vW = w;',
  ' gl_Position = uVP * vec4(w,1.0);',
  '}'].join('\n');
var LIT_FS = [
  'uniform vec3 uSunDir; uniform vec3 uSunCol; uniform vec3 uSky; uniform vec3 uGnd; uniform vec3 uFog; uniform float uFogD; uniform vec3 uCam;',
  'uniform vec4 uPL[4]; uniform vec3 uPC[4]; uniform float uDet; uniform float uHurt;',
  'varying vec3 vC; varying vec3 vN; varying vec3 vW; varying float vE;',
  'float hs(vec2 p){ return fract(sin(dot(p, vec2(12.9898,78.233)))*43758.5453); }',
  'void main(){',
  ' vec3 n = normalize(vN); if(!gl_FrontFacing) n = -n;',
  ' vec3 col = vC;',
  ' if(uDet > 0.0){ vec2 q=vW.xz*1.7; vec2 i=floor(q); vec2 f=fract(q); f=f*f*(3.0-2.0*f); float n=mix(mix(hs(i),hs(i+vec2(1.0,0.0)),f.x),mix(hs(i+vec2(0.0,1.0)),hs(i+vec2(1.0,1.0)),f.x),f.y); col *= 0.9 + 0.17*n + 0.04*hs(floor(vW.xz*9.0)); }',
  ' vec3 L = mix(uGnd, uSky, n.y*0.5+0.5);',
  ' L += uSunCol * max(dot(n, uSunDir), 0.0);',
  ' for(int i=0;i<4;i++){',
  '  vec3 lv = uPL[i].xyz - vW; float d = length(lv);',
  '  float a = clamp(1.0 - d/uPL[i].w, 0.0, 1.0);',
  '  L += uPC[i] * a*a * (0.35 + 0.65*max(dot(n, lv/max(d,0.001)), 0.0));',
  ' }',
  ' vec3 c = col * L + col * vE;',
  ' float fd = length(vW - uCam);',
  ' float f = clamp(1.0 - exp(-uFogD*uFogD*fd*fd), 0.0, 1.0);',
  ' gl_FragColor = vec4(mix(c, uFog, f), 1.0);',
  '}'].join('\n');

var DEC_VS = [
  'attribute vec3 aPos; attribute vec4 aR0; attribute vec4 aR1; attribute vec4 aR2; attribute vec4 aIC;',
  'uniform mat4 uVP; varying vec2 vL; varying float vA;',
  'void main(){ vec4 p=vec4(aPos,1.0); vec3 w=vec3(dot(aR0,p),dot(aR1,p),dot(aR2,p)); vL=aPos.xz*2.0; vA=aIC.a; gl_Position=uVP*vec4(w,1.0); }'].join('\n');
var DEC_FS = 'uniform float uA; varying vec2 vL; varying float vA; void main(){ float d=length(vL); float a=(1.0-smoothstep(0.35,1.0,d))*uA*vA; gl_FragColor=vec4(0.02,0.03,0.02,a); }';

var PT_VS = [
  'attribute vec3 aPos; attribute vec4 aCol; attribute vec2 aUV;',
  'uniform mat4 uVP; uniform vec3 uCam; uniform float uPS; uniform float uPM; varying vec4 vC; varying float vSoft;',
  'void main(){ vC=aCol; vSoft=aUV.y; gl_Position=uVP*vec4(aPos,1.0); float d=max(length(aPos-uCam),0.25); gl_PointSize=clamp(aUV.x*uPS/d,1.0,uPM); }'].join('\n');
var PT_FS = 'varying vec4 vC; varying float vSoft; void main(){ vec2 c=gl_PointCoord-0.5; float a=1.0-smoothstep(0.5-0.45*vSoft,0.5,length(c)); if(a<0.01) discard; gl_FragColor=vec4(vC.rgb, vC.a*a); }';

var LN_VS = 'attribute vec3 aPos; attribute vec4 aCol; uniform mat4 uVP; varying vec4 vC; void main(){ vC=aCol; gl_Position=uVP*vec4(aPos,1.0); }';
var LN_FS = 'varying vec4 vC; void main(){ gl_FragColor=vC; }';

var WAT_VS = 'attribute vec3 aPos; uniform mat4 uVP; varying vec3 vW; void main(){ vW=aPos; gl_Position=uVP*vec4(aPos,1.0); }';
var WAT_FS = [
  'uniform float uTime; uniform vec3 uCam; uniform vec3 uSunDir; uniform vec3 uSunCol; uniform vec3 uSky; uniform vec3 uGnd; uniform vec3 uHorz; uniform vec3 uZen;',
  'uniform vec3 uFog; uniform float uFogD; uniform float uRain; uniform vec4 uRip[4]; uniform vec4 uPL[4]; uniform vec3 uPC[4];',
  'varying vec3 vW;',
  'float hs(vec2 p){ return fract(sin(dot(p, vec2(12.9898,78.233)))*43758.5453); }',
  'void main(){',
  ' vec2 p=vW.xz; float t=uTime;',
  ' vec2 g = vec2(cos(p.x*1.3+t*1.1)+0.6*cos(p.x*0.7+p.y*0.9+t*0.6), cos(p.y*1.1-t*0.9)+0.6*cos(p.y*0.6-p.x*0.8-t*0.7))*0.045;',
  ' g += vec2(cos(p.x*3.7+p.y*2.1+t*2.6), cos(p.y*3.3-p.x*1.9+t*2.2))*0.02;',
  ' if(uRain>0.0){ vec2 cell=floor(p*3.0); float ph=hs(cell); float a=fract(t*1.3+ph); vec2 c=(cell+0.5)/3.0; vec2 dv=p-c; float d=length(dv);',
  '   g += dv/(d+0.001)*sin(d*40.0-a*10.0)*(1.0-a)*smoothstep(0.17,0.0,d)*0.12*uRain; }',
  ' for(int i=0;i<4;i++){ vec2 dv=p-uRip[i].xy; float d=length(dv); float age=uRip[i].z; float r=age*1.6;',
  '   g += dv/(d+0.001)*sin((d-r)*9.0)*exp(-age*1.4)*smoothstep(r+0.6,r,d)*0.18*uRip[i].w; }',
  ' vec3 n=normalize(vec3(-g.x,1.0,-g.y));',
  ' vec3 v=normalize(uCam-vW);',
  ' float fr=0.03+0.97*pow(1.0-max(dot(n,v),0.0),5.0);',
  ' vec3 rd=reflect(-v,n);',
  ' vec3 refl=mix(uHorz,uZen,clamp(rd.y*1.6,0.0,1.0));',
  ' vec3 L=mix(uGnd,uSky,0.8)+uSunCol*0.4;',
  ' for(int i=0;i<4;i++){ vec3 lv=uPL[i].xyz-vW; float d=length(lv); float a=clamp(1.0-d/uPL[i].w,0.0,1.0); L+=uPC[i]*a*a*0.5; refl+=uPC[i]*a*a*0.35; }',
  ' vec3 deep=vec3(0.035,0.11,0.12)*L*1.6;',
  ' vec3 c=mix(deep,refl,fr);',
  ' float sp=pow(max(dot(rd,uSunDir),0.0),160.0); c+=uSunCol*sp*2.0;',
  ' float fd=length(vW-uCam); float f=clamp(1.0-exp(-uFogD*uFogD*fd*fd),0.0,1.0);',
  ' gl_FragColor=vec4(mix(c,uFog,f), mix(0.72,0.97,fr));',
  '}'].join('\n');

var TEX_VS = 'attribute vec3 aPos; attribute vec2 aUV; attribute vec4 aR0; attribute vec4 aR1; attribute vec4 aR2; uniform mat4 uVP; varying vec2 vU; varying vec3 vW; void main(){ vec4 p=vec4(aPos,1.0); vW=vec3(dot(aR0,p),dot(aR1,p),dot(aR2,p)); vU=aUV; gl_Position=uVP*vec4(vW,1.0); }';
var TEX_FS = 'uniform sampler2D uTex; uniform vec3 uSky; uniform vec3 uSunCol; uniform vec3 uFog; uniform float uFogD; uniform vec3 uCam; uniform vec4 uPL[4]; uniform vec3 uPC[4]; varying vec2 vU; varying vec3 vW; void main(){ vec4 t=texture2D(uTex,vU); vec3 L=uSky*0.9+uSunCol*0.55; for(int i=0;i<4;i++){ vec3 lv=uPL[i].xyz-vW; float a=clamp(1.0-length(lv)/uPL[i].w,0.0,1.0); L+=uPC[i]*a*a; } vec3 c=t.rgb*L; float fd=length(vW-uCam); float f=clamp(1.0-exp(-uFogD*uFogD*fd*fd),0.0,1.0); gl_FragColor=vec4(mix(c,uFog,f),1.0); }';

/* ---------- буфери та сітки ---------- */
function glBuf(data, dyn) { var b = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, b); gl.bufferData(gl.ARRAY_BUFFER, data, dyn ? gl.DYNAMIC_DRAW : gl.STATIC_DRAW); return b; }
function Mesh(g) {
  this.n = g.n; this.mode = g.mode === undefined ? gl.TRIANGLES : g.mode;
  this.bp = glBuf(g.pos); this.bn = g.nor ? glBuf(g.nor) : null; this.bc = g.col ? glBuf(g.col) : null; this.bu = g.uv ? glBuf(g.uv) : null;
  this.bs = g.bs || [0, 0, 0, 1e6]; this.cull = g.cull === undefined ? true : g.cull;
}
/* динамічна сітка для частинок/ліній (оновлюється кожен кадр) */
function DynMesh(max, mode, withUV) {
  this.max = max; this.n = 0; this.mode = mode;
  this.pos = new Float32Array(max * 3); this.col = new Uint8Array(max * 4); this.uv = withUV ? new Float32Array(max * 2) : null;
  this.bp = glBuf(this.pos, true); this.bc = glBuf(this.col, true); this.bu = withUV ? glBuf(this.uv, true) : null;
}
DynMesh.prototype.upload = function () {
  if (!this.n) return;
  gl.bindBuffer(gl.ARRAY_BUFFER, this.bp); gl.bufferSubData(gl.ARRAY_BUFFER, 0, this.pos.subarray(0, this.n * 3));
  gl.bindBuffer(gl.ARRAY_BUFFER, this.bc); gl.bufferSubData(gl.ARRAY_BUFFER, 0, this.col.subarray(0, this.n * 4));
  if (this.bu) { gl.bindBuffer(gl.ARRAY_BUFFER, this.bu); gl.bufferSubData(gl.ARRAY_BUFFER, 0, this.uv.subarray(0, this.n * 2)); }
};
/* буфер екземплярів: 3 рядки матриці + колір (rgb множник/2, a — світіння) */
function IB(n) {
  this.n = n; this.m = new Float32Array(n * 12); this.c = new Uint8Array(n * 4);
  for (var i = 0; i < n; i++) { this.c[i * 4] = this.c[i * 4 + 1] = this.c[i * 4 + 2] = 128; this.c[i * 4 + 3] = 0; }
  this.bm = glBuf(this.m, true); this.bc = glBuf(this.c, true); this.dm = true; this.dc = true;
}
IB.prototype.set = function (i, x, y, z, ry, sx, sy, sz, tilt, dx, dz) { mat34(this.m, i * 12, x, y, z, ry, sx, sy === undefined ? sx : sy, sz === undefined ? sx : sz, tilt || 0, dx || 0, dz || 1); this.dm = true; };
IB.prototype.setM = function (i, m12) { this.m.set(m12, i * 12); this.dm = true; };
IB.prototype.hide = function (i) { for (var k = 0; k < 12; k++) this.m[i * 12 + k] = 0; this.dm = true; };
IB.prototype.tint = function (i, r, g, b, e) { var o = i * 4; this.c[o] = clamp(r * 128, 0, 255); this.c[o + 1] = clamp(g * 128, 0, 255); this.c[o + 2] = clamp(b * 128, 0, 255); this.c[o + 3] = clamp((e || 0) * 255, 0, 255); this.dc = true; };
IB.prototype.upload = function () {
  if (this.dm) { gl.bindBuffer(gl.ARRAY_BUFFER, this.bm); gl.bufferSubData(gl.ARRAY_BUFFER, 0, this.m); this.dm = false; }
  if (this.dc) { gl.bindBuffer(gl.ARRAY_BUFFER, this.bc); gl.bufferSubData(gl.ARRAY_BUFFER, 0, this.c); this.dc = false; }
};

/* ---------- стан атрибутів ---------- */
var aOn = [false, false, false, false, false, false, false, false], aDiv = [0, 0, 0, 0, 0, 0, 0, 0];
function aEn(l, on) { if (aOn[l] !== on) { if (on) gl.enableVertexAttribArray(l); else gl.disableVertexAttribArray(l); aOn[l] = on; } }
function aDv(l, d) { if (EXT.inst && aDiv[l] !== d) { EXT.inst.vertexAttribDivisorANGLE(l, d); aDiv[l] = d; } }
function bindAttr(l, buf, size, type, norm, stride, off) { gl.bindBuffer(gl.ARRAY_BUFFER, buf); aEn(l, true); aDv(l, 0); gl.vertexAttribPointer(l, size, type, norm, stride || 0, off || 0); }
var ID34 = new Float32Array([1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0]);
function constRows(m, o) {
  o = o || 0; aEn(3, false); aEn(4, false); aEn(5, false);
  gl.vertexAttrib4f(3, m[o], m[o + 1], m[o + 2], m[o + 3]); gl.vertexAttrib4f(4, m[o + 4], m[o + 5], m[o + 6], m[o + 7]); gl.vertexAttrib4f(5, m[o + 8], m[o + 9], m[o + 10], m[o + 11]);
}
function constTint(r, g, b, e) { aEn(6, false); gl.vertexAttrib4f(6, r * 0.5, g * 0.5, b * 0.5, e || 0); }
function bindMesh(me) {
  bindAttr(0, me.bp, 3, gl.FLOAT, false);
  if (me.bn) bindAttr(1, me.bn, 3, gl.BYTE, true); else { aEn(1, false); gl.vertexAttrib3f(1, 0, 1, 0); }
  if (me.bc) bindAttr(2, me.bc, 4, gl.UNSIGNED_BYTE, true); else { aEn(2, false); gl.vertexAttrib4f(2, 1, 1, 1, 0); }
  if (me.bu) bindAttr(7, me.bu, 2, gl.FLOAT, false); else aEn(7, false);
}
/* малювання сітки: окремо (rows = 3×4) або екземплярами (ib) */
function drawMesh(me, ib, rows, tint) {
  bindMesh(me);
  if (ib) {
    ib.upload();
    if (EXT.inst) {
      gl.bindBuffer(gl.ARRAY_BUFFER, ib.bm);
      for (var r = 0; r < 3; r++) { aEn(3 + r, true); gl.vertexAttribPointer(3 + r, 4, gl.FLOAT, false, 48, r * 16); aDv(3 + r, 1); }
      gl.bindBuffer(gl.ARRAY_BUFFER, ib.bc); aEn(6, true); gl.vertexAttribPointer(6, 4, gl.UNSIGNED_BYTE, true, 0, 0); aDv(6, 1);
      EXT.inst.drawArraysInstancedANGLE(me.mode, 0, me.n, ib.n);
      for (var k = 3; k <= 6; k++) aDv(k, 0);
    } else {
      for (var i = 0; i < ib.n; i++) {
        if (ib.m[i * 12] === 0 && ib.m[i * 12 + 5] === 0) continue;
        constRows(ib.m, i * 12); var o = i * 4; aEn(6, false); gl.vertexAttrib4f(6, ib.c[o] / 255, ib.c[o + 1] / 255, ib.c[o + 2] / 255, ib.c[o + 3] / 255);
        gl.drawArrays(me.mode, 0, me.n);
      }
    }
  } else {
    constRows(rows || ID34, 0);
    if (tint) constTint(tint[0], tint[1], tint[2], tint[3]); else constTint(1, 1, 1, 0);
    gl.drawArrays(me.mode, 0, me.n);
  }
}

/* ---------- кадр: камера, фрустум, спільні uniform-и ---------- */
var CAM = { x: 0, y: 1.7, z: 0, yaw: 0, pitch: 0, roll: 0, fov: 1.25, near: 0.06, far: 260, P: m4(), V: m4(), VP: m4(), R: null, planes: [] };
var ENV = {
  sunDir: [0.3, 0.8, 0.2], sunCol: [1, 0.95, 0.85], sky: [0.5, 0.6, 0.75], gnd: [0.25, 0.22, 0.15], fog: [0.6, 0.7, 0.8], fogD: 0.008,
  zen: [0.2, 0.4, 0.8], horz: [0.6, 0.75, 0.9], wind: [1, 1.5, 1], time: 0, rain: 0, hurt: 0,
  pl: new Float32Array(16), pc: new Float32Array(12), rip: new Float32Array(16)
};
function camUpdate(w, h) {
  m4persp(CAM.P, CAM.fov, w / h, CAM.near, CAM.far);
  CAM.R = m4view(CAM.V, CAM.x, CAM.y, CAM.z, CAM.yaw, CAM.pitch, CAM.roll);
  m4mul(CAM.VP, CAM.P, CAM.V);
  var m = CAM.VP, p = CAM.planes; p.length = 0;
  var rows = [[m[3] + m[0], m[7] + m[4], m[11] + m[8], m[15] + m[12]], [m[3] - m[0], m[7] - m[4], m[11] - m[8], m[15] - m[12]],
  [m[3] + m[1], m[7] + m[5], m[11] + m[9], m[15] + m[13]], [m[3] - m[1], m[7] - m[5], m[11] - m[9], m[15] - m[13]],
  [m[3] + m[2], m[7] + m[6], m[11] + m[10], m[15] + m[14]], [m[3] - m[2], m[7] - m[6], m[11] - m[10], m[15] - m[14]]];
  for (var i = 0; i < 6; i++) { var r = rows[i], l = Math.sqrt(r[0] * r[0] + r[1] * r[1] + r[2] * r[2]); p.push([r[0] / l, r[1] / l, r[2] / l, r[3] / l]); }
}
function inView(bs) {
  if (bs[3] > 1e5) return true;
  for (var i = 0; i < 6; i++) { var p = CAM.planes[i]; if (p[0] * bs[0] + p[1] * bs[1] + p[2] * bs[2] + p[3] < -bs[3]) return false; }
  return true;
}
function useProg(pr) {
  gl.useProgram(pr.p);
  if (pr.f === GLP.frame) return pr.u;
  pr.f = GLP.frame; var u = pr.u;
  if (u.uVP) gl.uniformMatrix4fv(u.uVP, false, CAM.VP);
  if (u.uCam) gl.uniform3f(u.uCam, CAM.x, CAM.y, CAM.z);
  if (u.uTime) gl.uniform1f(u.uTime, ENV.time);
  if (u.uWind) gl.uniform3fv(u.uWind, ENV.wind);
  if (u.uSunDir) gl.uniform3fv(u.uSunDir, ENV.sunDir);
  if (u.uSunCol) gl.uniform3fv(u.uSunCol, ENV.sunCol);
  if (u.uSky) gl.uniform3fv(u.uSky, ENV.sky);
  if (u.uGnd) gl.uniform3fv(u.uGnd, ENV.gnd);
  if (u.uFog) gl.uniform3fv(u.uFog, ENV.fog);
  if (u.uFogD) gl.uniform1f(u.uFogD, ENV.fogD);
  if (u.uHorz) gl.uniform3fv(u.uHorz, ENV.horz);
  if (u.uZen) gl.uniform3fv(u.uZen, ENV.zen);
  if (u.uRain) gl.uniform1f(u.uRain, ENV.rain);
  if (u.uPL) gl.uniform4fv(u.uPL, ENV.pl);
  if (u.uPC) gl.uniform3fv(u.uPC, ENV.pc);
  if (u.uRip) gl.uniform4fv(u.uRip, ENV.rip);
  if (u.uDet) gl.uniform1f(u.uDet, 0);
  return u;
}
var PR = {};
function glPrograms() {
  PR.lit = mkProg(LIT_VS, LIT_FS);
  PR.dec = mkProg(DEC_VS, DEC_FS);
  PR.pt = mkProg(PT_VS, PT_FS);
  PR.ln = mkProg(LN_VS, LN_FS);
  PR.wat = mkProg(WAT_VS, WAT_FS);
  PR.tex = mkProg(TEX_VS, TEX_FS);
}
/* текстура з canvas (для записок/табличок) */
function texFromCanvas(cv) {
  var t = gl.createTexture(); gl.bindTexture(gl.TEXTURE_2D, t);
  gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, cv);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
  return t;
}
