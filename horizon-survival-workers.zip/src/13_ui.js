/* =====================================================================
   ІНТЕРФЕЙС: HUD, повідомлення, рюкзак і майстрування, багаття,
   щоденник/рація, записки, люк, налаштування, пауза, мова
   ===================================================================== */
var cap = function (s) { return s.charAt(0).toUpperCase() + s.slice(1); };
function fmtT(m) { return pad2(Math.floor(m / 60) % 24) + ':' + pad2(m % 60); }
function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }

/* ---------- повідомлення ---------- */
var lastToast = '', lastToastT = 0;
function toast(text, icon, kind) {
  var e = $('toast'); if (!e) return;
  if (text === lastToast && G.t - lastToastT < 1.5) return; lastToast = text; lastToastT = G.t;
  var d = document.createElement('div'); d.className = 'tt ' + (kind || '');
  d.innerHTML = (icon ? svgI(icon) : '') + '<span>' + esc(text) + '</span>'; e.appendChild(d);
  while (e.children.length > 4) e.removeChild(e.firstChild);
  setTimeout(function () { d.className += ' out'; setTimeout(function () { if (d.parentNode) d.parentNode.removeChild(d); }, 450); }, 3800);
}
var subT = 0;
function subtitle(text, sec) { var e = $('sub'); e.textContent = text; e.className = 'show'; clearTimeout(subT); subT = setTimeout(function () { e.className = ''; }, (sec || 6) * 1000); }
var tipT = 0, tipShow = 0;
function tipStep(dt) {
  if (tipShow > 0) { tipShow -= dt; if (tipShow <= 0) $('tipBox').className = ''; return; }
  if (!tipQ.length || UI.ov) return;
  var id = tipQ.shift(), k = 'tip.' + (id === 'move' && touchMode ? 'moveT' : id);
  $('tipBox').innerHTML = svgI('info') + '<span>' + esc(t(k)) + '</span>'; $('tipBox').className = 'show'; tipShow = 9;
}
function fadeBlack(cb, hold) {
  var f = $('flash'); f.style.transition = 'opacity .7s'; f.style.webkitTransition = 'opacity .7s'; f.style.opacity = 1;
  setTimeout(function () { try { cb(); } catch (e) { console.error(e); } setTimeout(function () { f.style.opacity = 0; }, hold || 500); }, 750);
}
function giveItems(list) {
  for (var i = 0; i < list.length; i++) if (!canAdd(list[i][0], list[i][1])) { AU.error(); toast(t('msg.full'), 'bag', 'bad'); return false; }
  list.forEach(function (e) { addItem(e[0], e[1]); });
  AU.pickup(); toast(t('msg.found', { x: list.map(function (e) { return iname(e[0]) + (e[1] > 1 ? ' ×' + e[1] : ''); }).join(', ') }), list[0][0]);
  return true;
}

/* ---------- комірки ---------- */
function itemHTML(s) {
  if (!s) return '';
  var d = ITEMS[s.id], h = '<span class="ic">' + svgI(s.id) + '</span>' + (s.n > 1 ? '<span class="ct">' + s.n + '</span>' : '');
  if (d.dur && s.d !== undefined) h += '<span class="du"><u style="width:' + Math.round(100 * s.d / d.dur) + '%"></u></span>';
  else if (d.rot && s.b !== undefined) { var fk = freshK(s); if (fk < 0.999) h += '<span class="du fr"><u style="width:' + Math.round(100 * fk) + '%"></u></span>'; }
  return h;
}
var SEL = null; // вибраний предмет для перекладання {a,i}
var arrOf = function (a) { return a === 'inv' ? inv.slots : inv.craft; };
function selStack() { return SEL ? arrOf(SEL.a)[SEL.i] || null : null; }
function renderSlots(el, arr, start, count, name) {
  var h = '';
  for (var k = 0; k < count; k++) { var idx = start + k; h += '<div class="slot' + (SEL && SEL.a === name && SEL.i === idx ? ' sel' : '') + (arr[idx] ? ' has' : '') + '" data-a="' + name + '" data-i="' + idx + '">' + itemHTML(arr[idx]) + '</div>'; }
  el.innerHTML = h;
}
function renderHot() {
  var h = '';
  for (var i = 0; i < 9; i++) h += '<div class="hs' + (i === inv.sel ? ' sel' : '') + '" data-i="' + i + '"><span class="hn">' + (i + 1) + '</span>' + itemHTML(inv.slots[i]) + '</div>';
  $('hotbar').innerHTML = h;
  var s = inv.slots[inv.sel]; $('selname').textContent = s ? iname(s.id) : '';
  var tu = $('tUse'); if (tu) tu.innerHTML = s ? svgI(s.id) : svgI('hand');
}
function refreshUI() { if (!$('hotbar')) return; renderHot(); if (UI.ov === 'inv') renderInv(); if (UI.ov === 'fire') renderFire(); }

/* ---------- майстрування з часом ---------- */
var CS = { on: false, p: 0, r: null, tk: 0 };
function cancelCraft() { if (CS.on) { CS.on = false; CS.p = 0; var pg = document.querySelector('#outSlot .pg'); if (pg) pg.style.width = '0'; } }
function haveFor(r) {
  var need = {}; r.items.forEach(function (id) { need[id] = (need[id] || 0) + 1; });
  return Object.keys(need).every(function (id) { var inC = 0; inv.craft.forEach(function (s) { if (s && s.id === id) inC += s.n; }); return countItem(id) + inC >= need[id]; });
}
function miniPat(r) { var h = '<span class="mp">'; for (var i = 0; i < 2; i++) for (var j = 0; j < 2; j++) { var id = r.grid[i] ? r.grid[i][j] : null; h += '<b>' + (id ? svgI(id) : '') + '</b>'; } return h + '</span>'; }
function renderInv() {
  renderSlots($('invGrid'), inv.slots, 9, 27, 'inv'); renderSlots($('invHot'), inv.slots, 0, 9, 'inv'); renderSlots($('craftGrid'), inv.craft, 0, 4, 'craft');
  var o = $('outSlot'), r = curRecipe();
  o.className = 'slot out' + (r ? ' ready' : '') + (CS.on ? ' busy' : ''); o.setAttribute('data-a', 'out'); o.setAttribute('data-i', '0');
  o.innerHTML = (r ? (G.known[r.id] ? '<span class="ic">' + svgI(r.out[0]) + '</span>' : '<span class="ic q">?</span>') : '') + '<i class="pg" style="width:' + (CS.on ? Math.round(100 * CS.p / CS.r.time) : 0) + '%"></i>';
  var h = '';
  RECIPES.forEach(function (r2, k) {
    var kn = G.known[r2.id];
    h += '<div class="rc' + (kn ? ' known' : ' locked') + (kn && haveFor(r2) ? ' ok' : '') + '" data-r="' + k + '">' + (kn
      ? miniPat(r2) + '<span class="ro">' + svgI(r2.out[0]) + '</span><em>' + esc(iname(r2.out[0])) + (r2.need ? '<small>' + esc(t('inv.needFire')) + '</small>' : '') + '</em>'
      : '<span class="lk">' + svgI('lock') + '</span><em>' + esc(t('inv.unknown')) + '<small>' + esc(t('rh.' + r2.id)) + '</small></em>') + '</div>';
  });
  $('recipes').innerHTML = h;
  var ss = selStack(), tipE = $('itemTip');
  tipE.innerHTML = ss ? itemInfo(ss) + '<br><span style="opacity:.7">' + esc(t('inv.selected', { x: iname(ss.id) })) + '</span>' : esc(t('inv.tipEmpty'));
  $('invwrap').className = 'invwrap' + (ss ? ' picking' : '');
  var b = '';
  if (ss && SEL.a === 'inv') {
    var d = ITEMS[ss.id];
    if (d.f !== undefined || d.w !== undefined || d.use) b += '<button class="btn sm" id="ibUse">' + svgI(d.f !== undefined ? 'eat' : 'hand') + esc(t('btn.use')) + '</button>';
    b += '<button class="btn sm" id="ibDrop">' + esc(t('btn.drop')) + '</button>';
  }
  $('invBtns').innerHTML = b;
}
function itemInfo(s) {
  var d = ITEMS[s.id], h = '<b>' + esc(iname(s.id)) + '</b> — ' + esc(idesc(s.id));
  if (d.dur && s.d !== undefined) h += ' <span style="opacity:.75">(' + esc(t('inv.dur')) + ': ' + s.d + '/' + d.dur + ')</span>';
  if (d.rot && s.b !== undefined) { var fk = freshK(s); h += ' <span style="opacity:.75">(' + esc(t('inv.fresh')) + ': ' + esc(t(fk > 0.6 ? 'fr.fresh' : fk > 0.25 ? 'fr.stale' : 'fr.bad')) + ')</span>'; }
  return h;
}
function returnAll() {
  cancelCraft(); SEL = null;
  for (var i = 0; i < 4; i++) { var s = inv.craft[i]; if (s) { if (!putStack(s)) { addNodeDrop(P.x, P.z, s.id, s.n); toast(t('msg.dropped', { x: iname(s.id) }), s.id, 'bad'); } inv.craft[i] = null; } }
}
function quickMove(i) {
  var s = inv.slots[i]; if (!s) return;
  var range = i < 9 ? [9, 36] : [0, 9], st = ITEMS[s.id].s;
  if (s.d === undefined) for (var k = range[0]; k < range[1] && s.n > 0; k++) { var tt = inv.slots[k]; if (tt && tt.id === s.id && tt.n < st) { var m = Math.min(s.n, st - tt.n); tt.n += m; s.n -= m; } }
  for (var k2 = range[0]; k2 < range[1] && s.n > 0; k2++) { if (!inv.slots[k2]) { inv.slots[k2] = cloneSt(s, s.n); s.n = 0; } }
  if (s.n <= 0) inv.slots[i] = null;
}
function slotClick(a, i, right, shift) {
  if (a === 'out') { SEL = null; clickOutput(); renderInv(); return; }
  cancelCraft();
  var arr = arrOf(a), s = arr[i]; AU.click();
  if (!SEL) { if (s) { if (shift && a === 'inv') quickMove(i); else SEL = { a: a, i: i }; } refreshUI(); renderInv(); return; }
  var sa = arrOf(SEL.a), si = SEL.i, src = sa[si];
  if (!src || (SEL.a === a && si === i)) { SEL = null; refreshUI(); renderInv(); return; }
  if (a === 'craft' && SEL.a === 'inv') { // у сітку — по одному, вибір лишається
    if (s && !stackable(s, src)) { if (!putStack(s)) { AU.error(); return; } arr[i] = null; s = null; }
    if (!s) { arr[i] = cloneSt(src, 1); src.n--; } else if (s.n < ITEMS[s.id].s) { s.n++; src.n--; }
    if (src.n <= 0) { sa[si] = null; SEL = null; }
    refreshUI(); renderInv(); return;
  }
  if (right) {
    if (!s) { arr[i] = cloneSt(src, 1); src.n--; }
    else if (stackable(s, src) && s.n < ITEMS[s.id].s) { s.n++; src.n--; }
    else { AU.error(); return; }
    if (src.n <= 0) { sa[si] = null; SEL = null; }
  } else if (!s) { arr[i] = src; sa[si] = null; SEL = null; }
  else if (stackable(s, src)) { var tk = Math.min(src.n, ITEMS[s.id].s - s.n); s.n += tk; src.n -= tk; if (s.b !== undefined && src.b !== undefined) s.b = Math.min(s.b, src.b); if (src.n <= 0) { sa[si] = null; SEL = null; } }
  else { arr[i] = src; sa[si] = s; SEL = null; }
  refreshUI(); renderInv();
}
function clickOutput() {
  if (CS.on) { cancelCraft(); AU.click(); return; }
  var r = curRecipe(); if (!r) { AU.error(); return; }
  if (r.need === 'fire' && !nearFire(5)) { AU.error(); toast(t('msg.craftFire'), 'flame', 'bad'); return; }
  if (!canAdd(r.out[0], r.out[1])) { AU.error(); toast(t('msg.full'), 'bag', 'bad'); return; }
  CS.on = true; CS.p = 0; CS.r = r; CS.tk = 0; AU.click();
}
function craftStep(dt) {
  if (!CS.on) return;
  if (curRecipe() !== CS.r || UI.ov !== 'inv') { cancelCraft(); return; }
  CS.p += dt; CS.tk -= dt; if (CS.tk <= 0) { CS.tk = 0.4; AU.drillTick(); }
  var pg = document.querySelector('#outSlot .pg'); if (pg) pg.style.width = Math.min(100, Math.round(100 * CS.p / CS.r.time)) + '%';
  if (CS.p >= CS.r.time) finishCraft();
}
function finishCraft() {
  var r = CS.r; CS.on = false; CS.p = 0;
  if (curRecipe() !== r) { renderInv(); return; }
  if (Math.random() < r.fail) {
    var filled = [0, 1, 2, 3].filter(function (i) { return inv.craft[i]; }), k = filled[Math.floor(Math.random() * filled.length)], s = inv.craft[k], id = s.id;
    s.n--; if (s.n <= 0) inv.craft[k] = null; AU.error(); toast(t('msg.craftFail', { x: iname(id) }), id, 'bad'); renderInv(); refreshUI(); return;
  }
  consumeCraft(); addItem(r.out[0], r.out[1]);
  var first = !G.known[r.id]; G.known[r.id] = 1; G.flags['c_' + r.id] = 1;
  AU.craft(); toast(first ? t('msg.craftNew', { x: iname(r.out[0]) }) : t('msg.crafted', { x: iname(r.out[0]) }), r.out[0], first ? 'good' : '');
  if (r.id === 'axe') tip('axe');
  renderInv(); refreshUI();
}
function autoFill(r) {
  cancelCraft(); returnAll();
  if (!haveFor(r)) { AU.error(); var miss = r.items.filter(function (id) { return !countItem(id); }).map(iname).filter(function (v, i, a) { return a.indexOf(v) === i; }); toast(t('msg.missing', { x: miss.join(', ') || '…' }), 'bag', 'bad'); refreshUI(); return; }
  for (var i = 0; i < r.grid.length; i++) for (var j = 0; j < 2; j++) { var id = r.grid[i][j]; if (id) { var si = -1; for (var k = 35; k >= 0; k--) if (inv.slots[k] && inv.slots[k].id === id) { si = k; break; } var s = inv.slots[si]; inv.craft[i * 2 + j] = cloneSt(s, 1); s.n--; if (s.n <= 0) inv.slots[si] = null; } }
  AU.click(); refreshUI();
}
function bindInv() {
  var ov = $('ovInv');
  ov.addEventListener('click', function (e) {
    var tg = e.target, rc = tg.closest ? tg.closest('.rc') : null;
    if (rc) { var r = RECIPES[+rc.getAttribute('data-r')]; if (G.known[r.id]) autoFill(r); else { AU.click(); toast(t('inv.unknownTap'), 'lock'); } return; }
    if (tg.closest('#ibUse')) { var i = SEL.i; SEL = null; closeOvSilent(); inv.sel = i < 9 ? i : inv.sel; if (i >= 9) { var tmp = inv.slots[inv.sel]; inv.slots[inv.sel] = inv.slots[i]; inv.slots[i] = tmp; } useHeld(); return; }
    if (tg.closest('#ibDrop')) { var s2 = selStack(); if (s2) { arrOf(SEL.a)[SEL.i] = null; addNodeDrop(P.x - Math.sin(P.yaw) * 0.8, P.z - Math.cos(P.yaw) * 0.8, s2.id, s2.n); toast(t('msg.dropped', { x: iname(s2.id) }), s2.id); SEL = null; refreshUI(); renderInv(); } return; }
    var sl = tg.closest('.slot'); if (sl) slotClick(sl.getAttribute('data-a'), +sl.getAttribute('data-i'), false, e.shiftKey);
  });
  ov.addEventListener('contextmenu', function (e) { e.preventDefault(); var sl = e.target.closest('.slot'); if (sl) slotClick(sl.getAttribute('data-a'), +sl.getAttribute('data-i'), true, false); });
  ov.addEventListener('mousemove', function (e) {
    if (SEL) return; var sl = e.target.closest ? e.target.closest('.slot') : null, tipE = $('itemTip'); if (!sl) return;
    var a = sl.getAttribute('data-a');
    if (a !== 'out') { var it = arrOf(a)[+sl.getAttribute('data-i')]; tipE.innerHTML = it ? itemInfo(it) : esc(t('inv.tipEmpty')); }
    else { var r = curRecipe(); tipE.innerHTML = r ? (G.known[r.id] ? itemInfo({ id: r.out[0], n: 1 }) : esc(t('inv.try'))) : esc(t('inv.put')); }
  });
  function hotPick(e) { var h = e.target.closest ? e.target.closest('.hs') : null; if (!h) return; inv.sel = +h.getAttribute('data-i'); refreshUI(); AU.click(); e.stopPropagation(); if (e.cancelable) e.preventDefault(); }
  $('hotbar').addEventListener('touchstart', hotPick); $('hotbar').addEventListener('mousedown', hotPick);
}

/* ---------- панелі ---------- */
function openOv(n, arg) {
  if (UI.ov) closeOvSilent();
  UI.ov = n; UI.arg = arg; $('ov' + cap(n)).classList.remove('hide');
  try { if (document.pointerLockElement) document.exitPointerLock(); } catch (e) { }
  INP.held = false; keys = {}; joy.x = joy.y = 0;
  if (n === 'inv') { SEL = null; renderInv(); AU.open(); }
  if (n === 'fire') renderFire();
  if (n === 'journal') { UI.tab = arg || UI.tab || 'goals'; renderJournal(); AU.open(); }
  if (n === 'note') { $('noteT').textContent = t('note.' + arg + '.t'); $('noteB').textContent = noteText(arg); }
  if (n === 'hatch') { KEY.s = ''; renderHatch(); }
  if (n === 'settings') renderSettings();
}
function closeOvSilent() { if (!UI.ov) return; if (UI.ov === 'inv') returnAll(); $('ov' + cap(UI.ov)).classList.add('hide'); UI.ov = null; refreshUI(); }
function closeOv() {
  if (!UI.ov || UI.ov === 'end') return;
  var was = UI.ov; closeOvSilent();
  if (was === 'settings' && !G.started) return;
  if (was === 'help' && !G.started) return;
}
/* багаття */
function renderFire() {
  var f = UI.arg; if (!f) return;
  var stt = f.st === 'lit' ? t('fire.burning') : f.st === 'embers' ? t('fire.embers') : t('fire.out'), fk = clamp(f.fuel / 600, 0, 1);
  var h = '<div class="fstat">' + svgI('flame') + '<span style="margin-left:6px">' + esc(t('fire.fuel')) + '</span><div class="bar"><u style="width:' + Math.round(fk * 100) + '%"></u></div><b>' + esc(stt) + '</b></div>';
  if (f.st === 'lit') h += '<p style="font-size:12.5px;opacity:.75;margin:4px 0 8px">' + esc(t('fire.warm')) + (WX.rain > 0.3 && !underRoof(f.x, f.z) ? ' ' + esc(t('fire.rain')) : '') + '</p>';
  if (f.cook) h += '<div>' + esc(t('fire.cooking', { x: f.cook.kind === 'cook' ? iname(f.cook.id) : f.cook.kind === 'boil' ? iname('can_raw') : iname('can_tea') })) + '</div><div class="cookp"><u id="cookBar" style="width:' + Math.round(100 * f.cook.t / f.cook.dur) + '%"></u></div>';
  var lit = f.st === 'lit', busy = !!f.cook;
  function btn(act, icon, label, ok, cnt) { return '<button class="btn fa" data-fa="' + act + '"' + (ok ? '' : ' disabled') + '>' + svgI(icon) + esc(label) + (cnt !== undefined ? '<small>×' + cnt + '</small>' : '') + '</button>'; }
  h += btn('stick', 'stick', t('fire.addStick'), hasItem('stick') && f.st !== 'ash', countItem('stick'));
  h += btn('log', 'log', t('fire.addLog'), hasItem('log') && f.st !== 'ash', countItem('log'));
  ['fish', 'meat', 'mush'].forEach(function (id) { if (hasItem(id)) h += btn('cook:' + id, ITEMS[id].cook, t('fire.cook', { x: iname(id) }), lit && !busy, countItem(id)); });
  if (hasItem('can_raw')) h += btn('boil', 'can_boil', t('fire.boil'), lit && !busy);
  if (hasItem('can_boil') && hasItem('chamomile')) h += btn('tea', 'can_tea', t('fire.tea'), lit && !busy);
  if (!hasItem('fish') && !hasItem('meat') && !hasItem('mush') && !hasItem('can_raw')) h += '<p style="font-size:12.5px;opacity:.7">' + esc(t('fire.nothing')) + '</p>';
  $('fireBody').innerHTML = h;
}
function fireClick(e) {
  var b = e.target.closest ? e.target.closest('[data-fa]') : null; if (!b || b.disabled) return; var f = UI.arg, a = b.getAttribute('data-fa');
  if (a === 'stick' || a === 'log') addFuel(f, a); else if (a.indexOf('cook:') === 0) startCook(f, 'cook', a.slice(5)); else if (a === 'boil') startCook(f, 'boil'); else if (a === 'tea') startCook(f, 'tea');
  renderFire();
}
/* щоденник */
var JT = ['goals', 'notes', 'recipes', 'diary', 'radio'];
function renderJournal() {
  var tab = UI.tab || 'goals';
  $('jTabs').innerHTML = JT.map(function (k) { return '<span class="tab' + (k === tab ? ' on' : '') + '" data-tab="' + k + '">' + esc(t('j.' + k)) + '</span>'; }).join('');
  var h = '';
  if (tab === 'goals') {
    var cur = currentGoal(); h = '<ul class="gl">';
    GOALS.forEach(function (g) { if (g.show && !g.show()) return; var ok = g.ok(); h += '<li class="' + (ok ? 'ok' : g === cur ? 'cur' : '') + '"><span class="cb">' + (ok ? svgI('check') : '') + '</span>' + esc(goalText(g)) + '</li>'; });
    h += '</ul>';
  } else if (tab === 'notes') {
    var n = notesCount(); h = '<p style="opacity:.7;font-size:13px">' + esc(t('j.notesCount', { n: n })) + '</p>';
    if (!n) h += '<p>' + esc(t('j.noNotes')) + '</p>';
    for (var i = 1; i <= 6; i++) if (G.notes[i]) h += '<div class="nl" data-note="' + i + '"><b>' + svgI('note') + ' ' + esc(t('note.' + i + '.t')) + '</b><span>' + esc(noteText(i).slice(0, 110)) + '…</span></div>';
    var code = ''; for (var c = 0; c < 4; c++) code += G.notes[c + 2] ? G.code.charAt(c) : '_'; if (n >= 2) h += '<p style="font-family:monospace;font-size:15px">' + esc(t('j.codeHint', { c: code.split('').join(' ') })) + '</p>';
  } else if (tab === 'recipes') {
    RECIPES.forEach(function (r) { if (!G.known[r.id]) return; h += '<div class="rc known' + (haveFor(r) ? ' ok' : '') + '">' + miniPat(r) + '<span class="ro">' + svgI(r.out[0]) + '</span><em>' + esc(iname(r.out[0])) + '<small>' + esc(idesc(r.out[0])) + '</small></em></div>'; });
    var unk = RECIPES.filter(function (r) { return !G.known[r.id]; }).length; if (unk) h += '<p style="opacity:.6;font-size:12.5px">' + svgI('lock') + ' ' + unk + ' — ' + esc(t('inv.unknownTap')) + '</p>';
  } else if (tab === 'diary') {
    if (!G.diary.length) h = '<p>' + esc(t('j.noDiary')) + '</p>';
    G.diary.slice().reverse().forEach(function (e) { h += '<div class="dy"><b>' + esc(t('dy.title', { d: e.d })) + (e.ai ? ' ' + svgI('signal') : '') + '</b>' + esc(e.t) + '</div>'; });
  } else if (tab === 'radio') {
    if (!G.flags.radio) h = '<p>' + esc(t('j.noRadio')) + '</p>';
    else {
      h = '<div class="ais" id="aiStatus"></div><div class="rlog" id="rlog">';
      G.radio.forEach(function (m) { h += '<div class="rm ' + m.w + '"><small>' + esc(t(m.w === 'obs' ? 'radio.obs' : 'radio.you')) + ' · ' + esc(t('hud.day', { d: m.d })) + ' ' + m.h + '</small>' + esc(m.t) + '</div>'; });
      if (UI.waiting) h += '<div class="rm obs"><small>' + esc(t('radio.obs')) + '</small>' + esc(t('radio.wait')) + '</div>';
      h += '</div><div class="rin"><input id="rIn" maxlength="200" placeholder="' + esc(t('radio.ph')) + '"><button class="btn" id="rSend">' + svgI('send') + esc(t('btn.send')) + '</button></div>';
    }
  }
  $('jBody').innerHTML = h;
  if (tab === 'radio' && G.flags.radio) { updateAIStatus(); var jb = $('jBody'); jb.scrollTop = jb.scrollHeight; }
}
function journalClick(e) {
  var tg = e.target, tb = tg.closest('[data-tab]'); if (tb) { UI.tab = tb.getAttribute('data-tab'); renderJournal(); AU.click(); return; }
  var nl = tg.closest('[data-note]'); if (nl) { openOv('note', +nl.getAttribute('data-note')); return; }
  if (tg.closest('#rSend')) { var i = $('rIn'); radioSend(i.value); return; }
}
/* люк */
function renderHatch() {
  $('kdisp').textContent = (KEY.s + '____').slice(0, 4).split('').join(' ');
  if (!$('kpad').children.length) { var h = ''; ['1', '2', '3', '4', '5', '6', '7', '8', '9', 'c', '0'].forEach(function (d) { h += '<button class="btn" data-k="' + d + '">' + (d === 'c' ? esc(t('hatch.clear')) : d) + '</button>'; }); $('kpad').innerHTML = h; }
}
/* налаштування */
function renderSettings() {
  function opts(key, vals, labels) { return vals.map(function (v, i) { return '<button class="btn sm' + (SET[key] === v ? ' on' : '') + '" data-set="' + key + '" data-v="' + v + '">' + esc(labels[i]) + '</button>'; }).join(''); }
  function tog(key) { return opts(key, [true, false], [t('set.on'), t('set.off')]); }
  var h = '';
  h += '<div class="row"><span>' + esc(t('set.lang')) + '</span><div>' + opts('lang', ['uk', 'en', 'ru'], [t('lang.uk'), t('lang.en'), t('lang.ru')]) + '</div></div>';
  h += '<div class="row"><span>' + esc(t('set.quality')) + '<br><small style="opacity:.6">' + esc(t('set.quality_d')) + '</small></span><div>' + opts('quality', ['auto', 'low', 'medium', 'high'], [t('set.q.auto'), t('set.q.low'), t('set.q.medium'), t('set.q.high')]) + '</div></div>';
  h += '<div class="row"><span>' + esc(t('set.sens')) + '</span><input type="range" min="0.3" max="2.5" step="0.1" value="' + SET.sens + '" data-range="sens"></div>';
  h += '<div class="row"><span>' + esc(t('set.vol')) + '</span><input type="range" min="0" max="1" step="0.05" value="' + SET.vol + '" data-range="vol"></div>';
  h += '<div class="row"><span>' + esc(t('set.ai')) + '</span><div>' + tog('ai') + '</div></div>';
  h += '<div class="row"><span>' + esc(t('set.touch')) + '</span><div>' + opts('touch', ['auto', 'on', 'off'], [t('set.t.auto'), t('set.t.on'), t('set.t.off')]) + '</div></div>';
  h += '<div class="row"><span>' + esc(t('set.invert')) + '</span><div>' + tog('invertY') + '</div></div>';
  h += '<div class="row"><span>' + esc(t('set.hints')) + '</span><div>' + tog('hints') + '</div></div>';
  h += '<div class="row"><span>' + esc(t('set.fps')) + '</span><div>' + tog('fps') + '</div></div>';
  if (UI.qChanged) h += '<p style="color:#ffd56a;font-size:13px">' + esc(t('set.reload')) + ' <button class="btn sm" id="sReload">↻</button></p>';
  h += '<div style="margin-top:10px"><button class="btn sm" id="sReset">' + esc(t('set.reset')) + '</button></div>';
  $('setBody').innerHTML = h;
}
function settingsClick(e) {
  var b = e.target.closest('[data-set]');
  if (b) {
    var k = b.getAttribute('data-set'), v = b.getAttribute('data-v'); if (v === 'true') v = true; else if (v === 'false') v = false;
    SET[k] = v; saveSettings(); AU.click();
    if (k === 'lang') { LANG = v; applyLang(); }
    if (k === 'quality') UI.qChanged = true;
    if (k === 'touch') { setTouch(v === 'on' ? true : v === 'off' ? false : (IS_TOUCH && (COARSE || IS_IOS))); }
    if (k === 'ai') { AI.ok = null; aiProbe(); }
    if (k === 'fps') $('fps').classList.toggle('hide', !v);
    renderSettings(); return;
  }
  if (e.target.closest('#sReload')) { if (G.started && !S.ended) saveGame(true); location.reload(); }
  if (e.target.closest('#sReset')) { if (confirm(t('set.resetConfirm'))) { store.del(SAVE_KEY); location.reload(); } }
}
function settingsInput(e) { var r = e.target.getAttribute('data-range'); if (!r) return; SET[r] = parseFloat(e.target.value); if (r === 'vol') AU.vol(SET.vol); saveSettings(); }

/* ---------- мова ---------- */
function applyLang() {
  document.documentElement.lang = LANG;
  var els = document.querySelectorAll('[data-t]'); for (var i = 0; i < els.length; i++) els[i].textContent = t(els[i].getAttribute('data-t'));
  var tt = t('game.title').split(' '); var h1 = document.querySelector('#start h1'); if (h1) h1.innerHTML = esc(tt[0]) + ' <b>' + esc(tt.slice(1).join(' ')) + '</b>';
  document.title = t('game.title').replace(/[«»“”]/g, '') + ' — ' + t('game.sub');
  $('langBtns').innerHTML = ['uk', 'en', 'ru'].map(function (l) { return '<button class="btn sm' + (LANG === l ? ' on' : '') + '" data-lang="' + l + '">' + t('lang.' + l) + '</button>'; }).join('');
  ['btnJournal', 'btnInv', 'btnPause'].forEach(function (id, k) { $(id).title = t(['btn.journal', 'btn.inv', 'btn.pause'][k]); });
  buildCompass(); refreshUI(); if (UI.ov === 'journal') renderJournal(); if (UI.ov === 'settings') renderSettings(); if (UI.ov === 'fire') renderFire(); if (UI.ov === 'inv') renderInv();
  updateSaveInfo(); UI.ti = null; UI.wx = null; UI.goal = null;
}
function injectIcons(root) { var els = (root || document).querySelectorAll('[data-i]'); for (var i = 0; i < els.length; i++) { var n = els[i].getAttribute('data-i'); if (ICON[n]) els[i].innerHTML = svgI(n); } }

/* ---------- компас ---------- */
function buildCompass() { var L = ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW'], h = ''; for (var k = 0; k < 3; k++) L.forEach(function (l) { h += '<b' + (l.length === 1 ? ' class="m"' : '') + '>' + esc(t('dir.' + l)) + '</b>'; }); $('cmpin').innerHTML = h; }
function setCompass() { var f = fwd(), bearing = (Math.atan2(f[0], -f[2]) * 180 / Math.PI + 360) % 360; $('cmpin').style.transform = 'translateX(' + (-(440 + bearing / 45 * 55) + 110 - 27.5) + 'px)'; }

/* ---------- оновлення HUD ---------- */
var hudT = 0, fpsN = 0, fpsT = 0, fpsV = 0;
function hudStep(dt) {
  fpsN++; fpsT += dt; if (fpsT > 1) { fpsV = Math.round(fpsN / fpsT); fpsN = 0; fpsT = 0; if (SET.fps) $('fps').textContent = fpsV + ' ' + t('ui.fps') + ' · ' + QL + ' ×' + RES.scale.toFixed(2); }
  // підказка дії та кільце прогресу
  var a = ACT.cur, pr = $('prompt');
  if (PLACE.on) { pr.innerHTML = '<span class="pi">' + svgI(PLACE.id) + '</span>' + (touchMode ? '' : '<kbd>E</kbd>') + esc(PLACE.ok ? t('act.place') : t('act.cantPlace')); pr.className = 'show' + (PLACE.ok ? '' : ' no'); }
  else if (a && !UI.ov) {
    var keyH = touchMode ? '' : '<kbd>' + (a.dur ? 'E ' + t('ui.hold') : 'E') + '</kbd>';
    pr.innerHTML = '<span class="pi">' + svgI(a.icon) + '</span>' + keyH + '<span>' + esc(a.label) + '</span>';
    pr.className = 'show' + (a.ok ? '' : ' no') + (a.hot ? ' hot' : '');
  } else pr.className = '';
  $('cross').className = a && a.ok ? 'on' : '';
  var ring = $('ring'), fg = $('ringFg');
  if (a && a.dur && ACT.prog > 0) { ring.setAttribute('class', 'on'); fg.setAttribute('stroke-dashoffset', 138.2 * (1 - clamp(ACT.prog / a.dur, 0, 1))); } else ring.setAttribute('class', '');
  var tAct = $('tAct'); if (tAct) { var ic = a ? a.icon : 'hand'; if (tAct._ic !== ic) { tAct._ic = ic; tAct.innerHTML = svgI(ic); } tAct.className = a && a.ok ? 'act' : ''; }
  setCompass();
  hudT -= dt; if (hudT > 0) return; hudT = 0.12;
  var m = Math.floor(G.tot % 1440), day = dayOf();
  $('clk').textContent = fmtT(m); $('dayl').textContent = day <= 7 ? t('hud.dayOf', { d: day }) : t('hud.day', { d: day });
  var ti = isNight() ? 'moon' : 'sun'; if (UI.ti !== ti) { UI.ti = ti; $('timeIcon').innerHTML = svgI(ti); }
  var wx = WX.type === 'clear' ? '' : WX.type; if (UI.wx !== wx) { UI.wx = wx; $('wxIcon').innerHTML = wx ? svgI(wx) : ''; $('wxIcon').title = t('w.' + (wx || 'clear')); }
  var g = currentGoal(), gt = g ? goalText(g) : t('g.end'); if (UI.goal !== gt) { UI.goal = gt; $('goalTxt').textContent = gt; }
  var gp = null;
  if (g && g.id === 'water') { var bd = 1e9; PONDS.forEach(function (p) { var dd = Math.hypot(p.x - P.x, p.z - P.z) - p.r; if (dd < bd) { bd = dd; gp = { x: p.x, z: p.z, r: p.r }; } }); }
  else if (g && g.id === 'camp') gp = { x: POI.camp.x, z: POI.camp.z, r: 2 };
  else if (g && g.id === 'hatch') gp = { x: POI.hatch.x, z: POI.hatch.z, r: 1 };
  var gd = ''; if (gp) { var dx = gp.x - P.x, dz = gp.z - P.z, dist = Math.max(0, Math.hypot(dx, dz) - gp.r); if (dist > 4) gd = '≈ ' + Math.round(dist) + ' м · ' + t('dir.' + ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW'][Math.round(((Math.atan2(dx, -dz) * 180 / Math.PI + 360) % 360) / 45) % 8]); }
  if (LANG === 'en') gd = gd.replace(' м ', ' m ');
  if ($('goalDir')._v !== gd) { $('goalDir')._v = gd; $('goalDir').textContent = gd; }
  [['hp', S.hp], ['food', S.food], ['water', S.water], ['en', S.energy], ['warm', S.warm]].forEach(function (e) { $('b_' + e[0]).style.width = e[1] + '%'; var el = $('s_' + e[0]); el.className = 'st' + (e[1] < 22 ? ' low' : ''); el.title = t('st.' + (e[0] === 'en' ? 'energy' : e[0])) + ': ' + Math.round(e[1]); });
  var fx = [];
  if (S.bleed) fx.push(['bleed', 'sts.bleed']); if (S.sick) fx.push(['sick', 'sts.sick']); if (S.poison) fx.push(['poison', 'sts.poison']);
  if (S.wet > 0.35) fx.push(['wet', 'sts.wet']); if (S.warm < 25) fx.push(['cold', 'sts.cold']); if (S.energy < 14) fx.push(['tired', 'sts.tired']);
  var fh = fx.map(function (f) { return '<span class="fx" title="' + esc(t(f[1].replace('sts.', 'stsd.'))) + '">' + svgI(f[0]) + esc(t(f[1])) + '</span>'; }).join('');
  if ($('effects')._h !== fh) { $('effects')._h = fh; $('effects').innerHTML = fh; }
  var st = $('stam'); st.style.opacity = S.stamina < 98 ? 1 : 0; st.firstChild.style.width = S.stamina + '%';
  $('hurt').style.opacity = clamp((S.hurtT > 0 ? 0.6 : 0) + (S.hp < 35 ? (35 - S.hp) / 60 : 0), 0, 0.85);
  $('cold').style.opacity = clamp((40 - S.warm) / 55, 0, 0.6); $('wet').style.opacity = clamp(S.wet, 0, 1) * 0.9;
  canvas.style.filter = S.poison ? 'hue-rotate(' + Math.round(Math.sin(G.t * 0.7) * 40 * S.poison) + 'deg) saturate(' + (1 + S.poison * 0.6).toFixed(2) + ')' : '';
  $('placeBar').classList.toggle('hide', !PLACE.on);
}
function updateSaveInfo() {
  var s = store.get(SAVE_KEY, null), b = $('btnCont');
  if (s && s.G) { b.classList.remove('hide'); $('saveInfo').textContent = t('start.saveInfo', { d: Math.floor(s.G.tot / 1440) + 1, t: fmtT(Math.floor(s.G.tot % 1440)) }); } else b.classList.add('hide');
}
