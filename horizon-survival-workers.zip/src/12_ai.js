/* =====================================================================
   ШІ (Cloudflare Workers AI через /api/ai). Без мережі — записані репліки.
   ===================================================================== */
var AI = { ok: null, last: -1e9, chatN: 0, chatLast: -1e9, endpoint: 'api/ai' };
function aiCanTry() { return SET.ai && AI.ok !== false && navigator.onLine !== false && /^https?:/.test(location.protocol); }
function aiProbe() {
  if (!SET.ai || !/^https?:/.test(location.protocol) || typeof fetch !== 'function') { AI.ok = false; updateAIStatus(); return; }
  var done = false, tm = setTimeout(function () { if (!done) { done = true; AI.ok = false; updateAIStatus(); } }, 5000);
  fetch(AI.endpoint, { method: 'GET', cache: 'no-store' }).then(function (r) { return r.ok ? r.json() : null; }).then(function (j) {
    if (done) return; done = true; clearTimeout(tm); AI.ok = !!(j && j.ok && j.ai); updateAIStatus();
  }).catch(function () { if (done) return; done = true; clearTimeout(tm); AI.ok = false; updateAIStatus(); });
}
window.addEventListener('online', function () { AI.ok = null; aiProbe(); });
window.addEventListener('offline', function () { AI.ok = false; updateAIStatus(); });
function gameCtx() {
  var st = []; if (S.bleed) st.push('bleeding'); if (S.sick) st.push('sick'); if (S.poison) st.push('poisoned'); if (S.wet > 0.5) st.push('wet'); if (S.warm < 30) st.push('cold'); if (S.energy < 15) st.push('exhausted');
  return { day: dayOf(), hour: Math.floor(hourOf()), weather: WX.type, hp: Math.round(S.hp), food: Math.round(S.food), water: Math.round(S.water), warmth: Math.round(S.warm), status: st, notes: notesCount(), fire: !!nearFire(8), shelter: !!underRoof(P.x, P.z), night: isNight() };
}
function aiClean(s) { if (!s || typeof s !== 'string') return null; s = s.replace(/<think>[\s\S]*?<\/think>/g, '').replace(/[*#_`>]/g, '').replace(/\s+/g, ' ').trim(); return s.length > 2 ? s.slice(0, 600) : null; }
function aiAsk(kind, ctx, cb) {
  if (!aiCanTry() || AI.ok === null && kind !== 'chat') { cb(null); return; }
  if (kind === 'radio' && G.t - AI.last < 45) { cb(null); return; }
  AI.last = G.t;
  var body = { kind: kind, lang: LANG, ctx: gameCtx() }; for (var k in ctx) body.ctx[k] = ctx[k];
  var done = false, tm = setTimeout(function () { if (!done) { done = true; cb(null); } }, 12000);
  try {
    fetch(AI.endpoint, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) })
      .then(function (r) { if (!r.ok) throw r.status; return r.json(); })
      .then(function (j) { if (done) return; done = true; clearTimeout(tm); AI.ok = true; updateAIStatus(); cb(aiClean(j && j.text)); })
      .catch(function (e) { if (done) return; done = true; clearTimeout(tm); if (e === 404 || e === 405) { AI.ok = false; updateAIStatus(); } cb(null); });
  } catch (e) { done = true; clearTimeout(tm); cb(null); }
}
/* відповідь на повідомлення гравця: ШІ або ключові слова */
var CHAT_KW = [
  ['chat.water', /вод|water|пит|drink|пить/i], ['chat.fire', /вогон|вогн|огон|огн|fire|костр|костер|багатт|розпал|разжечь|дрил/i],
  ['chat.wolf', /вовк|волк|wolf|wolves|звір|звер/i], ['chat.who', /хто ти|кто ты|who are|хто ви|кто вы|ім'я|имя|name/i],
  ['chat.exit', /вихід|выход|exit|двер|door|out|втеч|побег|escape|код|code/i], ['chat.food', /їж|їст|еда|есть|food|eat|гриб|mushroom|риб|fish/i],
  ['chat.sky', /неб|sky|екран|экран|screen|глюк|glitch/i], ['chat.hello', /прив|здрав|hello|hi\b|hey|добр/i]
];
function radioSend(txt) {
  txt = (txt || '').trim().slice(0, 200); if (!txt) return;
  if (G.t - AI.chatLast < 6 || AI.chatN > 40) { toast(t('radio.limit'), 'radio', 'bad'); return; }
  AI.chatLast = G.t; AI.chatN++;
  G.radio.push({ w: 'you', t: txt, d: dayOf(), h: fmtT(G.tot) }); AU.radio(); renderJournal();
  var fb = null; for (var i = 0; i < CHAT_KW.length; i++) if (CHAT_KW[i][1].test(txt)) { fb = t(CHAT_KW[i][0]); break; }
  if (!fb) fb = t(['chat.d1', 'chat.d2', 'chat.d3'][Math.floor(Math.random() * 3)]);
  UI.waiting = true; renderJournal();
  var delay = aiCanTry() && AI.ok ? 0 : 1200 + Math.random() * 1200;
  setTimeout(function () {
    aiAsk('chat', { question: txt, history: G.radio.slice(-6).map(function (m) { return (m.w === 'you' ? 'S7: ' : 'OBS: ') + m.t; }) }, function (r) { UI.waiting = false; radioSay(r || fb, !!r); });
  }, delay);
}
function updateAIStatus() { var e = $('aiStatus'); if (e) { e.textContent = t(AI.ok ? 'radio.on' : 'radio.off'); e.className = 'ais ' + (AI.ok ? 'on' : 'off'); } }
