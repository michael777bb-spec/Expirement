/* =====================================================================
   ГРАВЕЦЬ: рух, ціль погляду, дії з утриманням, предмет у руці, рибалка
   ===================================================================== */
var keys = {}, joy = { x: 0, y: 0 }, INP = { held: false, pressed: false, use: false, jump: false, lookX: 0, lookY: 0 };
var EYE = 1.62;
function blocked(x, z) {
  if (x < 1.2 || x > X1 - 1.2 || Math.abs(z) > ZLIM) return true;
  if (waterDepth(x, z) > 0.85) return true;
  return false;
}
function collideP(p) {
  for (var it = 0; it < 2; it++) for (var i = 0; i < COLS.length; i++) {
    var c = COLS[i]; if (!c.on) continue;
    var dx = p.x - c.x, dz = p.z - c.z, rr2 = c.r + 0.32, d2 = dx * dx + dz * dz;
    if (d2 < rr2 * rr2 && d2 > 1e-8) { var d = Math.sqrt(d2), k = (rr2 - d) / d; p.x += dx * k; p.z += dz * k; }
  }
}
function look(dx, dy, s) { P.yaw -= dx * s * SET.sens; P.pitch = clamp(P.pitch - dy * s * SET.sens * (SET.invertY ? -1 : 1), -1.45, 1.45); }
function fwd() { var cp = Math.cos(P.pitch); return [-Math.sin(P.yaw) * cp, Math.sin(P.pitch), -Math.cos(P.yaw) * cp]; }

function movePlayer(dt) {
  var mx = 0, mz = 0;
  if (!UI.ov && !G.sleeping && !PLACE.on) {
    if (keys.KeyW || keys.ArrowUp) mz += 1; if (keys.KeyS || keys.ArrowDown) mz -= 1;
    if (keys.KeyD || keys.ArrowRight) mx += 1; if (keys.KeyA || keys.ArrowLeft) mx -= 1;
    mx += joy.x; mz -= joy.y;
  }
  if (PLACE.on && !UI.ov) { if (keys.KeyW || keys.ArrowUp) mz += 1; if (keys.KeyS || keys.ArrowDown) mz -= 1; if (keys.KeyD || keys.ArrowRight) mx += 1; if (keys.KeyA || keys.ArrowLeft) mx -= 1; mx += joy.x; mz -= joy.y; }
  var len = Math.hypot(mx, mz); if (len > 1) { mx /= len; mz /= len; len = 1; }
  var depth = waterDepth(P.x, P.z), inWater = depth > 0.15;
  var wantRun = (keys.ShiftLeft || keys.ShiftRight || P.run) && len > 0.3;
  var running = wantRun && S.stamina > 4 && S.energy > 12 && !inWater;
  var speed = running ? 5.6 : 3.4;
  if (S.energy < 12) speed *= 0.75; if (inWater) speed *= depth > 0.45 ? 0.45 : 0.65; if (S.poison) speed *= 0.85;
  P.running = running && len > 0.1;
  var sy = Math.sin(P.yaw), cy = Math.cos(P.yaw);
  var vx = (-sy * mz + cy * mx) * speed, vz = (-cy * mz - sy * mx) * speed;
  var np = { x: P.x + vx * dt, z: P.z + vz * dt }; collideP(np);
  if (blocked(np.x, P.z)) np.x = P.x; if (blocked(P.x, np.z)) np.z = P.z; if (blocked(np.x, np.z)) { np.x = P.x; np.z = P.z; }
  var moved = Math.hypot(np.x - P.x, np.z - P.z); P.x = np.x; P.z = np.z;
  var gy = H(P.x, P.z);
  if (INP.jump && P.onGround && !inWater && S.stamina > 8) { P.vy = 4.3; P.onGround = false; S.stamina -= 8; }
  INP.jump = false;
  P.vy -= 13 * dt; P.y += P.vy * dt;
  if (P.y <= gy) { if (!P.onGround && P.vy < -5) AU.step(false); P.y = gy; P.vy = 0; P.onGround = true; }
  if (moved > 0.0005 && P.onGround) {
    P.bob += moved * 5.4; P.stepD += moved;
    if (P.stepD > (running ? 1.75 : 1.25)) { P.stepD = 0; AU.step(inWater); if (inWater && Math.random() < 0.5) { PRE.splash(P.x, WATER_Y, P.z, 4); ripple(P.x, P.z, 0.5); } }
  }
  P.moving = moved > 0.0005;
  return moved;
}

/* ---------- ціль погляду ---------- */
var TARGET = null, WATER_T = null;
function findTarget() {
  var f = fwd(), ex = P.x, ey = P.y + EYE, ez = P.z, best = null, bs = 1e9;
  for (var i = 0; i < INTER.length; i++) {
    var o = INTER[i]; if (!o.on) continue;
    var dx = o.x - ex, dz = o.z - ez; if (Math.abs(dx) > 4 || Math.abs(dz) > 4) continue;
    var dy = o.y - ey, d = Math.sqrt(dx * dx + dy * dy + dz * dz), d2 = Math.hypot(dx, dz);
    if (d2 > o.r + 1.4) continue;
    var dot = (dx * f[0] + dy * f[1] + dz * f[2]) / (d || 1), need = d2 < 1 ? 0.55 : 0.86 - Math.min(0.12, o.r * 0.05);
    if (dot < need) continue;
    var sc = (1 - dot) * 6 + d * 0.25; if (sc < bs) { bs = sc; best = o; }
  }
  // вода: промінь до площини ставка
  WATER_T = null;
  if (f[1] < -0.05) {
    var tt = (WATER_Y - ey) / f[1];
    if (tt > 0 && tt < 4.5) { var wx = ex + f[0] * tt, wz = ez + f[2] * tt; if (waterDepth(wx, wz) > 0.06) WATER_T = { kind: 'water', x: wx, y: WATER_Y, z: wz, d: tt }; }
  }
  if (WATER_T && (!best || WATER_T.d < Math.hypot(best.x - ex, best.z - ez) - 0.5)) best = WATER_T;
  return best;
}
function held() { return inv.slots[inv.sel]; }
function heldId() { var s = inv.slots[inv.sel]; return s ? s.id : null; }
/* опис дії для цілі: {label, icon, dur, rep, ok, fn, swing} */
function actionFor(o) {
  if (!o) return null;
  var h = heldId();
  switch (o.kind) {
    case 'tree': return treeAction(o.ref, h);
    case 'node': return nodeAction(o.ref);
    case 'water': return waterAction(o, h);
    case 'fire': return fireAction(o.ref, h);
    case 'shelter': return { label: t('act.sleep'), icon: 'bedroll', dur: 0, ok: true, fn: function () { trySleep('shelter'); } };
    case 'snare': return o.ref.caught ? { label: t('act.snareGet'), icon: 'meat', dur: 0.8, ok: true, fn: function () { snareCollect(o.ref); } } : { label: t('act.snare'), icon: 'snare', dur: 0, ok: true, fn: function () { toast(t('msg.snareEmpty'), 'snare'); } };
    case 'drop': return { label: iname(o.ref.id), icon: o.ref.id, dur: 0.4, ok: true, fn: function () { if (giveItems([[o.ref.id, o.ref.n]])) { removeInter(o); DROPS.splice(DROPS.indexOf(o.ref), 1); } } };
    default: return storyAction(o, h);
  }
}
function treeAction(tr, h) {
  var info = TREE_INFO[tr.kind];
  if (tr.st === 1) return null;
  if (tr.st === 2) return h === 'axe' ? { label: t('act.process'), icon: 'axe', dur: 0.62, rep: true, swing: true, ok: true, fn: function () { chopTree(tr); } } : { label: t('act.process'), icon: 'axe', ok: false, sub: t('act.needAxe') };
  if (h === 'axe') return { label: t('act.chop'), icon: 'axe', dur: 0.62, rep: true, swing: true, ok: true, fn: function () { chopTree(tr); } };
  if (tr.kind === 'apple' && tr.apples.length && G.tot - tr.appleT > 30 * 60) return { label: t('act.apple'), icon: 'apple', dur: 0.6, ok: true, fn: function () { pickApples(tr); } };
  if (tr.kind === 'birch' && G.tot - tr.bark > 24 * 60) {
    if (hasItem('sharp')) return { label: t('act.bark'), icon: 'bark', dur: 1.4, ok: true, fn: function () { takeBark(tr); } };
    return { label: t('act.barkNeed'), icon: 'bark', ok: false };
  }
  return { label: t('act.needAxe'), icon: 'axe', ok: false };
}
function nodeAction(n) {
  var map = { stick: 'act.stick', stone: 'act.stone', fiber: 'act.fiber', bush: 'act.berry', mush: 'act.mush', amanita: 'act.amanita', plantain: 'act.plantain', chamomile: 'act.chamomile' };
  var ic = { stick: 'stick', stone: 'stone', fiber: 'fiber', bush: 'berry', mush: 'mush', amanita: 'amanita', plantain: 'plantain', chamomile: 'chamomile' };
  return { label: t(map[n.kind]), icon: ic[n.kind], dur: n.kind === 'fiber' || n.kind === 'bush' ? 0.55 : 0, ok: true, fn: function () { pickNode(n); } };
}
function waterAction(o, h) {
  if (FISH.st !== 'none') return FISH.st === 'bite' ? { label: t('act.hook'), icon: 'fishing', dur: 0, ok: true, fn: hookFish, hot: true } : { label: t('act.wait'), icon: 'fishing', dur: 0, ok: true, fn: hookFish };
  if (h === 'rod') return { label: t('act.fish'), icon: 'rod', dur: 0, ok: true, fn: function () { castRod(o); } };
  if (h === 'spear') return { label: t('act.spear'), icon: 'spear', dur: 0, ok: true, fn: function () { castRod(o, true); } };
  if (h === 'can_empty') return { label: t('act.fill'), icon: 'can_raw', dur: 0.9, ok: true, fn: function () { var i = findSlot('can_empty'); if (i >= 0) { inv.slots[i] = mkStack('can_raw', 1); AU.splash(0.06); toast(t('msg.filled'), 'can_raw'); refreshUI(); } } };
  return { label: t('act.drink'), icon: 'drop', dur: 0.75, rep: true, ok: true, fn: drinkPond };
}

/* ---------- збирання ---------- */
function pickNode(n) {
  var give = { stick: [['stick', 1]], stone: [['stone', 1]], fiber: [['fiber', 2 + (Math.random() < 0.5 ? 1 : 0)]], bush: [['berry', 3 + Math.floor(Math.random() * 3)]], mush: [['mush', 1 + (Math.random() < 0.3 ? 1 : 0)]], amanita: [['amanita', 1]], plantain: [['plantain', 1 + (Math.random() < 0.4 ? 1 : 0)]], chamomile: [['chamomile', 2]] }[n.kind];
  if (n.kind === 'bush' && Math.random() < 0.35) give.push(['stick', 1]);
  if (!giveItems(give)) return;
  n.t = G.tot; showInst(n.it, n.kind === 'bush'); n.extra.forEach(function (e) { showInst(e, false); });
  if (n.kind !== 'bush') n.inter.on = false; else n.inter.on = false;
  if (n.kind === 'fiber' || n.kind === 'bush') AU.rustle();
  P.swingT = 0.35; P.swingKind = 'grab';
  if (n.kind === 'stick' || n.kind === 'fiber') PRE.leaves(n.x, n.y + 0.2, n.z, 3, 0.2);
  tip('inv');
}
function pickApples(tr) {
  var n = 0; tr.apples.forEach(function (a) { if (!a.hid) n++; });
  if (!n) return; if (!giveItems([['apple', Math.min(n, 3 + Math.floor(Math.random() * 2))]])) return;
  tr.apples.forEach(function (a) { showInst(a, false); }); tr.appleT = G.tot; AU.rustle(); PRE.leaves(tr.x, H(tr.x, tr.z) + 3.5 * tr.s, tr.z, 8, 1.4);
}
function takeBark(tr) {
  if (!giveItems([['bark', 2]])) return; tr.bark = G.tot; AU.rustle(); AU.chop();
  PRE.chips(tr.x, H(tr.x, tr.z) + 1.2, tr.z, 4);
  if (Math.random() < 0.15) { removeItem('sharp', 1); toast(t('msg.sharpBroke'), 'sharp', 'bad'); }
  toast(t('msg.bark'), 'bark');
}
/* ---------- рубання ---------- */
function chopTree(tr) {
  var info = TREE_INFO[tr.kind], y0 = H(tr.x, tr.z);
  AU.chop(); P.shake = Math.max(P.shake, 0.12);
  var fx = tr.x - P.x, fz = tr.z - P.z, fl = Math.hypot(fx, fz) || 1; fx /= fl; fz /= fl;
  if (wearTool('axe')) return;
  if (tr.st === 0) {
    tr.hits++; tr.shake = 0.35; tr.shDx = fx; tr.shDz = fz;
    PRE.chips(tr.x - fx * 0.35, y0 + 0.9, tr.z - fz * 0.35, 6); if (Math.random() < 0.5) PRE.leaves(tr.x, y0 + 3.5 * tr.s, tr.z, 3, 1.5);
    if (tr.hits >= info.hits) {
      tr.st = 1; tr.fallT = 0; tr.dx = fx; tr.dz = fz; tr.col.on = false; showInst(tr.stump, true); AU.creak();
      toast(t('msg.treeFall'), 'axe'); tr.apples.forEach(function (a) { showInst(a, false); });
      showInst(tr.shadow, false);
    }
  } else if (tr.st === 2) {
    tr.proc++; PRE.chips(tr.inter.x, tr.inter.y, tr.inter.z, 7);
    if (tr.proc >= info.proc) {
      var got = [['log', info.logs], ['stick', info.sticks]];
      if (!canAdd('log', info.logs)) { toast(t('msg.full'), 'bag', 'bad'); tr.proc--; return; }
      giveItems(got); tr.st = 3; tr.goneT = 0; removeInter(tr.inter); STATS.trees++; logDay('tree');
      toast(t('msg.treeDone'), 'log', 'good'); PRE.leaves(tr.inter.x, tr.inter.y + 0.5, tr.inter.z, 14, 2); AU.rustle();
    }
  }
}
function treesUpdate(dt) {
  for (var i = 0; i < TREES.length; i++) {
    var tr = TREES[i], it = tr.it;
    if (tr.shake > 0) { tr.shake = Math.max(0, tr.shake - dt); if (tr.st === 0) { it.tilt = Math.sin(tr.shake * 40) * 0.025 * tr.shake * 3; it.dx = tr.shDx; it.dz = tr.shDz; writeInst(it); } }
    if (tr.st === 1) {
      tr.fallT += dt; var k = Math.min(1, tr.fallT / 2.3), a = k * k * (Math.PI / 2 - 0.06);
      if (k >= 1) { var bt = tr.fallT - 2.3; a = Math.PI / 2 - 0.06 - Math.abs(Math.sin(bt * 9)) * Math.exp(-bt * 5) * 0.08; }
      it.tilt = a; it.dx = tr.dx; it.dz = tr.dz; writeInst(it);
      if (k >= 1 && !tr.landed) {
        tr.landed = true; AU.crash(); var cx = tr.x + tr.dx * 3.5 * tr.s, cz = tr.z + tr.dz * 3.5 * tr.s;
        PRE.leaves(cx, H(cx, cz) + 1, cz, 26, 2.5); PRE.dust(cx, H(cx, cz) + 0.2, cz, 8);
        var dp = Math.hypot(P.x - cx, P.z - cz); if (dp < 25) P.shake = Math.max(P.shake, 0.5 * (1 - dp / 25));
        if (dp < 2.2 && tr.fallT < 2.6) { harm(25, 'tree'); toast(t('msg.treeHit'), 'heart', 'bad'); }
      }
      if (tr.fallT > 3) {
        tr.st = 2; var mid = (tr.kind === 'pine' ? 1.9 : tr.kind === 'birch' ? 1.6 : 1.5) * tr.s;
        tr.inter.x = tr.x + tr.dx * mid; tr.inter.z = tr.z + tr.dz * mid; tr.inter.y = H(tr.inter.x, tr.inter.z) + 0.4; tr.inter.r = 2.2;
      }
    }
    if (tr.st === 3 && tr.goneT < 1) { tr.goneT += dt; var sc = 1 - tr.goneT; if (sc <= 0) { showInst(it, false); } else { it.sy = tr.s * sc; it.s = tr.s * Math.max(0.05, sc); writeInst(it); } }
  }
}
/* ---------- вода ---------- */
function drinkPond() {
  if (S.water >= 99) { toast(t('msg.notThirsty'), 'drop'); return 'stop'; }
  S.water = clamp(S.water + 9, 0, 100); AU.drink(); P.swingT = 0.5; P.swingKind = 'drink'; G.flags.drank = 1;
  if (!S.sick && Math.random() < 0.07) { setSick(); }
  if (!G.flags.rawWarn) { G.flags.rawWarn = 1; toast(t('msg.rawWater'), 'drop'); }
  if (WATER_T) { ripple(WATER_T.x, WATER_T.z, 0.4); }
}
/* ---------- рибалка ---------- */
var FISH = { st: 'none', t: 0, wait: 0, x: 0, z: 0, spear: false, px: 0, pz: 0, fy: 0 };
function castRod(o, spear) {
  FISH.st = 'cast'; FISH.t = 0; FISH.spear = !!spear; FISH.px = P.x; FISH.pz = P.z;
  FISH.x = o.x; FISH.z = o.z; FISH.wait = rnd(4, 11) * (ENV.rain > 0.3 ? 0.65 : 1) * (ENV.dayK < 0.3 ? 1.4 : 1);
  if (spear) { FISH.x = P.x + (o.x - P.x) * 0.7; FISH.z = P.z + (o.z - P.z) * 0.7; }
  P.swingT = 0.6; P.swingKind = 'cast'; AU.swing(); tip('fish');
}
function fishStep(dt) {
  if (FISH.st === 'none') return;
  if (Math.hypot(P.x - FISH.px, P.z - FISH.pz) > 2.5 || (heldId() !== (FISH.spear ? 'spear' : 'rod'))) { FISH.st = 'none'; return; }
  FISH.t += dt;
  if (FISH.st === 'cast' && FISH.t > 0.55) { FISH.st = 'wait'; FISH.t = 0; if (!FISH.spear) { AU.plop(); ripple(FISH.x, FISH.z, 0.5); } }
  if (FISH.st === 'wait' && FISH.t > FISH.wait) { FISH.st = 'bite'; FISH.t = 0; AU.plop(); ripple(FISH.x, FISH.z, 0.9); PRE.splash(FISH.x, WATER_Y, FISH.z, 4); }
  if (FISH.st === 'bite' && FISH.t > (FISH.spear ? 0.8 : 1.15)) { FISH.st = 'none'; toast(t('msg.late'), 'fishing'); wearTool(FISH.spear ? 'spear' : 'rod'); }
}
function hookFish() {
  if (FISH.st === 'wait' || FISH.st === 'cast') { FISH.st = 'none'; toast(t('msg.early'), 'fishing'); return; }
  if (FISH.st !== 'bite') return;
  var ok = Math.random() < (FISH.spear ? 0.58 : 0.86); FISH.st = 'none';
  P.swingT = 0.6; P.swingKind = FISH.spear ? 'stab' : 'cast';
  if (ok && giveItems([['fish', 1]])) { STATS.fish++; logDay('fish'); AU.catchFish(); PRE.splash(FISH.x, WATER_Y, FISH.z, 12); ripple(FISH.x, FISH.z, 1.2); toast(t('msg.caught'), 'fish', 'good'); }
  else if (!ok) { AU.splash(0.08); toast(t(FISH.spear ? 'msg.missFish' : 'msg.escaped'), 'fishing'); }
  wearTool(FISH.spear ? 'spear' : 'rod');
}

/* ---------- удар/атака ---------- */
function attack() {
  var h = heldId(), dmg = h === 'spear' ? 1.5 : h === 'axe' ? 1.1 : 0.35, reach = h === 'spear' ? 2.8 : 2.2;
  P.swingT = 0.6; P.swingKind = h === 'spear' ? 'stab' : 'swing'; AU.swing();
  var f = fwd(), hit = false;
  WOLVES.forEach(function (w) {
    if (w.dead || hit) return; var dx = w.x - P.x, dz = w.z - P.z, d = Math.hypot(dx, dz);
    if (d < reach && (dx * f[0] + dz * f[2]) / d > 0.6) { hit = true; setTimeout(function () { hitWolf(w, dmg); if (h === 'spear' || h === 'axe') wearTool(h); }, 180); }
  });
  RABBITS.forEach(function (r) {
    if (!r.vis || hit) return; var dx = r.x - P.x, dz = r.z - P.z, d = Math.hypot(dx, dz);
    if (d < reach && (dx * f[0] + dz * f[2]) / d > 0.7 && h === 'spear' && Math.random() < 0.5) { hit = true; giveItems([['meat', 1]]); var nr = mkRabbit(); r.x = nr.x; r.z = nr.z; AU.yelp(); }
  });
  return hit;
}

/* ---------- розміщення споруд ---------- */
var PLACE = { on: false, id: null, x: 0, z: 0, ry: 0, ok: false };
function startPlace(id) { PLACE.on = true; PLACE.id = id; PLACE.ry = P.yaw; AU.click(); refreshUI(); }
function cancelPlace() { PLACE.on = false; PLACE.id = null; refreshUI(); }
function placeStep() {
  if (!PLACE.on) return;
  var d = PLACE.id === 'kit' ? 3.4 : 2.2, f = fwd();
  PLACE.x = P.x - Math.sin(P.yaw) * d; PLACE.z = P.z - Math.cos(P.yaw) * d; PLACE.ry = P.yaw + (PLACE.id === 'kit' ? Math.PI : 0);
  var ok = !blocked(PLACE.x, PLACE.z) && waterDepth(PLACE.x, PLACE.z) < -0.05;
  var rad = PLACE.id === 'kit' ? 1.6 : 0.8;
  for (var i = 0; i < COLS.length && ok; i++) { var c = COLS[i]; if (c.on && Math.hypot(c.x - PLACE.x, c.z - PLACE.z) < c.r + rad) ok = false; }
  PLACE.ok = ok;
}
function confirmPlace() {
  if (!PLACE.ok) { AU.error(); toast(t('act.cantPlace'), 'info', 'bad'); return; }
  var id = PLACE.id, i = findSlot(id); if (i < 0) { cancelPlace(); return; }
  removeAt(i, 1); AU.thud();
  if (id === 'firelay') { addFire(PLACE.x, PLACE.z, 'lay', 0); G.flags.firelay = 1; tip('fire'); }
  else if (id === 'kit') { addShelter(PLACE.x, PLACE.z, PLACE.ry); toast(t('msg.shelter'), 'kit', 'good'); G.flags.shelter = 1; PRE.leaves(PLACE.x, H(PLACE.x, PLACE.z) + 1, PLACE.z, 12, 1.5); }
  else if (id === 'snare') { addSnare(PLACE.x, PLACE.z, PLACE.ry); toast(t('msg.snareSet'), 'snare'); }
  toast(t('msg.placed'), id); cancelPlace();
}
function snareCollect(s) { if (!giveItems([['meat', 2]])) return; s.caught = false; s.set = G.tot; s.uses--; toast(t('msg.snareGot'), 'meat', 'good'); if (s.uses <= 0) { removeInter(s.inter); SNARES.splice(SNARES.indexOf(s), 1); toast(t('msg.broke', { x: iname('snare') }), 'snare', 'bad'); } }

/* ---------- кадр дій: утримання, прогрес ---------- */
var ACT = { prog: 0, cur: null, key: null, lock: false };
function actionsStep(dt) {
  if (UI.ov || G.sleeping || S.ended) { ACT.prog = 0; return; }
  if (PLACE.on) { placeStep(); if (INP.pressed) confirmPlace(); INP.pressed = false; ACT.cur = null; return; }
  TARGET = findTarget();
  var a = actionFor(TARGET); ACT.cur = a;
  var key = TARGET ? (TARGET.kind + (TARGET.ref ? TREES.indexOf(TARGET.ref) : '') + (a ? a.label : '')) : null;
  if (key !== ACT.key) { ACT.prog = 0; ACT.key = key; ACT.lock = false; }
  if (!INP.held) { ACT.lock = false; ACT.prog = 0; }
  if (a && a.ok && (INP.held || INP.pressed) && !ACT.lock) {
    if (!a.dur) { if (INP.pressed) { a.fn(); } }
    else {
      if (a.swing && ACT.prog === 0) { P.swingT = a.dur; P.swingKind = 'chop'; AU.swing(); }
      ACT.prog += dt;
      if (a.swing && ACT.prog > a.dur * 0.15 && ACT.prog - dt <= a.dur * 0.15) { }
      if (ACT.prog >= a.dur) { var r = a.fn(); ACT.prog = 0; if (!a.rep || r === 'stop') ACT.lock = true; }
    }
  } else if (a && !a.ok && INP.pressed) { AU.error(); }
  INP.pressed = false;
}
/* ---------- використання предмета в руці ---------- */
function useHeld() {
  if (UI.ov || G.sleeping || S.ended) return;
  if (PLACE.on) { confirmPlace(); return; }
  var s = held(), id = s ? s.id : null, d = id ? ITEMS[id] : null;
  // спершу: інструмент на цілі
  if (ACT.cur && ACT.cur.ok && id && (id === 'axe' && TARGET && TARGET.kind === 'tree' || (id === 'rod' || id === 'spear' || id === 'can_empty') && TARGET && TARGET.kind === 'water')) { INP.pressed = true; return; }
  if (FISH.st !== 'none') { hookFish(); return; }
  if (!id || d.tool || id === 'stick' || id === 'stone') { attack(); return; }
  if (d.f !== undefined || d.w !== undefined) { consume(inv.sel); return; }
  switch (d.use) {
    case 'torch': lightTorch(); return;
    case 'place': startPlace(id); return;
    case 'sleep': trySleep('bedroll'); return;
    case 'radio': openOv('journal', 'radio'); return;
    case 'heal': if (!S.bleed && S.hp > 95) { toast(t('msg.noNeed'), 'plantain'); return; } removeAt(inv.sel, 1); if (S.bleed && Math.random() < 0.75) { S.bleed = 0; toast(t('msg.bleedStop'), 'plantain', 'good'); } else toast(t('msg.plantain'), 'plantain'); S.hp = clamp(S.hp + 4, 0, 100); AU.rustle(); return;
    case 'bandage': if (!S.bleed && S.hp > 95) { toast(t('msg.noNeed'), 'bandage'); return; } removeAt(inv.sel, 1); S.bleed = 0; S.hp = clamp(S.hp + 12, 0, 100); toast(t('msg.bandaged'), 'bandage', 'good'); AU.rustle(); return;
    case 'charcoal': removeAt(inv.sel, 1); AU.eat(); if (S.poison) { S.poison = Math.max(0, S.poison - 0.7); toast(t('msg.charcoal'), 'charcoal', 'good'); } else toast(t('msg.noNeed'), 'charcoal'); return;
  }
  toast(iname(id) + ': ' + idesc(id), id);
}
function consume(i) {
  var s = inv.slots[i]; if (!s) return; var d = ITEMS[s.id], fk = freshK(s);
  if (d.f && !d.w && S.food > 97) { toast(t('msg.fullFood'), 'food'); return; }
  S.food = clamp(S.food + (d.f || 0) * (0.6 + 0.4 * fk), 0, 100); S.water = clamp(S.water + (d.w || 0), 0, 100);
  if (d.h) S.hp = clamp(S.hp + d.h, 0, 100);
  if (d.warm) S.warm = clamp(S.warm + d.warm, 0, 100);
  if (d.cure && S.sick) { S.sick = 0; toast(t('msg.cured'), 'can_tea', 'good'); }
  var risk = (d.raw || 0) + (fk < 0.25 ? 0.25 : 0);
  if (risk && Math.random() < risk) setSick();
  if (d.poison) setPoison();
  var id = s.id; if (d.ret) inv.slots[i] = mkStack(d.ret, 1); else removeAt(i, 1);
  if (d.w) AU.drink(); else AU.eat();
  P.swingT = 0.6; P.swingKind = d.w && !d.f ? 'drink' : 'eat';
  toast(t('msg.ate', { x: iname(id) }), id); refreshUI();
}
function lightTorch() {
  if (!nearFire(4)) { toast(t('msg.needFireFirst'), 'torch', 'bad'); AU.error(); return; }
  removeAt(inv.sel, 1); P.torch = 150; AU.ignite(); toast(t('msg.torchOn'), 'torch');
}
function nearFire(r) { for (var i = 0; i < FIRES.length; i++) { var f = FIRES[i]; if (f.st === 'lit' && Math.hypot(f.x - P.x, f.z - P.z) < (r || 6)) return f; } return P.torch > 0 && (r || 6) >= 4 ? { torch: true } : null; }

/* ---------- предмет у руці (вигляд від першої особи) ---------- */
var VW = new Float32Array(12), VL = new Float32Array(12), VO = new Float32Array(12);
function camWorld() {
  var R = CAM.R; VW[0] = R[0]; VW[1] = R[3]; VW[2] = R[6]; VW[3] = CAM.x; VW[4] = R[1]; VW[5] = R[4]; VW[6] = R[7]; VW[7] = CAM.y; VW[8] = R[2]; VW[9] = R[5]; VW[10] = R[8]; VW[11] = CAM.z;
}
function drawVM(mesh, x, y, z, rx, ry, rz, s, tint) { if (!mesh) return; mat34e(VL, 0, x, y, z, rx, ry, rz, s || 1); mul34(VO, VW, VL); drawMesh(mesh, null, VO, tint); return VO; }
var vmSway = [0, 0];
function viewmodelDraw(dt) {
  if (S.ended || G.sleeping) return;
  camWorld();
  gl.clear(gl.DEPTH_BUFFER_BIT);
  var u = useProg(PR.lit);
  var bobA = P.moving && P.onGround ? 1 : 0, bx = Math.sin(P.bob) * 0.012 * bobA, by = -Math.abs(Math.cos(P.bob)) * 0.014 * bobA;
  vmSway[0] = lerp(vmSway[0], clamp(INP.lookX * 0.002, -0.04, 0.04), Math.min(1, dt * 8)); vmSway[1] = lerp(vmSway[1], clamp(INP.lookY * 0.002, -0.04, 0.04), Math.min(1, dt * 8));
  INP.lookX = 0; INP.lookY = 0;
  var sw = P.swingT > 0 ? clamp(1 - P.swingT / (P.swingDur || 0.6), 0, 1) : 0, k = P.swingKind;
  var id = heldId(), mdl = id ? VM[ITEMS[id].vm] : null;
  var tool = id === 'axe' || id === 'spear' || id === 'rod' || id === 'stick' || id === 'drill' || id === 'torch';
  /* базова поза: предмет у правій руці внизу праворуч, верх трохи вперед і вліво */
  var px = 0.27 + bx - vmSway[0], py = -0.3 + by + vmSway[1], pz = -0.5, rx = -0.25, ry = -0.1, rz = 0.32;
  if (!tool) { px = 0.25 + bx - vmSway[0]; py = -0.3 + by + vmSway[1]; pz = -0.56; rx = -0.5; rz = 0.1; }
  if (id === 'spear') { rx = -1.3; rz = 0.05; py = -0.24; pz = -0.35; }
  if (id === 'rod') { rx = -0.75; rz = 0.15; }
  if (P.swingT > 0) {
    if (k === 'chop' || k === 'swing') {
      var a1 = sw < 0.6 ? smooth(0, 1, sw / 0.6) * 0.95 : sw < 0.88 ? lerp(0.95, -1.15, smooth(0, 1, (sw - 0.6) / 0.28)) : lerp(-1.15, -0.95, (sw - 0.88) / 0.12);
      rx += a1; var fw = sw > 0.6 ? Math.sin(clamp((sw - 0.6) / 0.4, 0, 1) * Math.PI) : 0; pz -= fw * 0.16; py -= fw * 0.06; px -= fw * 0.06; rz += a1 * 0.15;
    } else if (k === 'stab') { var e = Math.sin(sw * Math.PI); pz -= e * 0.38; py += e * 0.04; }
    else if (k === 'eat' || k === 'drink') { var e2 = Math.sin(sw * Math.PI); px -= e2 * 0.2; py += e2 * 0.17; pz += e2 * 0.12; rx += e2 * 0.7; }
    else if (k === 'grab') { var e3 = Math.sin(sw * Math.PI); py -= e3 * 0.22; pz -= e3 * 0.12; rx -= e3 * 0.6; }
    else if (k === 'cast') { rx += Math.sin(sw * Math.PI * 2) * 0.7; }
  }
  var itemRows = new Float32Array(12); mat34e(VL, 0, px, py, pz, rx, ry, rz, tool ? 1 : 0.68); mul34(itemRows, VW, VL);
  /* рука: кулак на руків'ї, рукав іде вниз-назад з кадру */
  var hand = new Float32Array(12); mat34e(VL, 0, 0, tool ? -0.08 : -0.05, tool ? 0 : 0.02, -0.85, 0, 0, tool ? 1.05 : 1.1); mul34(hand, itemRows, VL);
  if (mdl) drawMesh(VM.hand, null, hand);
  if (mdl) {
    var o = itemRows; if (!tool) { o = new Float32Array(12); mat34e(VL, 0, 0, 0.06, -0.01, 0, 0, 0, 1); mul34(o, itemRows, VL); }
    drawMesh(mdl, null, o);
    if (id === 'rod' && FISH.st !== 'none' && !FISH.spear) {
      var tipx = o[3] + o[1] * 0.95, tipy = o[7] + o[5] * 0.95, tipz = o[11] + o[9] * 0.95, by2 = WATER_Y + (FISH.st === 'bite' ? -0.06 : 0.01);
      lineAdd([tipx, tipy, tipz], [FISH.x, by2 + 0.04, FISH.z], [0.9, 0.9, 0.9, 0.7]);
    }
  }
  /* ліва рука з факелом */
  if (P.torch > 0) {
    var tr = drawVM(VM.torch, -0.3 - bx + vmSway[0] * 0.5, -0.32 + by + vmSway[1], -0.6, -0.3, 0, -0.12, 1);
    var tx = tr[3] + tr[1] * 0.3, ty = tr[7] + tr[5] * 0.3, tz = tr[11] + tr[9] * 0.3; P.torchPos = [tx, ty, tz];
    for (var fq = 0; fq < 2; fq++) if (Math.random() < 0.7 * Q.part + 0.3) spawnP(tx + rnd(-0.012, 0.012), ty + 0.01, tz + rnd(-0.012, 0.012), rnd(-0.02, 0.02), rnd(0.12, 0.3), rnd(-0.02, 0.02), rnd(0.12, 0.26), rnd(0.55, 1.0), 1, rnd(0.45, 0.72), 0.14, 0.9, true, -0.2, 1, -1.6);
    if (Math.random() < 0.06) spawnP(tx, ty + 0.05, tz, rnd(-0.1, 0.1), rnd(0.4, 0.8), rnd(-0.1, 0.1), rnd(0.5, 0.9), 0.25, 1, 0.6, 0.2, 1, true, -0.2, 0.3);
  } else P.torchPos = null;
}
var BOBBER_ROWS = null;
