/* =====================================================================
   ЗВУК: усе синтезується WebAudio (без файлів — працює офлайн)
   ===================================================================== */
var AU = {
  ctx: null, out: null, wet: null, nb: null, on: false, L: {},
  init: function () {
    if (this.ctx) { try { this.ctx.resume(); } catch (e) { } return; }
    try {
      var C = window.AudioContext || window.webkitAudioContext; if (!C) return;
      var c = this.ctx = new C();
      this.out = c.createGain(); this.out.gain.value = SET.vol;
      var comp = c.createDynamicsCompressor(); this.out.connect(comp); comp.connect(c.destination);
      var len = Math.floor(c.sampleRate * 1.8), ib = c.createBuffer(2, len, c.sampleRate);
      for (var ch = 0; ch < 2; ch++) { var d = ib.getChannelData(ch); for (var i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, 2.6); }
      var conv = c.createConvolver(); conv.buffer = ib; this.wet = c.createGain(); this.wet.gain.value = 0.28; this.wet.connect(conv); conv.connect(this.out);
      var nl = c.sampleRate * 2, nb = this.nb = c.createBuffer(1, nl, c.sampleRate), nd = nb.getChannelData(0);
      for (var j = 0; j < nl; j++) nd[j] = Math.random() * 2 - 1;
      this.on = true; this.loops();
      if (c.state === 'suspended') c.resume();
    } catch (e) { this.on = false; }
  },
  vol: function (v) { if (this.out) this.out.gain.value = v; },
  tone: function (f, d, type, v, to, delay, wet) {
    if (!this.on) return; var c = this.ctx, t0 = c.currentTime + (delay || 0);
    var o = c.createOscillator(), g = c.createGain(); o.type = type || 'sine'; o.frequency.setValueAtTime(f, t0);
    if (to) o.frequency.exponentialRampToValueAtTime(Math.max(20, to), t0 + d);
    g.gain.setValueAtTime(0.0001, t0); g.gain.exponentialRampToValueAtTime(v || 0.1, t0 + 0.012); g.gain.exponentialRampToValueAtTime(0.0001, t0 + d);
    o.connect(g); g.connect(this.out); if (wet) { var w = c.createGain(); w.gain.value = wet; g.connect(w); w.connect(this.wet); }
    o.start(t0); o.stop(t0 + d + 0.05);
  },
  noise: function (d, v, ft, f0, f1, delay, q, wet) {
    if (!this.on) return; var c = this.ctx, t0 = c.currentTime + (delay || 0);
    var s = c.createBufferSource(); s.buffer = this.nb; s.playbackRate.value = 0.8 + Math.random() * 0.4;
    var f = c.createBiquadFilter(); f.type = ft || 'lowpass'; f.frequency.setValueAtTime(f0 || 800, t0); if (f1) f.frequency.exponentialRampToValueAtTime(Math.max(30, f1), t0 + d); f.Q.value = q || 1;
    var g = c.createGain(); g.gain.setValueAtTime(0.0001, t0); g.gain.exponentialRampToValueAtTime(v || 0.1, t0 + 0.01); g.gain.exponentialRampToValueAtTime(0.0001, t0 + d);
    s.connect(f); f.connect(g); g.connect(this.out); if (wet) { var w = c.createGain(); w.gain.value = wet; g.connect(w); w.connect(this.wet); }
    s.start(t0, Math.random() * 1.5); s.stop(t0 + d + 0.05);
  },
  /* безперервні фони: вітер, дощ, цвіркуни, вогонь, вода */
  loop: function (ft, f0, q, lfoF, lfoA) {
    var c = this.ctx, s = c.createBufferSource(); s.buffer = this.nb; s.loop = true;
    var f = c.createBiquadFilter(); f.type = ft; f.frequency.value = f0; f.Q.value = q;
    var g = c.createGain(); g.gain.value = 0; s.connect(f); f.connect(g); g.connect(this.out);
    if (lfoF) { var l = c.createOscillator(), la = c.createGain(); l.frequency.value = lfoF; la.gain.value = lfoA; l.connect(la); la.connect(f.frequency); l.start(); }
    s.start(0, Math.random()); return { g: g, f: f };
  },
  loops: function () {
    this.L.wind = this.loop('bandpass', 380, 0.5, 0.08, 220);
    this.L.rain = this.loop('highpass', 1400, 0.4, 0, 0);
    this.L.rain2 = this.loop('lowpass', 500, 0.6, 0, 0);
    this.L.fire = this.loop('bandpass', 900, 0.4, 7, 500);
    this.L.water = this.loop('bandpass', 600, 1.2, 0.3, 250);
    var c = this.ctx, o = c.createOscillator(), g = c.createGain(), am = c.createOscillator(), amg = c.createGain();
    o.type = 'sine'; o.frequency.value = 4300; am.frequency.value = 22; amg.gain.value = 0.5; am.connect(amg); amg.connect(g.gain);
    g.gain.value = 0; var cg = c.createGain(); cg.gain.value = 0; o.connect(g); g.connect(cg); cg.connect(this.out); o.start(); am.start();
    this.L.crick = { g: cg };
  },
  setLoop: function (k, v) { if (!this.on || !this.L[k]) return; var g = this.L[k].g.gain; g.setTargetAtTime(v, this.ctx.currentTime, 0.4); },
  /* разові звуки */
  step: function (water) {
    if (water) { this.noise(0.18, 0.08, 'lowpass', 900, 300, 0, 1, 0.1); return; }
    this.noise(0.07, 0.07, 'bandpass', 520 * rnd(0.85, 1.2), 300, 0, 1.2, 0.05); this.tone(60 * rnd(0.9, 1.1), 0.08, 'sine', 0.06, 40);
  },
  pickup: function () { this.tone(660, 0.07, 'triangle', 0.08); this.tone(990, 0.1, 'triangle', 0.07, null, 0.06); },
  rustle: function () { for (var i = 0; i < 3; i++) this.noise(0.14, 0.09, 'highpass', 2500, 4500, i * 0.07, 0.8, 0.1); },
  click: function () { this.tone(880, 0.04, 'square', 0.04, 600); },
  open: function () { this.noise(0.18, 0.06, 'lowpass', 1600, 300); },
  craft: function () { [523, 659, 784].forEach(function (f, i) { AU.tone(f, 0.14, 'triangle', 0.08, null, i * 0.07, 0.4); }); },
  error: function () { this.tone(170, 0.2, 'sawtooth', 0.07, 120); },
  snap: function () { this.noise(0.12, 0.18, 'highpass', 2000, 600); this.tone(300, 0.1, 'square', 0.06, 120); },
  eat: function () { for (var i = 0; i < 4; i++) this.noise(0.07, 0.1, 'bandpass', 1500, 700, i * 0.11, 2, 0.05); },
  drink: function () { this.tone(rnd(500, 650), 0.09, 'sine', 0.07, rnd(950, 1150)); this.noise(0.2, 0.04, 'lowpass', 900, 400); },
  swing: function () { this.noise(0.16, 0.07, 'bandpass', 1200, 400, 0, 2); },
  chop: function () { this.noise(0.1, 0.22, 'bandpass', 800, 350, 0, 1.4, 0.15); this.tone(120, 0.13, 'square', 0.1, 70); this.tone(85, 0.18, 'sine', 0.16, 50, 0.01); },
  creak: function () { this.tone(140, 1.1, 'sawtooth', 0.05, 70, 0, 0.3); this.tone(210, 0.9, 'triangle', 0.035, 110, 0.2, 0.3); },
  crash: function () { this.noise(0.9, 0.3, 'lowpass', 900, 80, 0, 1, 0.4); this.tone(55, 0.8, 'sine', 0.3, 30); for (var i = 0; i < 6; i++) this.noise(0.15, 0.1, 'highpass', 2500, 3000, 0.1 + i * 0.07, 1, 0.2); },
  splash: function (v) { this.noise(0.35, v || 0.14, 'lowpass', 1400, 300, 0, 1, 0.3); this.tone(300, 0.2, 'sine', 0.06, 150); },
  plop: function () { this.tone(500, 0.12, 'sine', 0.1, 180); this.noise(0.12, 0.05, 'lowpass', 1200, 400); },
  catchFish: function () { this.splash(0.18); [600, 800, 1000].forEach(function (f, i) { AU.tone(f, 0.12, 'triangle', 0.08, null, 0.15 + i * 0.08, 0.4); }); },
  hurt: function () { this.tone(110, 0.25, 'sawtooth', 0.12, 60); this.noise(0.15, 0.1, 'lowpass', 700, 200); },
  growl: function () { this.tone(80, 0.6, 'sawtooth', 0.07, 60); this.noise(0.5, 0.05, 'lowpass', 300, 150); },
  yelp: function () { this.tone(900, 0.25, 'triangle', 0.08, 500); this.tone(700, 0.2, 'triangle', 0.06, 400, 0.15); },
  howl: function () { var b = rnd(380, 460); this.tone(b * 0.8, 2.6, 'sine', 0.05, b * 1.25, 0, 0.8); this.tone(b * 1.25, 1.4, 'sine', 0.04, b * 0.9, 1.6, 0.8); },
  thunder: function (d) { var dl = d || 0; this.noise(2.6, 0.32, 'lowpass', 300, 40, dl, 1, 0.6); this.noise(0.4, 0.2, 'lowpass', 1600, 200, dl, 1, 0.3); this.tone(40, 2, 'sine', 0.2, 25, dl); },
  crackle: function () { for (var i = 0; i < 4; i++) this.noise(0.04, 0.08, 'highpass', 2500, 3500, i * 0.07 + Math.random() * 0.05, 1, 0.1); },
  ignite: function () { this.noise(0.6, 0.18, 'bandpass', 600, 1500, 0, 0.8, 0.2); this.crackle(); },
  drillTick: function () { this.noise(0.08, 0.05, 'bandpass', 1800, 900, 0, 3); },
  bird: function () { var b = rnd(2400, 3900); for (var i = 0; i < 3; i++) this.tone(b, 0.07, 'sine', 0.03, b * 1.35, i * 0.11, 0.6); },
  glitch: function () { this.noise(0.35, 0.1, 'highpass', 1500, 5000, 0, 1, 0.2); for (var i = 0; i < 5; i++) this.tone(rnd(200, 2000), 0.04, 'square', 0.04, null, i * 0.05, 0.1); },
  radio: function () { this.noise(0.5, 0.06, 'bandpass', 2200, 1800, 0, 4); this.tone(1200, 0.08, 'sine', 0.05, null, 0.45); },
  beep: function (i) { this.tone(900 + (i || 0) * 60, 0.06, 'square', 0.04); },
  motor: function () { this.tone(90, 3.5, 'sawtooth', 0.03, 70, 0, 0.3); this.noise(3.5, 0.03, 'bandpass', 400, 300, 0, 2); },
  thud: function () { this.tone(70, 0.4, 'sine', 0.22, 35); this.noise(0.3, 0.1, 'lowpass', 400, 100); },
  sleep: function () { [392, 330, 262].forEach(function (f, i) { AU.tone(f, 0.6, 'sine', 0.07, null, i * 0.35, 0.7); }); },
  win: function () { [523, 659, 784, 1046, 1318].forEach(function (f, i) { AU.tone(f, 0.3, 'triangle', 0.08, null, i * 0.1, 0.6); }); },
  death: function () { [330, 262, 196, 147].forEach(function (f, i) { AU.tone(f, 0.7, 'sine', 0.1, f * 0.9, i * 0.4, 0.7); }); },
  heart: function () { this.tone(55, 0.12, 'sine', 0.2, 40); this.tone(50, 0.12, 'sine', 0.16, 38, 0.18); }
};
