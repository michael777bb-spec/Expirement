/* =====================================================================
   ЕФЕКТИ (частинки, дощ, блискавка) і ЖИВНІСТЬ (вовки, зайці, птахи, риба)
   ===================================================================== */
var PT = { list: [], max: Math.floor(1400 * Q.part) + 200, add: null, alp: null };
function ptInit() { PT.add = new DynMesh(PT.max, gl.POINTS, true); PT.alp = new DynMesh(PT.max, gl.POINTS, true); }
function spawnP(x, y, z, vx, vy, vz, life, size, r, g, b, a, add, grav, drag, grow) {
  if (PT.list.length >= PT.max) return;
  PT.list.push({ x: x, y: y, z: z, vx: vx, vy: vy, vz: vz, life: life, max: life, size: size, r: r, g: g, b: b, a: a, add: add, grav: grav || 0, drag: drag || 0, grow: grow || 0 });
}
var PRE = {
  chips: function (x, y, z, n) { for (var i = 0; i < n; i++) spawnP(x, y, z, rnd(-2, 2), rnd(1, 3.5), rnd(-2, 2), rnd(0.5, 1), rnd(3, 6), 0.75, 0.58, 0.35, 1, false, 9, 0.5); },
  leaves: function (x, y, z, n, sp) { for (var i = 0; i < n; i++) spawnP(x + rnd(-sp, sp), y + rnd(-1, 1.5), z + rnd(-sp, sp), rnd(-1, 1), rnd(-0.3, 0.6), rnd(-1, 1), rnd(1.5, 3.2), rnd(4, 8), rnd(0.25, 0.45), rnd(0.45, 0.6), 0.15, 1, false, 1.4, 1.2); },
  dust: function (x, y, z, n) { for (var i = 0; i < n; i++) spawnP(x + rnd(-1.5, 1.5), y, z + rnd(-1.5, 1.5), rnd(-1, 1), rnd(0.3, 1.2), rnd(-1, 1), rnd(1, 2), rnd(12, 26), 0.55, 0.5, 0.4, 0.35, false, -0.2, 1.5, 12); },
  splash: function (x, y, z, n) { for (var i = 0; i < n; i++) spawnP(x, y, z, rnd(-1.5, 1.5), rnd(1.5, 3.5), rnd(-1.5, 1.5), rnd(0.4, 0.8), rnd(3, 6), 0.8, 0.9, 1, 0.8, false, 9, 0.2); },
  blood: function (x, y, z, n) { for (var i = 0; i < n; i++) spawnP(x, y, z, rnd(-1, 1), rnd(0.5, 2), rnd(-1, 1), rnd(0.4, 0.7), rnd(3, 5), 0.5, 0.03, 0.03, 1, false, 8, 0.2); },
  steam: function (x, y, z) { spawnP(x + rnd(-0.1, 0.1), y, z + rnd(-0.1, 0.1), rnd(-0.1, 0.1), rnd(0.4, 0.8), rnd(-0.1, 0.1), rnd(1, 1.8), 10, 0.9, 0.92, 0.95, 0.35, false, -0.1, 0.5, 14); },
  breath: function (x, y, z, fx, fz) { spawnP(x + fx * 0.3, y - 0.1, z + fz * 0.3, fx * 0.5, 0.15, fz * 0.5, rnd(0.8, 1.3), 6, 0.92, 0.94, 0.97, 0.25, false, -0.1, 1, 10); },
  flame: function (x, y, z, k) { spawnP(x + rnd(-0.18, 0.18) * k, y, z + rnd(-0.18, 0.18) * k, rnd(-0.15, 0.15), rnd(0.9, 1.8) * k, rnd(-0.15, 0.15), rnd(0.35, 0.7), rnd(14, 24) * k, 1, rnd(0.45, 0.7), 0.15, 0.9, true, -0.5, 0.8, -12); },
  ember: function (x, y, z) { spawnP(x, y, z, rnd(-0.4, 0.4), rnd(1.5, 3), rnd(-0.4, 0.4), rnd(0.8, 1.6), rnd(2, 3.5), 1, 0.6, 0.2, 1, true, -0.4, 0.3); },
  smoke: function (x, y, z, k) { spawnP(x + rnd(-0.1, 0.1), y, z + rnd(-0.1, 0.1), rnd(-0.2, 0.2) + ENV.wind[0] * 0.3, rnd(0.6, 1.1), rnd(-0.2, 0.2), rnd(2.5, 4.5), 18, 0.35, 0.35, 0.36, 0.28 * k, false, -0.15, 0.4, 22); },
  spark: function (x, y, z, n) { for (var i = 0; i < n; i++) spawnP(x, y, z, rnd(-2, 2), rnd(0.5, 3), rnd(-2, 2), rnd(0.3, 0.7), rnd(2, 4), 1, 0.8, 0.3, 1, true, 6, 0.2); },
  firefly: function (x, y, z) { spawnP(x, y, z, rnd(-0.3, 0.3), rnd(-0.1, 0.2), rnd(-0.3, 0.3), rnd(2, 4), rnd(3, 5), 0.85, 1, 0.45, 0.9, true, 0, 0.1); }
};
var PT_IMM = []; // миттєві точки на один кадр (очі вовків)
function ptUpdate(dt) {
  var L = PT.list, a = PT.add, b = PT.alp; a.n = 0; b.n = 0;
  for (var i = L.length - 1; i >= 0; i--) {
    var p = L[i]; p.life -= dt; if (p.life <= 0) { L[i] = L[L.length - 1]; L.pop(); continue; }
    p.vy -= p.grav * dt; var dr = 1 - p.drag * dt; p.vx *= dr; p.vy *= dr; p.vz *= dr;
    p.x += p.vx * dt; p.y += p.vy * dt; p.z += p.vz * dt; p.size = Math.max(1, p.size + p.grow * dt);
    var k = p.life / p.max, al = p.a * (p.add ? k : Math.min(1, k * 2.5));
    var m = p.add ? a : b, o = m.n; if (o >= m.max) continue;
    m.pos[o * 3] = p.x; m.pos[o * 3 + 1] = p.y; m.pos[o * 3 + 2] = p.z;
    m.col[o * 4] = p.r * 255; m.col[o * 4 + 1] = p.g * 255; m.col[o * 4 + 2] = p.b * 255; m.col[o * 4 + 3] = al * 255;
    m.uv[o * 2] = p.size; m.uv[o * 2 + 1] = 1; m.n++;
  }
  for (var j = 0; j < PT_IMM.length; j++) { var q = PT_IMM[j], o2 = a.n; if (o2 >= a.max) break; a.pos.set([q[0], q[1], q[2]], o2 * 3); a.col[o2 * 4] = q[3] * 255; a.col[o2 * 4 + 1] = q[4] * 255; a.col[o2 * 4 + 2] = q[5] * 255; a.col[o2 * 4 + 3] = q[6] * 255; a.uv[o2 * 2] = q[7]; a.uv[o2 * 2 + 1] = 0.3; a.n++; }
  PT_IMM.length = 0;
}
function ptDraw() {
  var u = useProg(PR.pt); gl.uniform1f(u.uPS, canvas.height * 0.06); gl.uniform1f(u.uPM, GLP.maxPoint);
  gl.depthMask(false); gl.enable(gl.BLEND);
  [[PT.alp, false], [PT.add, true]].forEach(function (e) {
    var m = e[0]; if (!m.n) return; m.upload();
    if (e[1]) gl.blendFunc(gl.SRC_ALPHA, gl.ONE); else gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);
    bindAttr(0, m.bp, 3, gl.FLOAT, false); aEn(1, false); bindAttr(2, m.bc, 4, gl.UNSIGNED_BYTE, true); bindAttr(7, m.bu, 2, gl.FLOAT, false);
    gl.drawArrays(gl.POINTS, 0, m.n);
  });
  gl.disable(gl.BLEND); gl.depthMask(true);
}

/* ---------- дощ (лінії навколо камери) ---------- */
var RAIN = { n: Q.rain, mesh: null, d: [] };
function rainInit() {
  RAIN.mesh = new DynMesh(RAIN.n * 2, gl.LINES, false);
  for (var i = 0; i < RAIN.n; i++) RAIN.d.push([rnd(-16, 16), rnd(0, 14), rnd(-16, 16), rnd(13, 17)]);
}
function rainDraw(dt) {
  if (ENV.rain < 0.02) return;
  var m = RAIN.mesh, n = Math.floor(RAIN.n * Math.min(1, ENV.rain)), wx = ENV.wind[0] * 1.6, k = 0;
  for (var i = 0; i < n; i++) {
    var d = RAIN.d[i]; d[1] -= d[3] * dt; d[0] += wx * dt;
    var x = CAM.x + d[0], z = CAM.z + d[2], y = CAM.y - 2 + d[1];
    if (y < H(x, z) || d[1] < -2) { d[1] = rnd(10, 15); d[0] = rnd(-16, 16); d[2] = rnd(-16, 16); if (Math.random() < 0.15 && d[0] * d[0] + d[2] * d[2] < 60) PRE.splash(x, Math.max(H(x, z), WATER_Y) + 0.02, z, 1); continue; }
    var o = k * 2; m.pos.set([x, y, z, x - wx * 0.03, y + 0.45, z], o * 3);
    for (var j = 0; j < 2; j++) { m.col[(o + j) * 4] = 180; m.col[(o + j) * 4 + 1] = 190; m.col[(o + j) * 4 + 2] = 205; m.col[(o + j) * 4 + 3] = j ? 0 : 90 * ENV.rain + 30; }
    k++;
  }
  m.n = k * 2; if (!m.n) return; m.upload();
  useProg(PR.ln); gl.enable(gl.BLEND); gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA); gl.depthMask(false);
  bindAttr(0, m.bp, 3, gl.FLOAT, false); aEn(1, false); bindAttr(2, m.bc, 4, gl.UNSIGNED_BYTE, true); aEn(7, false);
  gl.drawArrays(gl.LINES, 0, m.n); gl.depthMask(true); gl.disable(gl.BLEND);
}
/* лінія волосіні та тросу ящика */
var LINES = { mesh: null, list: [] };
function lineAdd(a, b, c) { LINES.list.push(a, b, c); }
function linesDraw() {
  if (!LINES.mesh) LINES.mesh = new DynMesh(64, gl.LINES, false);
  var m = LINES.mesh, L = LINES.list; m.n = 0;
  for (var i = 0; i < L.length && m.n < 62; i += 3) { var a = L[i], b = L[i + 1], c = L[i + 2]; m.pos.set(a, m.n * 3); m.pos.set(b, m.n * 3 + 3); for (var j = 0; j < 2; j++) { m.col.set([c[0] * 255, c[1] * 255, c[2] * 255, (c[3] || 1) * 255], (m.n + j) * 4); } m.n += 2; }
  L.length = 0; if (!m.n) return; m.upload();
  useProg(PR.ln); gl.enable(gl.BLEND); gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);
  bindAttr(0, m.bp, 3, gl.FLOAT, false); aEn(1, false); bindAttr(2, m.bc, 4, gl.UNSIGNED_BYTE, true); aEn(7, false);
  gl.drawArrays(gl.LINES, 0, m.n); gl.disable(gl.BLEND);
}

/* ---------- вовки ---------- */
var WOLF_M = null, RABBIT_M = null, BIRD_G = null, FISH_M = null;
var WOLVES = [], RABBITS = [], BIRDS = [], FJUMP = [];
var tmp12 = new Float32Array(12), tmp12b = new Float32Array(12);
function lifeInit() {
  WOLF_M = mdlWolf(); RABBIT_M = mdlRabbit(); FISH_M = mdlFish();
  BIRD_G = { mesh: mdlBird(), ib: null }; BIRD_G.ib = new IB(6);
  for (var i = 0; i < 6; i++) BIRDS.push({ r: 18 + i * 3, h: 17 + (i % 3) * 2.5, ph: i * 1.05, cx: 70 + (i % 2) * 50, cz: (i % 3 - 1) * 6 });
  for (var r = 0; r < 9; r++) RABBITS.push(mkRabbit());
}
function mkRabbit() { var x, z, k = 0; do { x = rnd(10, X1 - 10); z = rnd(-ZLIM + 3, ZLIM - 3); k++; } while ((inPond(x, z, 1) || Math.hypot(x - P.x, z - P.z) < 20) && k < 30); return { x: x, z: z, yaw: rnd(0, TAU), st: 'idle', t: rnd(1, 4), hop: 0, vis: true, speed: 0 }; }
function spawnWolf() {
  var side = Math.random() < 0.5 ? -1 : 1, x = clamp(P.x + rnd(-40, 40), 5, X1 - 5), z = side * (ZLIM - 1);
  WOLVES.push({ x: x, z: z, yaw: 0, st: 'roam', t: rnd(3, 8), hp: 3, speed: 0, gait: 0, cd: 0, orb: rnd(0, TAU), orbDir: Math.random() < 0.5 ? -1 : 1, flee: 0, dead: false, deadT: 0, growled: false });
}
function wolfFear(w) {
  var fear = 0, dP = Math.hypot(w.x - P.x, w.z - P.z);
  FIRES.forEach(function (f) { if (f.st === 'lit' && Math.hypot(f.x - P.x, f.z - P.z) < 9) fear = Math.max(fear, 14); });
  if (P.torch > 0) fear = Math.max(fear, 7.5);
  return fear;
}
function wolvesUpdate(dt) {
  var night = ENV.dayK < 0.25;
  for (var i = WOLVES.length - 1; i >= 0; i--) {
    var w = WOLVES[i];
    if (w.dead) { w.deadT += dt; if (w.deadT > 40) WOLVES.splice(i, 1); continue; }
    var dx = P.x - w.x, dz = P.z - w.z, d = Math.hypot(dx, dz) || 0.01, fear = wolfFear(w), tx = w.x, tz = w.z, sp = 0;
    w.t -= dt; w.cd = Math.max(0, w.cd - dt);
    if (!night && w.st !== 'leave') { w.st = 'leave'; }
    if (w.flee > 0) { w.flee -= dt; tx = w.x - dx / d * 10; tz = w.z - dz / d * 10; sp = 7.5; }
    else if (w.st === 'leave') { tx = w.x; tz = (w.z > 0 ? 1 : -1) * (CR + 4); sp = 6; if (Math.abs(w.z) > ZLIM + 0.5) { WOLVES.splice(i, 1); continue; } }
    else {
      var keep = fear ? fear : (G.sleeping ? 0 : 0);
      if (fear || w.st === 'roam') {
        // кружляє на відстані
        w.orb += dt * 0.25 * w.orbDir; var R = fear ? fear + 2 : 24;
        tx = P.x + Math.cos(w.orb) * R; tz = P.z + Math.sin(w.orb) * R; sp = d > R + 6 ? 6 : 2.2;
        if (!fear && w.t <= 0) { w.st = 'stalk'; w.t = rnd(6, 12); }
      }
      if (!fear && w.st === 'stalk') { tx = P.x - dx / d * 9; tz = P.z - dz / d * 9; sp = 3; if (d < 11 && w.t <= 0) { w.st = 'attack'; } if (!w.growled && d < 14) { w.growled = true; AU.growl(); } }
      if (!fear && w.st === 'attack') { tx = P.x; tz = P.z; sp = 8.5; if (d < 1.5 && w.cd <= 0 && !S.ended) { wolfBite(w); w.cd = 2.2; w.st = 'retreat'; w.t = rnd(5, 9); } }
      if (w.st === 'retreat') { tx = w.x - dx / d * 8; tz = w.z - dz / d * 8; sp = 6; if (w.t <= 0) { w.st = 'stalk'; w.t = rnd(3, 6); w.growled = false; } }
      if (fear && (w.st === 'attack' || w.st === 'stalk')) { w.st = 'roam'; w.t = rnd(6, 12); }
    }
    var mx = tx - w.x, mz = tz - w.z, ml = Math.hypot(mx, mz);
    if (ml > 0.3) { var ty = Math.atan2(-mx, -mz), dy = ((ty - w.yaw + Math.PI * 3) % TAU) - Math.PI; w.yaw += clamp(dy, -4 * dt, 4 * dt); }
    w.speed = lerp(w.speed, ml > 0.3 ? sp : 0, Math.min(1, dt * 3));
    var nx = w.x - Math.sin(w.yaw) * w.speed * dt, nz = w.z - Math.cos(w.yaw) * w.speed * dt;
    if (!inPond(nx, nz, 0.3) && Math.abs(nz) < CR + 6) { w.x = clamp(nx, 2, X1 - 2); w.z = nz; } else w.yaw += 1.5 * dt;
    w.gait += w.speed * dt * 2.2;
  }
}
function wolfBite(w) {
  var dmg = rnd(9, 15); harm(dmg, 'wolf'); AU.growl(); AU.hurt(); P.shake = 0.45; S.hurtT = 0.6;
  PRE.blood(P.x, H(P.x, P.z) + 1, P.z, 8);
  if (Math.random() < 0.55 && !S.bleed) { S.bleed = 1; toast(t('msg.bleed'), 'bleed', 'bad'); tip('bleed'); } else toast(t('msg.bitten'), 'wolf', 'bad');
  STATS.bitten = (STATS.bitten || 0) + 1; logDay('wolf');
}
function hitWolf(w, dmg) {
  w.hp -= dmg; AU.yelp(); PRE.blood(w.x, H(w.x, w.z) + 0.7, w.z, 6);
  if (w.hp <= 0) { w.dead = true; toast(t('msg.wolfDead'), 'wolf'); STATS.wolves = (STATS.wolves || 0) + 1; addNodeDrop(w.x, w.z, 'meat', 2); return; }
  w.flee = rnd(12, 20); w.st = 'roam'; toast(t('msg.wolfFlee'), 'wolf');
}
function wolvesDraw() {
  var night = ENV.dayK < 0.4;
  WOLVES.forEach(function (w) {
    var y = H(w.x, w.z), dead = w.dead, bob = dead ? 0 : Math.abs(Math.sin(w.gait)) * 0.06 * Math.min(1, w.speed / 3);
    var roll = dead ? Math.PI / 2 : 0;
    mat34e(tmp12, 0, w.x, y + (dead ? 0.3 : 0.72 + bob), w.z, 0, w.yaw, roll, 1);
    drawMesh(WOLF_M.body, null, tmp12);
    var part = function (mesh, lx, ly, lz, rx, s) { mat34e(tmp12b, 0, lx, ly, lz, rx, 0, 0, s || 1); var o = new Float32Array(12); mul34(o, tmp12, tmp12b); drawMesh(mesh, null, o); return o; };
    var hr = part(WOLF_M.head, 0, 0.2, -0.62, dead ? 0 : (w.st === 'stalk' ? 0.3 : -0.1));
    var sw = dead ? 0.3 : Math.sin(w.gait) * 0.6 * Math.min(1, w.speed / 2);
    part(WOLF_M.leg, -0.16, 0, -0.38, sw); part(WOLF_M.leg, 0.16, 0, -0.38, -sw); part(WOLF_M.leg, -0.16, 0, 0.38, -sw); part(WOLF_M.leg, 0.16, 0, 0.38, sw);
    part(WOLF_M.tail, 0, 0.1, 0.6, dead ? 1.6 : 2.2 + Math.sin(w.gait * 0.5) * 0.15);
    if (night && !dead) { // очі світяться
      var ex = hr[3], ey = hr[7] + 0.04, ez = hr[11], fx = -Math.sin(w.yaw) * 0.2, fz = -Math.cos(w.yaw) * 0.2, sx = Math.cos(w.yaw) * 0.075, sz = -Math.sin(w.yaw) * 0.075;
      PT_IMM.push([ex + fx + sx, ey, ez + fz + sz, 1, 0.85, 0.35, 0.95, 4.5], [ex + fx - sx, ey, ez + fz - sz, 1, 0.85, 0.35, 0.95, 4.5]);
    }
  });
}
/* ---------- зайці ---------- */
function rabbitsUpdate(dt) {
  var day = ENV.dayK > 0.3;
  RABBITS.forEach(function (r) {
    r.vis = day; if (!day) return;
    var d = Math.hypot(r.x - P.x, r.z - P.z); r.t -= dt;
    if (d < 7 && r.st !== 'flee') { r.st = 'flee'; r.t = rnd(2, 3.5); r.yaw = Math.atan2(r.x - P.x, r.z - P.z) + Math.PI + rnd(-0.5, 0.5); }
    if (r.t <= 0) { if (r.st === 'flee' || r.st === 'hop') { r.st = 'idle'; r.t = rnd(2, 6); } else { r.st = 'hop'; r.t = rnd(1, 3); r.yaw += rnd(-1.5, 1.5); } }
    var sp = r.st === 'flee' ? 6.5 : r.st === 'hop' ? 1.6 : 0;
    if (sp) { var nx = r.x - Math.sin(r.yaw) * sp * dt, nz = r.z - Math.cos(r.yaw) * sp * dt; if (inPond(nx, nz, 0.5) || Math.abs(nz) > ZLIM || nx < 3 || nx > X1 - 3) r.yaw += 2; else { r.x = nx; r.z = nz; } r.hop += dt * (sp > 2 ? 14 : 9); } else r.hop = 0;
    if (d > 90) { var nr = mkRabbit(); r.x = nr.x; r.z = nr.z; }
  });
}
function rabbitsDraw() {
  RABBITS.forEach(function (r) { if (!r.vis) return; var y = H(r.x, r.z) + Math.abs(Math.sin(r.hop)) * (r.st === 'flee' ? 0.25 : 0.12); mat34e(tmp12, 0, r.x, y, r.z, r.hop ? -Math.cos(r.hop) * 0.2 : 0, r.yaw, 0, 1); drawMesh(RABBIT_M, null, tmp12); });
}
/* ---------- птахи (летять тим самим колом — період 252 с, як у записці) ---------- */
function birdsDraw(time) {
  var day = ENV.dayK > 0.35 && ENV.dark < 0.6, ib = BIRD_G.ib;
  for (var i = 0; i < BIRDS.length; i++) {
    var b = BIRDS[i];
    if (!day) { ib.hide(i); continue; }
    var a = (time % 252) / 252 * TAU + b.ph, x = b.cx + Math.cos(a) * b.r, z = b.cz + Math.sin(a) * b.r * 0.55, flap = Math.sin(time * 9 + i);
    if (SKY.glitch > 0.5) { a = b.ph; flap = 1; }
    mat34(tmp12, 0, x, b.h + Math.sin(a * 3) * 0.6, z, -a - Math.PI / 2 + Math.PI, 1, flap * 0.9 + 0.1, 1, 0, 0, 1); ib.setM(i, tmp12);
  }
  drawMesh(BIRD_G.mesh, ib);
}
/* ---------- риба вистрибує (показує, де клює) ---------- */
var fishT = 8;
function fishUpdate(dt) {
  fishT -= dt;
  if (fishT <= 0) {
    fishT = rnd(10, 26); var p = rpickR(PONDS), a = rnd(0, TAU), r = rnd(0, p.r * 0.75);
    FJUMP.push({ x: p.x + Math.cos(a) * r, z: p.z + Math.sin(a) * r, t: 0, yaw: rnd(0, TAU) });
  }
  for (var i = FJUMP.length - 1; i >= 0; i--) {
    var f = FJUMP[i]; f.t += dt;
    if (f.t > 0.01 && !f.s0) { f.s0 = 1; ripple(f.x, f.z, 0.7); if (Math.hypot(f.x - P.x, f.z - P.z) < 30) { PRE.splash(f.x, WATER_Y, f.z, 6); AU.splash(0.05); } }
    if (f.t > 0.9 && !f.s1) { f.s1 = 1; ripple(f.x - Math.sin(f.yaw) * 0.9, f.z - Math.cos(f.yaw) * 0.9, 1); if (Math.hypot(f.x - P.x, f.z - P.z) < 30) PRE.splash(f.x - Math.sin(f.yaw) * 0.9, WATER_Y, f.z - Math.cos(f.yaw) * 0.9, 8); }
    if (f.t > 1.2) FJUMP.splice(i, 1);
  }
}
function rpickR(a) { return a[Math.floor(Math.random() * a.length)]; }
function fishDraw() {
  FJUMP.forEach(function (f) { if (f.t > 0.9) return; var k = f.t / 0.9, y = WATER_Y + Math.sin(k * Math.PI) * 0.7; mat34e(tmp12, 0, f.x - Math.sin(f.yaw) * k * 0.9, y, f.z - Math.cos(f.yaw) * k * 0.9, (k - 0.5) * 2.4, f.yaw, 0, 1.3); drawMesh(FISH_M, null, tmp12); });
}
var RIP = [[0, 0, 99, 0], [0, 0, 99, 0], [0, 0, 99, 0], [0, 0, 99, 0]], ripI = 0;
function ripple(x, z, s) { RIP[ripI] = [x, z, 0, s || 1]; ripI = (ripI + 1) % 4; }
function ripUpdate(dt) { for (var i = 0; i < 4; i++) { RIP[i][2] += dt; ENV.rip[i * 4] = RIP[i][0]; ENV.rip[i * 4 + 1] = RIP[i][1]; ENV.rip[i * 4 + 2] = RIP[i][2]; ENV.rip[i * 4 + 3] = RIP[i][2] < 4 ? RIP[i][3] : 0; } }
/* скинути здобич на землю (м'ясо з вовка) як тимчасовий вузол */
var DROPS = [];
function addNodeDrop(x, z, id, n) { var d = { x: x, z: z, id: id, n: n }; d.inter = addInter({ kind: 'drop', ref: d, x: x, y: H(x, z) + 0.3, z: z, r: 1.3 }); DROPS.push(d); }
