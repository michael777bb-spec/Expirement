/* ===== Стан гри (зберігається) ===== */
var G, S, P, STATS, UI = { ov: null, arg: null };
function freshState(seed) {
  seed = seed || (Math.floor(Math.random() * 1e9) + 1);
  var r = mulberry32(seed), code = ''; for (var i = 0; i < 4; i++) code += Math.floor(r() * 10);
  G = { v: 1, seed: seed, tot: 8 * 60, t: 0, started: false, paused: false, sleeping: false, flags: {}, code: code, notes: {}, known: { sharp: 1, rope: 1 }, goals: {}, diary: [], radio: [], dayLog: {}, obsLast: {}, events: {}, glitchT: 0 };
  S = { hp: 100, food: 78, water: 70, energy: 100, warm: 100, stamina: 100, bleed: 0, sick: 0, poison: 0, wet: 0, hurtT: 0, ended: false, won: false, lastCause: 'other' };
  P = { x: 22, z: 3, y: 0, vy: 0, onGround: true, yaw: 0.95, pitch: -0.05, bob: 0, stepD: 0, run: false, torch: 0, shake: 0, swingT: 0, swingDur: 0.6, swingKind: '', moving: false, running: false, torchPos: null };
  STATS = { trees: 0, fish: 0, cooked: 0, fires: 0, wolves: 0, bitten: 0 };
}
freshState(1);
