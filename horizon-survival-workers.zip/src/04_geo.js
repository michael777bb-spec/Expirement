/* =====================================================================
   ГЕОМЕТРІЯ: будівельник низькополігональних моделей з кольором вершин
   ===================================================================== */
function GB() { this.p = []; this.n = []; this.c = []; this.uv = []; this.useUV = false; this.M = null; }
GB.prototype.mat = function (m) { this.M = m; return this; };
GB.prototype.tp = function (v) {
  var M = this.M; if (!M) return v;
  return [M[0] * v[0] + M[1] * v[1] + M[2] * v[2] + M[3], M[4] * v[0] + M[5] * v[1] + M[6] * v[2] + M[7], M[8] * v[0] + M[9] * v[1] + M[10] * v[2] + M[11]];
};
/* трикутник: a,b,c — точки; ca..cc — кольори [r,g,b]; sa..sc — вага вітру 0..1 */
GB.prototype.tri = function (a, b, c, ca, cb, cc, sa, sb, sc, uva, uvb, uvc) {
  a = this.tp(a); b = this.tp(b); c = this.tp(c);
  var ux = b[0] - a[0], uy = b[1] - a[1], uz = b[2] - a[2], vx = c[0] - a[0], vy = c[1] - a[1], vz = c[2] - a[2];
  var nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx, l = Math.sqrt(nx * nx + ny * ny + nz * nz) || 1;
  nx /= l; ny /= l; nz /= l;
  this.push(a, nx, ny, nz, ca, sa || 0, uva); this.push(b, nx, ny, nz, cb || ca, sb === undefined ? (sa || 0) : sb, uvb); this.push(c, nx, ny, nz, cc || ca, sc === undefined ? (sa || 0) : sc, uvc);
};
GB.prototype.push = function (p, nx, ny, nz, col, sw, uv) {
  this.p.push(p[0], p[1], p[2]); this.n.push(nx, ny, nz);
  this.c.push(col[0], col[1], col[2], sw); if (this.useUV) this.uv.push(uv ? uv[0] : 0, uv ? uv[1] : 0);
};
/* вершина з окремою нормаллю (для гладкого рельєфу) */
GB.prototype.vtx = function (x, y, z, nx, ny, nz, col, sw) { this.p.push(x, y, z); this.n.push(nx, ny, nz); this.c.push(col[0], col[1], col[2], sw || 0); };
GB.prototype.quad = function (a, b, c, d, ca, cb, cc, cd, s) { this.tri(a, b, c, ca, cb || ca, cc || ca, s, s, s); this.tri(a, c, d, ca, cc || ca, cd || ca, s, s, s); };
function cmix(a, b, t) { return [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t]; }
function cmul(a, k) { return [a[0] * k, a[1] * k, a[2] * k]; }
function cjit(a, j, r) { var k = 1 + (r() - 0.5) * j; return [a[0] * k, a[1] * k * (1 + (r() - 0.5) * j * 0.3), a[2] * k]; }
/* коробка: x,z — центр, y — низ */
GB.prototype.box = function (x, y, z, w, h, d, c, o) {
  o = o || {}; var ct = o.ct || c, cb = o.cb || c, sw = o.sw || 0;
  var x0 = x - w / 2, x1 = x + w / 2, y0 = y, y1 = y + h, z0 = z - d / 2, z1 = z + d / 2;
  var A = [x0, y0, z1], B = [x1, y0, z1], C = [x1, y1, z1], D = [x0, y1, z1], E = [x0, y0, z0], F = [x1, y0, z0], G = [x1, y1, z0], H = [x0, y1, z0];
  this.quad(A, B, C, D, cb, cb, ct, ct, sw); this.quad(F, E, H, G, cb, cb, ct, ct, sw);
  this.quad(B, F, G, C, cb, cb, ct, ct, sw); this.quad(E, A, D, H, cb, cb, ct, ct, sw);
  this.quad(D, C, G, H, ct, ct, ct, ct, sw); if (!o.noBottom) this.quad(E, F, B, A, cb, cb, cb, cb, sw);
  return this;
};
/* циліндр/конус: низ у y, r0 — нижній радіус, r1 — верхній */
GB.prototype.cyl = function (x, y, z, r0, r1, h, seg, c, o) {
  o = o || {}; var c2 = o.c2 || c, sw0 = o.sw0 || 0, sw1 = o.sw1 === undefined ? sw0 : o.sw1, rng = o.rng, jit = o.jit || 0, a0 = o.a0 || 0;
  var pts0 = [], pts1 = [];
  for (var i = 0; i < seg; i++) {
    var a = a0 + i / seg * TAU, j0 = jit && rng ? 1 + (rng() - 0.5) * jit : 1, j1 = jit && rng ? 1 + (rng() - 0.5) * jit : 1;
    pts0.push([x + Math.cos(a) * r0 * j0, y, z + Math.sin(a) * r0 * j0]);
    pts1.push([x + Math.cos(a) * r1 * j1 + (o.lx || 0), y + h, z + Math.sin(a) * r1 * j1 + (o.lz || 0)]);
  }
  for (var k = 0; k < seg; k++) {
    var n = (k + 1) % seg;
    if (r1 > 0.0001) this.quad(pts0[n], pts0[k], pts1[k], pts1[n], c, c, c2, c2, 0), this._sw(4, sw0, sw1);
    else { this.tri(pts0[n], pts0[k], pts1[k], c, c, c2, sw0, sw0, sw1); }
  }
  if (o.cap && r1 > 0.0001) { var ct = o.ct || c2, top = [x + (o.lx || 0), y + h, z + (o.lz || 0)]; for (var q = 0; q < seg; q++) this.tri(pts1[q], top, pts1[(q + 1) % seg], ct, ct, ct, sw1, sw1, sw1); }
  if (o.capB) { var cbm = [x, y, z]; for (var q2 = 0; q2 < seg; q2++) this.tri(pts0[(q2 + 1) % seg], cbm, pts0[q2], c, c, c, sw0, sw0, sw0); }
  return this;
};
/* поправка ваги вітру для останнього квадрата циліндра (верх/низ) */
GB.prototype._sw = function (nTri, s0, s1) {
  if (!s0 && !s1) return;
  var L = this.c.length, base = L - 6 * 4; // 6 вершин
  // порядок: tri(a=p0n,b=p0k,c=p1k) tri(a=p0n,c=p1k,d=p1n)
  var w = [s0, s0, s1, s0, s1, s1];
  for (var i = 0; i < 6; i++) this.c[base + i * 4 + 3] = w[i];
};
/* стрижень між двома точками (гілки, крокви, колоди) */
GB.prototype.rod = function (ax, ay, az, bx, by, bz, r0, r1, seg, c, o) {
  o = o || {}; var c2 = o.c2 || c, sw0 = o.sw0 || 0, sw1 = o.sw1 === undefined ? sw0 : o.sw1;
  var dx = bx - ax, dy = by - ay, dz = bz - az, L = Math.sqrt(dx * dx + dy * dy + dz * dz) || 1; dx /= L; dy /= L; dz /= L;
  var ux = Math.abs(dy) < 0.9 ? 0 : 1, uy = Math.abs(dy) < 0.9 ? 1 : 0, uz = 0;
  var px = dy * uz - dz * uy, py = dz * ux - dx * uz, pz = dx * uy - dy * ux, pl = Math.sqrt(px * px + py * py + pz * pz) || 1; px /= pl; py /= pl; pz /= pl;
  var qx = dy * pz - dz * py, qy = dz * px - dx * pz, qz = dx * py - dy * px;
  var A = [], Bv = [];
  for (var i = 0; i < seg; i++) { var a = i / seg * TAU, ca = Math.cos(a), sa = Math.sin(a);
    A.push([ax + (px * ca + qx * sa) * r0, ay + (py * ca + qy * sa) * r0, az + (pz * ca + qz * sa) * r0]);
    Bv.push([bx + (px * ca + qx * sa) * r1, by + (py * ca + qy * sa) * r1, bz + (pz * ca + qz * sa) * r1]); }
  for (var k = 0; k < seg; k++) { var n = (k + 1) % seg; this.quad(A[k], A[n], Bv[n], Bv[k], c, c, c2, c2, 0); var L2 = this.c.length - 24, w = [sw0, sw0, sw1, sw0, sw1, sw1]; for (var j = 0; j < 6; j++) this.c[L2 + j * 4 + 3] = w[j]; }
  if (o.cap) { var ct = o.ct || c2; for (var q = 0; q < seg; q++) this.tri(Bv[q], Bv[(q + 1) % seg], [bx, by, bz], ct, ct, ct, sw1, sw1, sw1); for (var q2 = 0; q2 < seg; q2++) this.tri(A[(q2 + 1) % seg], A[q2], [ax, ay, az], ct, ct, ct, sw0, sw0, sw0); }
  return this;
};
/* ікосфера (опукла «брила»): гранована, з тремтінням і градієнтом знизу вгору */
var ICO = (function () {
  var t = (1 + Math.sqrt(5)) / 2, v = [[-1, t, 0], [1, t, 0], [-1, -t, 0], [1, -t, 0], [0, -1, t], [0, 1, t], [0, -1, -t], [0, 1, -t], [t, 0, -1], [t, 0, 1], [-t, 0, -1], [-t, 0, 1]];
  v = v.map(function (p) { var l = Math.sqrt(p[0] * p[0] + p[1] * p[1] + p[2] * p[2]); return [p[0] / l, p[1] / l, p[2] / l]; });
  var f = [[0, 11, 5], [0, 5, 1], [0, 1, 7], [0, 7, 10], [0, 10, 11], [1, 5, 9], [5, 11, 4], [11, 10, 2], [10, 7, 6], [7, 1, 8], [3, 9, 4], [3, 4, 2], [3, 2, 6], [3, 6, 8], [3, 8, 9], [4, 9, 5], [2, 4, 11], [6, 2, 10], [8, 6, 7], [9, 8, 1]];
  var cache = {};
  function sub(vs, fs) {
    var nv = vs.slice(), nf = [], mid = {};
    function m(a, b) { var k = a < b ? a + '_' + b : b + '_' + a; if (mid[k] !== undefined) return mid[k]; var p = [(vs[a][0] + vs[b][0]) / 2, (vs[a][1] + vs[b][1]) / 2, (vs[a][2] + vs[b][2]) / 2], l = Math.sqrt(p[0] * p[0] + p[1] * p[1] + p[2] * p[2]); nv.push([p[0] / l, p[1] / l, p[2] / l]); return (mid[k] = nv.length - 1); }
    fs.forEach(function (q) { var a = m(q[0], q[1]), b = m(q[1], q[2]), c = m(q[2], q[0]); nf.push([q[0], a, c], [q[1], b, a], [q[2], c, b], [a, b, c]); });
    return [nv, nf];
  }
  return function (det) { if (cache[det]) return cache[det]; var r = [v, f]; for (var i = 0; i < det; i++) r = sub(r[0], r[1]); return (cache[det] = r); };
})();
GB.prototype.ico = function (x, y, z, rx, ry, rz, c, o) {
  o = o || {}; var d = ICO(o.det === undefined ? 1 : o.det), vs = d[0], fs = d[1], rng = o.rng || Math.random, jit = o.jit || 0;
  var c2 = o.c2 || c, sw = o.sw || 0, flatB = o.flatB;
  var pp = vs.map(function (p) { var k = jit ? 1 + (rng() - 0.5) * jit : 1; var py = p[1]; if (flatB && py < -0.3) py = -0.3 - (py + 0.3) * 0.2; return [x + p[0] * rx * k, y + py * ry * k, z + p[2] * rz * k, p[1]]; });
  for (var i = 0; i < fs.length; i++) {
    var A = pp[fs[i][0]], B = pp[fs[i][1]], C = pp[fs[i][2]];
    var cc = function (P) { var t = (P[3] + 1) / 2; var col = cmix(c, c2, t); if (o.cj) col = cjit(col, o.cj, rng); return col; };
    var swf = function (P) { return sw * clamp((P[3] + 1) / 2 + 0.3, 0, 1); };
    this.tri(A, B, C, cc(A), cc(B), cc(C), swf(A), swf(B), swf(C));
  }
  return this;
};
GB.prototype.build = function (opt) {
  opt = opt || {}; var n = this.p.length / 3;
  var pos = new Float32Array(this.p), nor = new Int8Array(this.n.length), col = new Uint8Array(this.c.length);
  for (var i = 0; i < this.n.length; i++) nor[i] = clamp(Math.round(this.n[i] * 127), -127, 127);
  for (var k = 0; k < this.c.length; k++) col[k] = clamp(Math.round(this.c[k] * 255), 0, 255);
  var mn = [1e9, 1e9, 1e9], mx = [-1e9, -1e9, -1e9];
  for (var j = 0; j < n; j++) for (var a = 0; a < 3; a++) { var v = pos[j * 3 + a]; if (v < mn[a]) mn[a] = v; if (v > mx[a]) mx[a] = v; }
  var cx = (mn[0] + mx[0]) / 2, cy = (mn[1] + mx[1]) / 2, cz = (mn[2] + mx[2]) / 2, r = 0;
  for (var q = 0; q < n; q++) { var dx = pos[q * 3] - cx, dy = pos[q * 3 + 1] - cy, dz = pos[q * 3 + 2] - cz; r = Math.max(r, dx * dx + dy * dy + dz * dz); }
  var m = new Mesh({ n: n, pos: pos, nor: nor, col: col, uv: this.useUV ? new Float32Array(this.uv) : null, bs: [cx, cy, cz, Math.sqrt(r)], cull: opt.cull });
  m.h = mx[1]; m.r = Math.max(mx[0] - mn[0], mx[2] - mn[2]) / 2;
  return m;
};

/* ---------- палітра ---------- */
var COL = {
  bark: [0.33, 0.24, 0.16], barkD: [0.2, 0.14, 0.09], oak: [0.2, 0.38, 0.12], oak2: [0.36, 0.56, 0.2],
  pine: [0.09, 0.23, 0.12], pine2: [0.17, 0.36, 0.17], birch: [0.86, 0.85, 0.79], birchD: [0.13, 0.13, 0.12], birchL: [0.38, 0.56, 0.17], birchL2: [0.58, 0.72, 0.28],
  grass: [0.25, 0.44, 0.13], grass2: [0.56, 0.7, 0.26], dry: [0.55, 0.53, 0.27], stone: [0.47, 0.47, 0.45], stone2: [0.62, 0.62, 0.6], moss: [0.3, 0.42, 0.15],
  wood: [0.62, 0.45, 0.27], woodL: [0.82, 0.68, 0.45], ash: [0.2, 0.2, 0.2], skin: [0.86, 0.66, 0.52], rope: [0.72, 0.6, 0.38], metal: [0.45, 0.48, 0.5]
};

/* ---------- дерева: 3 варіанти кожного виду ---------- */
function mdlOak(seed, apple) {
  var r = mulberry32(seed), g = new GB(), h = 3.0 + r() * 0.8;
  g.cyl(0, -0.3, 0, 0.36, 0.24, h + 0.3, 7, COL.barkD, { c2: COL.bark, rng: r, jit: 0.15, cap: true });
  for (var b = 0; b < 4; b++) { var a = r() * TAU, by = h * (0.55 + r() * 0.3); g.rod(0, by, 0, Math.cos(a) * 1.3, by + 0.9 + r() * 0.4, Math.sin(a) * 1.3, 0.11, 0.05, 5, COL.bark, { sw1: 0.25 }); }
  var n = 6 + Math.floor(r() * 3);
  for (var i = 0; i < n; i++) {
    var aa = i / n * TAU + r() * 0.6, d = 0.6 + r() * 1.0, cr = 1.4 + r() * 0.8, cy = h + 0.3 + r() * 1.2;
    g.ico(Math.cos(aa) * d, cy, Math.sin(aa) * d, cr, cr * 0.82, cr, cmul(COL.oak, 0.85 + r() * 0.25), { c2: cmul(COL.oak2, 0.85 + r() * 0.2), rng: r, jit: 0.35, sw: 0.45, cj: 0.12 });
  }
  g.ico(0, h + 1.9, 0, 1.6, 1.3, 1.6, COL.oak, { c2: COL.oak2, rng: r, jit: 0.3, sw: 0.5, cj: 0.1 });
  var m = g.build(); m.trunkH = h; return m;
}
function mdlPine(seed) {
  var r = mulberry32(seed), g = new GB(), H = 6.5 + r() * 2;
  g.cyl(0, -0.3, 0, 0.27, 0.12, H, 6, COL.barkD, { c2: COL.bark, rng: r, jit: 0.1 });
  var lv = 6;
  for (var i = 0; i < lv; i++) {
    var y = 1.6 + i * (H - 2.0) / lv, rad = (2.3 - i * 0.32) * (0.9 + r() * 0.2);
    g.cyl(0, y, 0, rad, 0.0, 2.3 - i * 0.12, 8, cmul(COL.pine, 0.9 + r() * 0.2), { c2: COL.pine2, rng: r, jit: 0.35, sw0: 0.18 + i * 0.05, sw1: 0.35 + i * 0.06, a0: r() * 3 });
  }
  var m = g.build(); m.trunkH = H * 0.4; return m;
}
function mdlBirch(seed) {
  var r = mulberry32(seed), g = new GB(), H = 4.6 + r() * 1.2, segs = 9;
  for (var s = 0; s < segs; s++) {
    var y0 = -0.3 + s * (H + 0.3) / segs, hh = (H + 0.3) / segs, r0 = 0.17 - s * 0.012, r1 = 0.17 - (s + 1) * 0.012;
    var dark = r() < 0.3 || s === 0; g.cyl(0, y0, 0, r0, r1, hh, 6, dark ? cmix(COL.birch, COL.birchD, 0.75) : COL.birch, { c2: COL.birch, rng: r, jit: 0.08 });
  }
  for (var b = 0; b < 4; b++) { var a = r() * TAU, by = H * (0.5 + r() * 0.3); g.rod(0, by, 0, Math.cos(a) * 0.9, by + 0.8, Math.sin(a) * 0.9, 0.05, 0.02, 4, COL.birch, { sw1: 0.3 }); }
  for (var i = 0; i < 6; i++) {
    var aa = r() * TAU, d = r() * 0.8, cr = 0.9 + r() * 0.5;
    g.ico(Math.cos(aa) * d, H * 0.72 + r() * 1.6, Math.sin(aa) * d, cr, cr * 1.15, cr, COL.birchL, { c2: COL.birchL2, rng: r, jit: 0.4, sw: 0.55, cj: 0.15 });
  }
  var m = g.build(); m.trunkH = H * 0.6; return m;
}
function mdlStump(kind) {
  var g = new GB(), c = kind === 'birch' ? COL.birch : COL.bark, top = COL.woodL;
  g.cyl(0, -0.2, 0, kind === 'pine' ? 0.3 : kind === 'birch' ? 0.2 : 0.4, kind === 'pine' ? 0.27 : kind === 'birch' ? 0.18 : 0.34, 0.55, 8, cmul(c, 0.7), { c2: c, cap: true, ct: top });
  return g.build();
}
/* ---------- рослини, каміння, дрібниці ---------- */
function mdlBush(seed, berry) {
  var r = mulberry32(seed), g = new GB();
  for (var i = 0; i < 4; i++) { var a = r() * TAU, d = r() * 0.45; g.ico(Math.cos(a) * d, 0.45 + r() * 0.2, Math.sin(a) * d, 0.6, 0.5, 0.6, berry ? [0.15, 0.3, 0.12] : COL.oak, { c2: berry ? [0.24, 0.42, 0.16] : COL.oak2, rng: r, jit: 0.35, sw: 0.25, det: 1, cj: 0.1 }); }
  return g.build();
}
function mdlBerry() { return new GB().ico(0, 0, 0, 0.07, 0.07, 0.07, [0.45, 0.08, 0.35], { det: 0, c2: [0.62, 0.15, 0.5] }).build(); }
function mdlApple() { return new GB().ico(0, 0, 0, 0.09, 0.085, 0.09, [0.72, 0.1, 0.08], { det: 0, c2: [0.85, 0.3, 0.12] }).build(); }
function mdlFiber(seed) {
  var r = mulberry32(seed), g = new GB();
  for (var i = 0; i < 14; i++) {
    var a = r() * TAU, d = r() * 0.25, h = 0.7 + r() * 0.6, w = 0.04, x = Math.cos(a) * d, z = Math.sin(a) * d, lx = Math.cos(a) * 0.25 * r(), lz = Math.sin(a) * 0.25 * r();
    var c0 = [0.3, 0.42, 0.14], c1 = cmix([0.62, 0.66, 0.3], [0.72, 0.62, 0.32], r());
    g.tri([x - w, 0, z], [x + w, 0, z + w * 0.5], [x + lx, h, z + lz], c0, c0, c1, 0, 0, 0.9);
  }
  var m = g.build({ cull: false }); m.cull = false; return m;
}
function mdlStick(seed) {
  var r = mulberry32(seed), g = new GB(), L = 0.8 + r() * 0.4;
  g.mat(new Float32Array([0, -1, 0, 0, 1, 0, 0, 0.04, 0, 0, 1, 0])); // поклали на бік
  g.cyl(0, -L / 2, 0, 0.03, 0.022, L, 5, [0.38, 0.27, 0.16], { c2: [0.5, 0.36, 0.22] });
  g.cyl(0, 0.05, 0, 0.018, 0.01, 0.3, 4, [0.4, 0.29, 0.17], { lz: 0.18 });
  return g.build();
}
function mdlStone(seed, big) {
  var r = mulberry32(seed), g = new GB(), s = big ? 1 : 0.13;
  g.ico(0, s * 0.35, 0, s * (1 + r() * 0.4), s * (0.6 + r() * 0.3), s * (0.9 + r() * 0.4), cmul(COL.stone, 0.85 + r() * 0.2), { c2: big ? cmix(COL.stone2, COL.moss, 0.45) : COL.stone2, rng: r, jit: 0.45, det: big ? 1 : 0, flatB: true, cj: 0.1 });
  return g.build();
}
function mdlMush(poison) {
  var g = new GB();
  g.cyl(0, 0, 0, 0.035, 0.03, 0.12, 6, [0.92, 0.88, 0.8]);
  g.ico(0, 0.13, 0, 0.1, 0.05, 0.1, poison ? [0.75, 0.08, 0.05] : [0.5, 0.33, 0.18], { det: 1, c2: poison ? [0.9, 0.15, 0.08] : [0.62, 0.42, 0.24], flatB: true });
  if (poison) { var pts = [[0.04, 0.17, 0.02], [-0.03, 0.17, 0.05], [0.0, 0.18, -0.05], [-0.06, 0.155, -0.01], [0.07, 0.15, -0.04]]; pts.forEach(function (p) { g.box(p[0], p[1], p[2], 0.022, 0.012, 0.022, [0.97, 0.95, 0.9]); }); }
  return g.build();
}
function mdlPlantain() {
  var g = new GB(), c0 = [0.2, 0.36, 0.12], c1 = [0.32, 0.5, 0.18];
  for (var i = 0; i < 6; i++) { var a = i / 6 * TAU, ca = Math.cos(a), sa = Math.sin(a); g.tri([0, 0.02, 0], [ca * 0.16 - sa * 0.06, 0.05, sa * 0.16 + ca * 0.06], [ca * 0.22, 0.09, sa * 0.22], c0, c1, c1, 0, 0.2, 0.3); g.tri([0, 0.02, 0], [ca * 0.22, 0.09, sa * 0.22], [ca * 0.16 + sa * 0.06, 0.05, sa * 0.16 - ca * 0.06], c0, c1, c1, 0, 0.3, 0.2); }
  g.cyl(0, 0, 0, 0.008, 0.006, 0.28, 4, [0.3, 0.4, 0.15], { sw1: 0.6 }); g.cyl(0, 0.2, 0, 0.018, 0.012, 0.1, 5, [0.35, 0.33, 0.18], { sw0: 0.5, sw1: 0.6 });
  var m = g.build(); m.cull = false; return m;
}
function mdlChamomile() {
  var g = new GB();
  for (var k = 0; k < 3; k++) {
    var x = (k - 1) * 0.07, z = (k % 2) * 0.05, h = 0.26 + k * 0.04;
    g.cyl(x, 0, z, 0.006, 0.005, h, 4, [0.3, 0.45, 0.16], { sw1: 0.7 });
    for (var i = 0; i < 8; i++) { var a = i / 8 * TAU; g.tri([x, h, z], [x + Math.cos(a - 0.25) * 0.04, h, z + Math.sin(a - 0.25) * 0.04], [x + Math.cos(a + 0.25) * 0.04, h, z + Math.sin(a + 0.25) * 0.04], [0.97, 0.97, 0.94], null, null, 0.7, 0.7, 0.7); }
    g.ico(x, h + 0.008, z, 0.015, 0.01, 0.015, [0.95, 0.75, 0.1], { det: 0, sw: 0.7 });
  }
  var m = g.build(); m.cull = false; return m;
}
function mdlReed(seed) {
  var r = mulberry32(seed), g = new GB();
  for (var i = 0; i < 7; i++) { var x = (r() - 0.5) * 0.5, z = (r() - 0.5) * 0.5, h = 1.2 + r() * 0.8; g.cyl(x, -0.4, z, 0.015, 0.01, h + 0.4, 4, [0.3, 0.42, 0.16], { c2: [0.5, 0.58, 0.25], sw0: 0, sw1: 0.8 }); if (r() < 0.5) g.cyl(x, h - 0.25, z, 0.04, 0.04, 0.22, 5, [0.35, 0.2, 0.1], { sw0: 0.75, sw1: 0.8 }); }
  return g.build();
}
function mdlFlowers(seed) {
  var r = mulberry32(seed), g = new GB(), pal = [[0.9, 0.85, 0.2], [0.85, 0.3, 0.6], [0.95, 0.95, 0.95], [0.45, 0.5, 0.95], [0.95, 0.5, 0.15]];
  for (var i = 0; i < 6; i++) { var x = (r() - 0.5) * 0.7, z = (r() - 0.5) * 0.7, h = 0.18 + r() * 0.22, c = pal[Math.floor(r() * pal.length)]; g.cyl(x, 0, z, 0.006, 0.005, h, 3, [0.3, 0.45, 0.16], { sw1: 0.6 }); g.ico(x, h, z, 0.03, 0.02, 0.03, c, { det: 0, sw: 0.6 }); }
  var m = g.build(); m.cull = false; return m;
}
/* ---------- споруди ---------- */
function mdlFireLay() {
  var g = new GB();
  for (var k = 0; k < 9; k++) { var a = k / 9 * TAU; g.ico(Math.cos(a) * 0.55, 0.06, Math.sin(a) * 0.55, 0.13, 0.1, 0.12, COL.stone, { det: 0, c2: COL.stone2 }); }
  for (var i = 0; i < 6; i++) { var a2 = i / 6 * TAU; g.cyl(Math.cos(a2) * 0.32, 0, Math.sin(a2) * 0.32, 0.04, 0.03, 0.7, 5, [0.45, 0.32, 0.19], { lx: -Math.cos(a2) * 0.3, lz: -Math.sin(a2) * 0.3 }); }
  g.ico(0, 0.05, 0, 0.18, 0.08, 0.18, COL.dry, { det: 0 });
  return g.build();
}
function mdlFirePit(burnt) {
  var g = new GB();
  for (var k = 0; k < 9; k++) { var a = k / 9 * TAU; g.ico(Math.cos(a) * 0.55, 0.06, Math.sin(a) * 0.55, 0.13, 0.1, 0.12, cmul(COL.stone, burnt ? 0.6 : 0.9), { det: 0 }); }
  g.ico(0, 0.0, 0, 0.42, 0.06, 0.42, burnt ? [0.15, 0.14, 0.13] : [0.25, 0.22, 0.2], { det: 1, flatB: true });
  for (var i = 0; i < 3; i++) { var a2 = i / 3 * TAU + 0.3; g.cyl(Math.cos(a2) * 0.3, 0.06, Math.sin(a2) * 0.3, 0.06, 0.05, 0.6, 5, [0.12, 0.1, 0.09], { lx: -Math.cos(a2) * 0.55, lz: -Math.sin(a2) * 0.55 }); }
  return g.build();
}
function mdlShelter(broken) {
  var r = mulberry32(broken ? 77 : 33), g = new GB(), W = 2.6, D = 2.3, Hh = 1.75;
  g.rod(-W / 2, -0.2, 0, -W / 2, Hh + 0.15, 0, 0.075, 0.06, 6, COL.barkD, { c2: COL.bark });
  g.rod(W / 2, -0.2, 0, W / 2, Hh + 0.15, 0, 0.075, 0.06, 6, COL.barkD, { c2: COL.bark });
  if (!broken) g.rod(-W / 2 - 0.25, Hh, 0, W / 2 + 0.25, Hh, 0, 0.07, 0.06, 6, COL.bark);
  else g.rod(-W / 2 - 0.2, Hh, 0, W / 2 - 0.2, 0.15, 0.4, 0.07, 0.06, 6, COL.bark);
  for (var i = 0; i < 12; i++) {
    var x = -W / 2 + 0.05 + i * (W - 0.1) / 11;
    if (broken && r() < 0.45) { g.rod(x + rr(-0.4, 0.4), 0.05, rr(0.3, 2.2), x + rr(-1, 1), 0.08, rr(0.3, 2.4), 0.035, 0.03, 4, [0.38, 0.29, 0.18]); continue; }
    g.rod(x, Hh + 0.05, -0.12, x + (r() - 0.5) * 0.15, -0.05, D, 0.038, 0.032, 4, [0.4, 0.3, 0.18]);
  }
  var steps = 6;
  for (var s = 0; s < steps; s++) {
    var t0 = s / steps, t1 = (s + 1) / steps, y0 = Hh * (1 - t0) + 0.07, y1 = Hh * (1 - t1) + 0.07, z0 = D * t0 - 0.1, z1 = D * t1;
    for (var k = 0; k < 5; k++) {
      if (broken && r() < 0.55) continue;
      var xa = -W / 2 - 0.05 + k * (W + 0.1) / 5, xb = xa + (W + 0.1) / 5 + 0.05, c = cmix([0.22, 0.34, 0.12], [0.44, 0.38, 0.17], r()), j = (r() - 0.5) * 0.06;
      g.quad([xa, y0 + j, z0], [xb, y0, z0], [xb, y1 + j, z1 + 0.06], [xa, y1, z1 + 0.06], c, null, cmul(c, 0.85), cmul(c, 0.85), 0.05);
      g.quad([xa, y1 - 0.02, z1 + 0.06], [xb, y1 + j - 0.02, z1 + 0.06], [xb, y0 - 0.02, z0], [xa, y0 + j - 0.02, z0], cmul(c, 0.55), null, null, null, 0.05);
    }
  }
  return g.build();
}
function mdlSnare(caught) {
  var g = new GB();
  g.cyl(-0.18, 0, 0, 0.02, 0.015, 0.4, 4, COL.bark); g.cyl(0.18, 0, 0, 0.02, 0.015, 0.4, 4, COL.bark);
  g.mat(new Float32Array([0, -1, 0, 0.22, 1, 0, 0, 0.38, 0, 0, 1, 0])); g.cyl(0, 0, 0, 0.015, 0.015, 0.44, 4, COL.bark); g.mat(null);
  for (var i = 0; i < 10; i++) { var a = i / 10 * TAU, b = (i + 1) / 10 * TAU; g.box(Math.cos(a) * 0.1, 0.12 + Math.sin(a) * 0.1, 0, 0.012, 0.012, 0.012, COL.rope); }
  if (caught) { g.ico(0.05, 0.1, 0.2, 0.17, 0.11, 0.1, [0.5, 0.42, 0.33], { det: 1 }); g.ico(0.2, 0.12, 0.2, 0.07, 0.06, 0.06, [0.55, 0.47, 0.37], { det: 0 }); }
  return g.build();
}
function mdlCrate() {
  var g = new GB();
  g.box(0, 0, 0, 0.9, 0.62, 0.62, [0.55, 0.4, 0.22], { ct: [0.6, 0.45, 0.26] });
  [[-0.46, 0], [0.46, 0]].forEach(function (p) { g.box(p[0], -0.01, 0, 0.04, 0.64, 0.66, COL.metal); });
  g.box(0, 0.62, 0, 0.92, 0.03, 0.64, [0.85, 0.85, 0.82]);
  g.box(0, 0.25, 0.32, 0.25, 0.14, 0.02, [0.85, 0.15, 0.1]); // червоний хрест-маркування
  return g.build();
}
function mdlPost() {
  var g = new GB();
  g.cyl(0, -0.2, 0, 0.09, 0.08, 2.4, 6, COL.barkD, { c2: COL.bark, cap: true });
  g.box(0.0, 1.4, 0.1, 0.06, 0.2, 0.02, [0.8, 0.82, 0.85]);
  return g.build();
}
function mdlBag() {
  var g = new GB();
  g.ico(0, 0.25, 0, 0.3, 0.28, 0.2, [0.32, 0.36, 0.22], { det: 1, flatB: true, c2: [0.4, 0.44, 0.28] });
  g.box(0, 0.4, 0.18, 0.3, 0.14, 0.06, [0.28, 0.32, 0.2]);
  return g.build();
}
function mdlRadio() {
  var g = new GB(); g.box(0, 0, 0, 0.22, 0.13, 0.08, [0.18, 0.2, 0.18], { ct: [0.24, 0.26, 0.24] }); g.box(0.07, 0.13, 0, 0.012, 0.3, 0.012, [0.1, 0.1, 0.1]); g.box(-0.05, 0.04, 0.042, 0.07, 0.05, 0.005, [0.5, 0.55, 0.5]); return g.build();
}
function mdlBottle() { var g = new GB(); g.mat(new Float32Array([0, -1, 0, 0, 1, 0, 0, 0.06, 0, 0, 1, 0])); g.cyl(0, -0.15, 0, 0.055, 0.055, 0.22, 7, [0.2, 0.45, 0.3], { cap: true }); g.cyl(0, 0.07, 0, 0.055, 0.02, 0.06, 7, [0.25, 0.5, 0.35]); g.cyl(0, 0.13, 0, 0.022, 0.022, 0.05, 6, [0.6, 0.5, 0.35]); return g.build(); }
function mdlPaper() { var g = new GB(); g.box(0, 0, 0, 0.18, 0.006, 0.24, [0.92, 0.9, 0.8]); return g.build(); }
function mdlRing() { // кільце-підсвітка цілі на землі
  var g = new GB(); for (var i = 0; i < 24; i++) { var a = i / 24 * TAU, b = (i + 1) / 24 * TAU; g.quad([Math.cos(a) * 0.5, 0, Math.sin(a) * 0.5], [Math.cos(b) * 0.5, 0, Math.sin(b) * 0.5], [Math.cos(b) * 0.42, 0, Math.sin(b) * 0.42], [Math.cos(a) * 0.42, 0, Math.sin(a) * 0.42], [1, 1, 1]); }
  var m = g.build(); m.cull = false; return m;
}
/* ---------- тварини (окремі частини для анімації) ---------- */
function mdlWolf() {
  var c = [0.36, 0.34, 0.32], c2 = [0.55, 0.52, 0.48], d = [0.15, 0.14, 0.13];
  return {
    body: new GB().ico(0, 0, 0, 0.32, 0.3, 0.62, c, { c2: c2, det: 1 }).build(),
    head: new GB().ico(0, 0, 0, 0.2, 0.19, 0.22, c, { c2: c2, det: 1 }).box(0, -0.09, -0.24, 0.13, 0.11, 0.24, c2).box(0, -0.05, -0.37, 0.05, 0.04, 0.03, d)
      .cyl(-0.1, 0.12, 0.02, 0.06, 0, 0.14, 4, c).cyl(0.1, 0.12, 0.02, 0.06, 0, 0.14, 4, c).build(),
    leg: new GB().box(0, -0.55, 0, 0.09, 0.55, 0.1, d, { ct: c }).build(),
    tail: new GB().cyl(0, 0, 0, 0.07, 0.02, 0.5, 5, c, { c2: d }).build()
  };
}
function mdlRabbit() {
  var c = [0.52, 0.43, 0.33], w = [0.92, 0.9, 0.86], g = new GB();
  g.ico(0, 0.17, 0, 0.13, 0.13, 0.2, c, { det: 1, c2: [0.6, 0.5, 0.4] });
  g.ico(0, 0.29, -0.17, 0.08, 0.08, 0.09, c, { det: 0 });
  g.box(-0.03, 0.34, -0.15, 0.025, 0.16, 0.04, c); g.box(0.03, 0.34, -0.15, 0.025, 0.16, 0.04, c);
  g.ico(0, 0.2, 0.21, 0.045, 0.045, 0.045, w, { det: 0 });
  g.box(-0.035, 0.29, -0.245, 0.015, 0.015, 0.01, [0.05, 0.05, 0.05]); g.box(0.035, 0.29, -0.245, 0.015, 0.015, 0.01, [0.05, 0.05, 0.05]);
  return g.build();
}
function mdlBird() {
  var g = new GB(), c = [0.12, 0.12, 0.13];
  g.tri([0, 0, -0.18], [-0.45, 0.12, 0.02], [0, 0, 0.1], c, null, null, 0, 0, 0); g.tri([0, 0, -0.18], [0, 0, 0.1], [0.45, 0.12, 0.02], c, null, null, 0, 0, 0);
  g.ico(0, 0, -0.03, 0.04, 0.035, 0.14, c, { det: 0 });
  var m = g.build(); m.cull = false; return m;
}
function mdlFish() { var g = new GB(); g.ico(0, 0, 0, 0.05, 0.08, 0.2, [0.35, 0.42, 0.4], { det: 1, c2: [0.75, 0.8, 0.78] }); g.tri([0, 0, 0.18], [0, 0.09, 0.3], [0, -0.09, 0.3], [0.3, 0.36, 0.35]); var m = g.build(); m.cull = false; return m; }
function mdlBobber() { return new GB().ico(0, 0.03, 0, 0.035, 0.05, 0.035, [0.95, 0.95, 0.92], { det: 0, c2: [0.9, 0.12, 0.1] }).build(); }
function mdlBox() { return new GB().box(0, -0.5, 0, 1, 1, 1, [1, 1, 1]).build(); }

/* ---------- предмети в руці (вигляд від першої особи) ---------- */
function mdlHand() { var g = new GB(); g.box(0, -0.42, 0, 0.085, 0.42, 0.085, [0.22, 0.25, 0.3], { ct: [0.24, 0.27, 0.32] }); g.box(0, 0, 0, 0.09, 0.1, 0.11, COL.skin, { ct: cmul(COL.skin, 1.05) }); return g.build(); }
var VM = {};
function buildViewModels() {
  var g;
  g = new GB(); g.cyl(0, -0.25, 0, 0.022, 0.02, 0.62, 6, [0.45, 0.32, 0.2], { c2: [0.55, 0.4, 0.25] }); g.ico(0.07, 0.33, 0, 0.1, 0.06, 0.025, COL.stone, { det: 1, c2: COL.stone2 }); g.box(0, 0.29, 0, 0.06, 0.08, 0.05, COL.rope); VM.axe = g.build();
  g = new GB(); g.cyl(0, -0.45, 0, 0.018, 0.016, 1.3, 5, [0.45, 0.32, 0.2]); g.cyl(0, 0.85, 0, 0.035, 0, 0.16, 4, COL.stone2); g.box(0, 0.8, 0, 0.045, 0.06, 0.045, COL.rope); VM.spear = g.build();
  g = new GB(); g.cyl(0, -0.25, 0, 0.018, 0.008, 1.2, 5, [0.5, 0.36, 0.22]); g.box(0, -0.05, 0.02, 0.05, 0.1, 0.05, COL.rope); VM.rod = g.build();
  g = new GB(); g.cyl(0, -0.25, 0, 0.025, 0.03, 0.5, 6, [0.4, 0.28, 0.17]); g.ico(0, 0.28, 0, 0.055, 0.07, 0.055, [0.25, 0.2, 0.12], { det: 0 }); VM.torch = g.build();
  g = new GB(); g.cyl(0, -0.2, 0, 0.02, 0.015, 0.55, 5, [0.42, 0.3, 0.18]); VM.stick = g.build();
  g = new GB(); g.ico(0, 0, 0, 0.07, 0.05, 0.06, COL.stone, { det: 0, c2: COL.stone2, jit: 0.3, rng: mulberry32(4) }); VM.stone = g.build();
  g = new GB(); g.ico(0, 0, 0, 0.08, 0.04, 0.05, COL.stone2, { det: 0, c2: [0.75, 0.76, 0.78], jit: 0.5, rng: mulberry32(9) }); VM.sharp = g.build();
  g = new GB(); g.cyl(0, -0.08, 0, 0.065, 0.06, 0.16, 8, [0.9, 0.88, 0.8], { c2: [0.82, 0.8, 0.72], capB: true }); g.cyl(0, -0.05, 0, 0.067, 0.067, 0.025, 8, [0.15, 0.14, 0.12]); VM.can = g.build();
  g = new GB(); g.cyl(0, -0.04, 0, 0.05, 0.05, 0.08, 8, [0.9, 0.88, 0.82], { cap: true, ct: [0.95, 0.94, 0.9] }); VM.bandage = g.build();
  g = new GB(); for (var i = 0; i < 4; i++) g.cyl(0, -0.03 + i * 0.012, 0, 0.06, 0.06, 0.012, 8, COL.rope); VM.rope = g.build();
  g = new GB(); g.mat(new Float32Array([0, -1, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0])); g.cyl(0, -0.25, 0, 0.07, 0.07, 0.5, 7, COL.bark, { cap: true, capB: true, ct: COL.woodL }); VM.log = g.build();
  g = new GB(); g.cyl(0, -0.2, 0, 0.02, 0.015, 0.4, 5, COL.bark); g.mat(new Float32Array([1, 0, 0, 0, 0, 0.3, -0.95, 0.1, 0, 0.95, 0.3, 0])); g.cyl(0, -0.15, 0, 0.012, 0.012, 0.35, 4, COL.bark); VM.drill = g.build();
  g = new GB(); for (var j = 0; j < 7; j++) { var a = j / 7 * TAU; g.tri([0, -0.05, 0], [Math.cos(a) * 0.04, 0.12, Math.sin(a) * 0.04], [Math.cos(a + 0.4) * 0.05, 0.14, Math.sin(a + 0.4) * 0.05], [0.4, 0.5, 0.2], [0.65, 0.68, 0.32]); } VM.fiber = g.build();
  g = new GB(); g.mat(new Float32Array([1, 0, 0, 0, 0, 0, -1, 0, 0, 1, 0, 0])); g.box(0, -0.06, 0, 0.18, 0.004, 0.12, [0.88, 0.85, 0.74]); g.box(0, -0.06, 0, 0.18, 0.004, 0.12, [0.88, 0.85, 0.74]); VM.paper = g.build();
  g = new GB(); g.box(0, -0.06, 0, 0.12, 0.08, 0.06, [0.18, 0.2, 0.18]); g.box(0.04, 0.02, 0, 0.01, 0.18, 0.01, [0.1, 0.1, 0.1]); VM.radio = g.build();
  g = new GB(); g.cyl(0, -0.1, 0, 0.06, 0.06, 0.2, 8, [0.3, 0.4, 0.55], { cap: true, capB: true, ct: [0.25, 0.32, 0.45] }); VM.bedroll = g.build();
  g = new GB(); g.box(0, -0.04, 0, 0.06, 0.02, 0.04, [0.8, 0.7, 0.4]); VM.matches = g.build();
  VM.apple = mdlApple();
  VM.berry = new GB().ico(0.02, 0, 0, 0.03, 0.03, 0.03, [0.45, 0.08, 0.35], { det: 0 }).ico(-0.02, 0.01, 0.01, 0.03, 0.03, 0.03, [0.5, 0.1, 0.4], { det: 0 }).ico(0, 0.03, -0.01, 0.03, 0.03, 0.03, [0.42, 0.06, 0.32], { det: 0 }).build();
  VM.mush = mdlMush(false); VM.amanita = mdlMush(true);
  VM.fish = mdlFish();
  VM.meat = new GB().ico(0, 0, 0, 0.08, 0.04, 0.06, [0.7, 0.2, 0.2], { det: 1, c2: [0.85, 0.5, 0.45] }).build();
  VM.cooked = new GB().ico(0, 0, 0, 0.08, 0.04, 0.06, [0.42, 0.24, 0.12], { det: 1, c2: [0.55, 0.33, 0.16] }).build();
  VM.herb = mdlPlantain(); VM.flower = mdlChamomile();
  VM.charcoal = new GB().ico(0, 0, 0, 0.05, 0.035, 0.04, [0.08, 0.08, 0.08], { det: 0 }).build();
  VM.bark = new GB().box(0, -0.06, 0, 0.12, 0.12, 0.01, COL.birch).build();
  VM.ration = new GB().box(0, -0.04, 0, 0.12, 0.08, 0.04, [0.35, 0.4, 0.25]).build();
  VM.firelay = new GB().cyl(0, -0.1, 0, 0.08, 0.06, 0.2, 6, [0.45, 0.32, 0.19]).build();
  VM.snare = new GB().cyl(0, -0.1, 0, 0.012, 0.012, 0.25, 4, COL.bark).box(0, 0.05, 0, 0.08, 0.08, 0.01, COL.rope).build();
  VM.kit = new GB().cyl(-0.04, -0.15, 0, 0.03, 0.03, 0.35, 5, COL.bark).cyl(0.04, -0.15, 0, 0.03, 0.03, 0.35, 5, COL.bark).box(0, 0, 0, 0.12, 0.03, 0.08, COL.rope).build();
  VM.hand = mdlHand();
}
