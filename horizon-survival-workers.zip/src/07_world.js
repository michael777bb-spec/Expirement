/* =====================================================================
   СВІТ: купол-екран, рельєф, ставки, рослинність, ресурси, точки сюжету
   ===================================================================== */
var X0 = 0, X1 = 200, CR = 32, ZLIM = 29.3;
var SPAWN = { x: 22, z: 3, yaw: 0.95 };
var PONDS = [{ x: 60, z: -13, r: 6.5 }, { x: 116, z: 13, r: 7.5 }, { x: 166, z: -8, r: 6.2 }];
var WATER_Y = -0.32;
var POI = { post: { x: 19.6, z: 0.6 }, camp: { x: 92, z: 18 }, stone: { x: 140, z: -19 }, bottle: { x: 0, z: 0 }, grove: { x: 176, z: 18 }, edge: { x: 194, z: -3.5 }, hatch: { x: 199.2, z: 0 } };
POI.bottle.x = PONDS[1].x - 7.2; POI.bottle.z = PONDS[1].z + 3.2;

function Hraw(x, z) {
  var h = (fbm2(x * 0.028 + 3.1, z * 0.04 + 7.7) - 0.5) * 1.5 + Math.sin(x * 0.043 + 1.3) * 0.22 + Math.cos(z * 0.09 + x * 0.01) * 0.12;
  var ds = Math.hypot(x - SPAWN.x, z - SPAWN.z); h *= 0.4 + 0.6 * smooth(4, 14, ds);
  return h;
}
function pondK(x, z) { var k = 0; for (var i = 0; i < PONDS.length; i++) { var p = PONDS[i], d = Math.hypot(x - p.x, z - p.z); k = Math.max(k, smooth(p.r + 2.6, p.r * 0.3, d)); } return k; }
function H(x, z) { var h = Hraw(x, z), k = pondK(x, z); return k > 0 ? lerp(h, -1.25, k) : h; }
function inPond(x, z, m) { for (var i = 0; i < PONDS.length; i++) { var p = PONDS[i]; if (Math.hypot(x - p.x, z - p.z) < p.r + (m || 0)) return p; } return null; }
function waterDepth(x, z) { return WATER_Y - H(x, z); }

/* ---------- групи екземплярів ---------- */
var GROUPS = {}, MESHC = {};
function grp(key, mk) { var g = GROUPS[key]; if (!g) g = GROUPS[key] = { key: key, mk: mk, items: [], ib: null, mesh: null }; return g; }
function place(key, mk, x, y, z, ry, s, sy) { var g = grp(key, mk); var it = { g: g, i: g.items.length, x: x, y: y, z: z, ry: ry || 0, s: s || 1, sy: sy === undefined ? (s || 1) : sy, tilt: 0, dx: 0, dz: 1, hid: false }; g.items.push(it); return it; }
function writeInst(it) { if (!it.g.ib) return; if (it.hid) it.g.ib.hide(it.i); else it.g.ib.set(it.i, it.x, it.y, it.z, it.ry, it.s, it.sy, it.s, it.tilt, it.dx, it.dz); }
function showInst(it, on) { it.hid = !on; writeInst(it); }
function finalizeGroups() {
  for (var k in GROUPS) {
    var g = GROUPS[k]; if (g.ib) continue;
    var mk = g.mk; g.mesh = MESHC[k] || (MESHC[k] = mk());
    g.ib = new IB(Math.max(1, g.items.length));
    for (var i = 0; i < g.items.length; i++) writeInst(g.items[i]);
    if (!g.items.length) g.ib.hide(0);
  }
}
/* колізії: кола */
var COLS = [];
function addCol(x, z, r) { var c = { x: x, z: z, r: r, on: true }; COLS.push(c); return c; }
/* цілі для взаємодії */
var INTER = [];
function addInter(o) { o.on = o.on === undefined ? true : o.on; INTER.push(o); return o; }

/* ---------- небо-екран ---------- */
var SKY_VS = 'attribute vec3 aPos; uniform mat4 uVP; varying vec3 vW; void main(){ vW=aPos; gl_Position=uVP*vec4(aPos,1.0); }';
var SKY_FS = [
  'uniform float uTime; uniform vec3 uSun; uniform float uDayK; uniform float uGold; uniform vec3 uCenter; uniform float uGlitch; uniform float uOff;',
  'uniform float uCloud; uniform float uDark; uniform float uFlash; uniform float uHatch;',
  'varying vec3 vW;',
  'float h21(vec2 p){ return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453); }',
  'float n2(vec2 p){ vec2 i=floor(p); vec2 f=fract(p); f=f*f*(3.0-2.0*f); return mix(mix(h21(i),h21(i+vec2(1.0,0.0)),f.x),mix(h21(i+vec2(0.0,1.0)),h21(i+vec2(1.0,1.0)),f.x),f.y); }',
  'float fbm(vec2 p){ float a=0.5; float s=0.0; for(int i=0;i<FB;i++){ s+=a*n2(p); p=p*2.03+vec2(1.7,9.2); a*=0.5; } return s; }',
  'void main(){',
  ' vec3 d=normalize(vW-uCenter); vec3 sun=uSun; float dayK=uDayK; float gold=uGold;',
  ' vec3 zen=mix(vec3(0.01,0.02,0.07),vec3(0.16,0.4,0.86),dayK);',
  ' vec3 hor=mix(vec3(0.03,0.04,0.09),vec3(0.62,0.79,0.96),dayK);',
  ' float sd=max(dot(d,sun),0.0);',
  ' hor=mix(hor,vec3(1.0,0.52,0.26),gold*0.75*(0.35+0.65*pow(sd,2.0))*(1.0-uDark*0.7));',
  ' vec3 gray=mix(vec3(0.02,0.025,0.035),vec3(0.42,0.45,0.5),dayK);',
  ' zen=mix(zen,gray*0.8,uDark); hor=mix(hor,gray,uDark);',
  ' float up=clamp(d.y,0.0,1.0);',
  ' vec3 col=mix(hor,zen,pow(up,0.5));',
  ' float sv=1.0-uDark*0.92;',
  ' col+=vec3(1.0,0.85,0.6)*(pow(sd,700.0)*3.0+pow(sd,10.0)*0.3)*smoothstep(-0.08,0.1,sun.y)*sv;',
  ' float md=max(dot(d,-sun),0.0);',
  ' col+=vec3(0.75,0.82,1.0)*(pow(md,1500.0)*3.0+pow(md,30.0)*0.04)*(1.0-dayK)*sv;',

  ' vec2 cp=d.xz/(d.y+0.4)*1.5+vec2(uTime*0.012,uTime*0.004);',
  ' float cov=uCloud;',
  ' float cl=smoothstep(0.56-0.36*cov,0.86-0.26*cov,fbm(cp))*smoothstep(0.0,0.18,d.y+0.04);',
  ' vec3 ccol=mix(vec3(0.08,0.09,0.14),vec3(1.0),dayK); ccol=mix(ccol,vec3(1.0,0.62,0.42),gold*0.5*(1.0-uDark)); ccol*=mix(1.0,0.5,uDark);',
  ' col=mix(col,ccol*(0.78+0.22*fbm(cp*3.0)),cl*0.92);',
  ' vec2 sp=d.xz/(d.y+0.35)*95.0; vec2 sc=floor(sp); vec2 sf=fract(sp)-0.5; float sr=h21(sc);',
  ' float star=step(0.982,sr)*smoothstep(0.32,0.0,length(sf))*(0.55+0.45*sin(uTime*(2.0+sr*5.0)+sr*40.0));',
  ' col+=vec3(0.9,0.93,1.0)*star*(1.0-dayK)*smoothstep(0.05,0.35,d.y)*(1.0-cl)*(1.0-uDark);',
  ' float ang=atan(d.x,d.z); float ridge=0.04+0.06*fbm(vec2(ang*2.5,3.0));',
  ' if(d.y<ridge){ vec3 hill=vec3(0.04,0.09,0.06)*(0.12+dayK*(1.0-uDark*0.5))+hor*0.14; col=mix(col,hill,smoothstep(ridge,ridge-0.012,d.y)); }',
  ' vec2 uv=vec2(vW.x+vW.z*0.0, atan(vW.y+2.0,vW.z)*30.0); if(abs(vW.x-100.0)>99.5) uv=vec2(vW.z,vW.y);',
  ' vec2 g=abs(fract(uv*6.0)-0.5); float line=smoothstep(0.46,0.5,max(g.x,g.y));',
  ' col*=1.0-line*0.07*(0.4+uGlitch);',
  ' col*=0.975+0.025*sin(vW.y*160.0+uTime*2.0);',
  ' if(uGlitch>0.0){ float band=step(0.82,fract(vW.y*0.8+floor(uTime*12.0)*0.37))*uGlitch;',
  '   col=mix(col,vec3(h21(floor(uv*3.0)+floor(uTime*20.0))),band*0.5); col.r+=uGlitch*0.12*sin(uv.x*3.0+uTime*30.0);',
  '   vec2 ck=floor(uv*2.0); float chk=mod(ck.x+ck.y,2.0); col=mix(col,mix(vec3(0.0),vec3(0.2,1.0,0.6),chk),step(0.9,uGlitch)*0.6*line+step(0.95,uGlitch)*0.2); }',
  ' if(uHatch>0.0 && vW.x>199.0){ vec2 q=vec2(vW.z,vW.y-1.3); float fr=max(abs(q.x)/0.62,abs(q.y)/1.15);',
  '   float edge=smoothstep(0.95,1.0,fr)*(1.0-smoothstep(1.0,1.05,fr)); vec2 kp=q-vec2(0.38,0.1); float pad=step(abs(kp.x),0.12)*step(abs(kp.y),0.18);',
  '   col=mix(col,vec3(0.55,1.0,0.75),edge*uHatch); col=mix(col,vec3(0.15,0.35,0.25)+0.3*step(0.5,fract(kp.x*12.0))*step(0.5,fract(kp.y*10.0)),pad*uHatch*0.9); }',
  ' col+=vec3(0.75,0.8,1.0)*uFlash;',
  ' if(uOff>0.0){ vec3 hc=vec3(0.07,0.075,0.08); vec2 lp=fract(vec2(vW.x*0.05,atan(vW.y+2.0,vW.z)*2.0)); float lamp=smoothstep(0.1,0.0,length(lp-0.5));',
  '   float beam=step(0.94,fract(vW.x*0.1))+step(0.96,fract(atan(vW.y+2.0,vW.z)*5.0)); hc=mix(hc,vec3(0.18,0.19,0.2),clamp(beam,0.0,1.0)); hc+=vec3(1.0,0.95,0.82)*lamp*1.4; col=mix(col,hc,uOff); }',
  ' col=pow(clamp(col,0.0,1.0),vec3(1.0/2.2));',
  ' gl_FragColor=vec4(col,1.0);',
  '}'].join('\n');
var SKY = { mesh: null, prog: null, glitch: 0, off: 0, hatch: 0, flash: 0 };
function buildSky() {
  SKY.prog = mkProg(SKY_VS, SKY_FS, '#define FB ' + Q.fb + '\n');
  var pos = [], seg = 64, R = CR, cy = -2;
  function push(a, b, c) { pos.push(a[0], a[1], a[2], b[0], b[1], b[2], c[0], c[1], c[2]); }
  for (var i = 0; i < seg; i++) {
    var a0 = i / seg * Math.PI, a1 = (i + 1) / seg * Math.PI;
    var z0 = -R * Math.cos(a0), y0 = cy + R * Math.sin(a0), z1 = -R * Math.cos(a1), y1 = cy + R * Math.sin(a1);
    push([X0, y0, z0], [X1, y0, z0], [X1, y1, z1]); push([X0, y0, z0], [X1, y1, z1], [X0, y1, z1]);
    push([X0, cy, 0], [X0, y0, z0], [X0, y1, z1]); push([X1, cy, 0], [X1, y1, z1], [X1, y0, z0]);
  }
  SKY.mesh = new Mesh({ n: pos.length / 3, pos: new Float32Array(pos), cull: false });
}
function drawSky() {
  var u = useProg(SKY.prog);
  gl.uniform3fv(u.uSun, ENV.sunVec); gl.uniform1f(u.uDayK, ENV.dayK); gl.uniform1f(u.uGold, ENV.gold);
  gl.uniform3f(u.uCenter, CAM.x, CAM.y, CAM.z); gl.uniform1f(u.uGlitch, SKY.glitch); gl.uniform1f(u.uOff, SKY.off);
  gl.uniform1f(u.uCloud, ENV.cloud); gl.uniform1f(u.uDark, ENV.dark); gl.uniform1f(u.uFlash, SKY.flash); gl.uniform1f(u.uHatch, SKY.hatch);
  gl.disable(gl.CULL_FACE); bindAttr(0, SKY.mesh.bp, 3, gl.FLOAT, false); aEn(1, false); aEn(2, false); aEn(7, false);
  gl.drawArrays(gl.TRIANGLES, 0, SKY.mesh.n); gl.enable(gl.CULL_FACE);
}
/* кольори неба на CPU (для туману), повторюють шейдер */
function skyHorizon(dayK, gold, dark) {
  var hor = [lerp(0.03, 0.62, dayK), lerp(0.04, 0.79, dayK), lerp(0.09, 0.96, dayK)];
  var gk = gold * 0.75 * 0.55 * (1 - dark * 0.7); hor = cmix(hor, [1, 0.52, 0.26], gk);
  var gray = [lerp(0.02, 0.42, dayK), lerp(0.025, 0.45, dayK), lerp(0.035, 0.5, dayK)]; hor = cmix(hor, gray, dark);
  return hor.map(function (v) { return Math.pow(clamp(v, 0, 1), 1 / 2.2); });
}

/* ---------- рельєф та трава ---------- */
var TERRAIN = null, GRASS = [], WATERM = [];
function groundCol(x, z, h) {
  var n = fbm2(x * 0.08, z * 0.08), n2 = vnoise(x * 0.5, z * 0.5);
  var c = cmix(COL.grass, cmix(COL.grass2, COL.dry, 0.6), clamp(n * 0.9 - 0.15, 0, 1) * 0.55);
  c = cmul(c, 0.86 + n2 * 0.22);
  var pk = pondK(x, z); if (pk > 0.05) c = cmix(c, h < WATER_Y + 0.1 ? [0.22, 0.2, 0.14] : [0.34, 0.3, 0.2], smooth(0.05, 0.4, pk));
  var de = Math.abs(z); if (de > 28) c = cmul(c, 1 - (de - 28) * 0.08);
  return c;
}
function buildTerrain() {
  var g = new GB(), st = QL === 'low' ? 1.6 : QL === 'medium' ? 1.2 : 1.0, zmin = -CR - 1, zmax = CR + 1;
  var nx = Math.ceil((X1 - X0) / st), nz = Math.ceil((zmax - zmin) / st), P = [];
  for (var i = 0; i <= nx; i++) { P[i] = []; for (var j = 0; j <= nz; j++) { var x = X0 + i * st, z = zmin + j * st, h = H(x, z); var e = 0.25, hx = H(x + e, z) - H(x - e, z), hz = H(x, z + e) - H(x, z - e), nl = Math.sqrt(hx * hx + hz * hz + 4 * e * e); P[i][j] = [x, h, z, -hx / nl, 2 * e / nl, -hz / nl, groundCol(x, z, h)]; } }
  function V(p) { g.vtx(p[0], p[1], p[2], p[3], p[4], p[5], p[6], 0); }
  for (var a = 0; a < nx; a++) for (var b = 0; b < nz; b++) { var p00 = P[a][b], p10 = P[a + 1][b], p01 = P[a][b + 1], p11 = P[a + 1][b + 1]; V(p00); V(p01); V(p11); V(p00); V(p11); V(p10); }
  TERRAIN = g.build();
  /* трава: злиті шматки по 20 м з відсіканням по відстані */
  var dens = 1.5 * Q.grass;
  for (var cx = X0; cx < X1; cx += 20) {
    var gg = new GB(), r = mulberry32(cx * 7 + 3), cnt = Math.floor(20 * 2 * ZLIM * dens);
    for (var k = 0; k < cnt; k++) {
      var x2 = cx + r() * 20, z2 = (r() * 2 - 1) * (CR - 1.5), h2 = H(x2, z2);
      if (h2 < WATER_Y + 0.04) continue;
      if (Math.hypot(x2 - POI.post.x, z2 - POI.post.z) < 0.8) continue;
      var base = cmix(COL.grass, COL.dry, clamp(fbm2(x2 * 0.08, z2 * 0.08) - 0.35, 0, 1) * 0.7), top = cmix(COL.grass2, COL.dry, r() * 0.35);
      base = cmul(base, 0.8 + r() * 0.25);
      var hh = 0.28 + r() * 0.45 + pondK(x2, z2) * 0.4, ww = 0.05;
      for (var bl = 0; bl < 3; bl++) {
        var a2 = r() * TAU, ca = Math.cos(a2), sa = Math.sin(a2), lx = (r() - 0.5) * 0.22, lz = (r() - 0.5) * 0.22;
        gg.tri([x2 - ca * ww, h2 - 0.02, z2 - sa * ww], [x2 + ca * ww, h2 - 0.02, z2 + sa * ww], [x2 + lx, h2 + hh, z2 + lz], base, base, top, 0, 0, clamp(hh * 1.6, 0.3, 1));
      }
    }
    if (gg.p.length) { var m = gg.build(); m.cull = false; GRASS.push(m); }
  }
  /* вода: диск на кожен ставок */
  PONDS.forEach(function (p) {
    var pos = [], seg = 40, rr2 = p.r + 2.6;
    for (var i2 = 0; i2 < seg; i2++) { var a0 = i2 / seg * TAU, a1 = (i2 + 1) / seg * TAU; pos.push(p.x, WATER_Y, p.z, p.x + Math.cos(a1) * rr2, WATER_Y, p.z + Math.sin(a1) * rr2, p.x + Math.cos(a0) * rr2, WATER_Y, p.z + Math.sin(a0) * rr2); }
    WATERM.push(new Mesh({ n: pos.length / 3, pos: new Float32Array(pos), bs: [p.x, WATER_Y, p.z, rr2] }));
  });
}

/* ---------- плями тіней під об'єктами ---------- */
var SHADOWS = [];
function addShadow(x, z, r) { var it = place('shadow', mdlShadowQuad, x, H(x, z) + 0.04, z, 0, r * 2.2); SHADOWS.push(it); return it; }
function mdlShadowQuad() { var g = new GB(); g.quad([-0.5, 0, 0.5], [0.5, 0, 0.5], [0.5, 0, -0.5], [-0.5, 0, -0.5], [0, 0, 0]); return g.build(); }

/* ---------- дерева ---------- */
var TREES = [], NODES = [], TREE_INFO = {
  oak: { hits: 8, proc: 5, logs: 4, sticks: 3, col: 0.5 }, apple: { hits: 7, proc: 4, logs: 3, sticks: 3, col: 0.5 },
  pine: { hits: 6, proc: 4, logs: 3, sticks: 2, col: 0.36 }, birch: { hits: 5, proc: 3, logs: 2, sticks: 2, col: 0.28 }
};
var occupied = [];
function free(x, z, r) {
  if (Math.abs(z) > ZLIM - 1 || x < 3 || x > X1 - 3) return false;
  if (inPond(x, z, 2.4)) return false;
  if (Math.hypot(x - SPAWN.x, z - SPAWN.z) < 7) return false;
  for (var k in POI) if (Math.hypot(x - POI[k].x, z - POI[k].z) < (k === 'hatch' || k === 'edge' ? 5 : 4.5)) return false;
  for (var i = 0; i < occupied.length; i++) { var o = occupied[i]; if (Math.hypot(x - o[0], z - o[1]) < r + o[2]) return false; }
  return true;
}
function addTree(kind, x, z, s) {
  var v = Math.floor(RNG() * 3), key = (kind === 'apple' ? 'oak' : kind) + v, mk = kind === 'pine' ? mdlPine : kind === 'birch' ? mdlBirch : mdlOak;
  var mkv = (function (k, vv) { return function () { return k === 'pine' ? mdlPine(100 + vv) : k === 'birch' ? mdlBirch(200 + vv) : mdlOak(300 + vv); }; })(kind === 'apple' ? 'oak' : kind, v);
  var y = H(x, z), it = place(key, mkv, x, y, z, RNG() * TAU, s);
  var info = TREE_INFO[kind], tr = { kind: kind, it: it, x: x, z: z, s: s, st: 0, hits: 0, proc: 0, fallT: 0, shake: 0, bark: -1e9, appleT: -1e9, apples: [], col: addCol(x, z, info.col * s), shadow: addShadow(x, z, (kind === 'pine' ? 2.2 : kind === 'birch' ? 1.5 : 2.4) * s) };
  var sk = 'stump_' + (kind === 'apple' ? 'oak' : kind), smk = (function (k) { return function () { return mdlStump(k); }; })(kind === 'apple' ? 'oak' : kind);
  tr.stump = place(sk, smk, x, y, z, it.ry, s); tr.stump.hid = true;
  if (kind === 'apple') {
    for (var a = 0; a < 7; a++) { var aa = RNG() * TAU, rad = (1.2 + RNG() * 1.3) * s; tr.apples.push(place('apple', mdlApple, x + Math.cos(aa) * rad, y + (3.0 + RNG() * 1.6) * s, z + Math.sin(aa) * rad, 0, 1)); }
  }
  tr.inter = addInter({ kind: 'tree', ref: tr, x: x, y: y + 1.1, z: z, r: 1.1 + info.col * s });
  TREES.push(tr); occupied.push([x, z, (kind === 'pine' ? 2.6 : 3) * s]);
  return tr;
}
/* вузли ресурсів: зникають при зборі, з'являються знову через respawn ігрових хвилин */
function addNode(kind, key, mk, x, z, ry, s, respawn, yOff) {
  var y = H(x, z) + (yOff || 0), it = place(key, mk, x, y, z, ry, s);
  var n = { kind: kind, it: it, x: x, y: y, z: z, t: -1, resp: respawn, extra: [] };
  n.inter = addInter({ kind: 'node', ref: n, x: x, y: y + 0.15, z: z, r: kind === 'bush' ? 1.25 : 0.75 });
  NODES.push(n); return n;
}
function named(fn) { return fn; }

function buildNature() {
  RNG = mulberry32(G.seed);
  var i, x, z, tries;
  /* ліси за шумом */
  var want = { oak: 80, apple: 14, pine: 70, birch: 48 };
  Object.keys(want).forEach(function (kind) {
    var n = 0; tries = 0;
    while (n < want[kind] && tries < 6000) {
      tries++; x = rr(4, X1 - 4); z = rr(-ZLIM + 2, ZLIM - 2);
      var f = fbm2(x * 0.035 + (kind === 'pine' ? 40 : kind === 'birch' ? 80 : 0), z * 0.05);
      if (f < (kind === 'apple' ? 0.35 : 0.5)) continue;
      var s = rr(0.85, 1.25); if (!free(x, z, 1.6 * s)) continue;
      addTree(kind, x, z, s); n++;
    }
  });
  /* березовий гай (записка 5) */
  for (i = 0; i < 12; i++) { var a = i / 12 * TAU + rr(0, 0.4), d = rr(3, 8); x = POI.grove.x + Math.cos(a) * d; z = clamp(POI.grove.z + Math.sin(a) * d, -ZLIM + 2, ZLIM - 2); if (free(x, z, 1.3)) addTree('birch', x, z, rr(0.95, 1.2)); }
  /* гілки під деревами */
  var sticks = named(function () { return mdlStick(11); }, 'stick'), sticks2 = named(function () { return mdlStick(23); }, 'stick2');
  TREES.forEach(function (tr) {
    if (tr.kind === 'pine' && RNG() < 0.5) return;
    var c = 1 + Math.floor(RNG() * 2);
    for (var k = 0; k < c; k++) { var a2 = RNG() * TAU, d2 = rr(1.2, 3); var sx = tr.x + Math.cos(a2) * d2, sz = tr.z + Math.sin(a2) * d2; if (inPond(sx, sz, 0.5) || Math.abs(sz) > ZLIM) continue; addNode('stick', RNG() < 0.5 ? 'stick' : 'stick2', RNG() < 0.5 ? sticks : sticks2, sx, sz, RNG() * TAU, 1, 20 * 60); }
  });
  /* стартові гілки й каміння біля появи, щоб не блукати */
  for (i = 0; i < 6; i++) { var a3 = rr(0, TAU), d3 = rr(3, 7); addNode('stick', 'stick', sticks, SPAWN.x + Math.cos(a3) * d3, SPAWN.z + Math.sin(a3) * d3, rr(0, TAU), 1, 20 * 60); }
  /* каміння */
  var stones = [named(function () { return mdlStone(5); }, 'st5'), named(function () { return mdlStone(8); }, 'st8'), named(function () { return mdlStone(13); }, 'st13')];
  function stone(x2, z2) { var v = Math.floor(RNG() * 3); addNode('stone', 'stone' + v, stones[v], x2, z2, RNG() * TAU, rr(0.85, 1.3), 36 * 60); }
  PONDS.forEach(function (p) { for (var k = 0; k < 9; k++) { var a4 = RNG() * TAU, d4 = p.r + rr(1.6, 3.2); stone(p.x + Math.cos(a4) * d4, p.z + Math.sin(a4) * d4); } });
  for (i = 0; i < 5; i++) stone(SPAWN.x + rr(-6, 6), SPAWN.z + rr(-6, 6));
  for (i = 0; i < 70; i++) { x = rr(4, X1 - 4); z = rr(-ZLIM + 1, ZLIM - 1); if (!inPond(x, z, 0.8)) stone(x, z); }
  /* валуни */
  var bould = [named(function () { return mdlStone(31, true); }, 'b31'), named(function () { return mdlStone(37, true); }, 'b37'), named(function () { return mdlStone(41, true); }, 'b41')];
  for (i = 0; i < 26; i++) { tries = 0; do { x = rr(5, X1 - 5); z = rr(-ZLIM + 2, ZLIM - 2); tries++; } while (!free(x, z, 2) && tries < 50); var s2 = rr(0.6, 1.5), v2 = Math.floor(RNG() * 3); place('boulder' + v2, bould[v2], x, H(x, z) - 0.15, z, RNG() * TAU, s2); addCol(x, z, 0.95 * s2); addShadow(x, z, 1.1 * s2); occupied.push([x, z, 1.5 * s2]); for (var q = 0; q < 2; q++) stone(x + rr(-2, 2), z + rr(-2, 2)); }
  /* великий камінь (записка 3) */
  place('boulder0', bould[0], POI.stone.x, H(POI.stone.x, POI.stone.z) - 0.3, POI.stone.z, 0.4, 2.6); addCol(POI.stone.x, POI.stone.z, 2.4); addShadow(POI.stone.x, POI.stone.z, 2.8);
  /* волокно (висока трава) */
  var fib = [named(function () { return mdlFiber(3); }, 'fib3'), named(function () { return mdlFiber(9); }, 'fib9')];
  for (i = 0; i < 120; i++) { tries = 0; do { x = rr(4, X1 - 4); z = rr(-ZLIM + 1, ZLIM - 1); tries++; } while ((inPond(x, z, 0.8) || fbm2(x * 0.06, z * 0.06) < 0.42) && tries < 30); var v3 = Math.floor(RNG() * 2); addNode('fiber', 'fiber' + v3, fib[v3], x, z, RNG() * TAU, rr(0.9, 1.3), 14 * 60); }
  for (i = 0; i < 5; i++) addNode('fiber', 'fiber0', fib[0], SPAWN.x + rr(-8, 8), SPAWN.z + rr(-8, 8), rr(0, 3), 1, 14 * 60);
  /* кущі: ягідні та звичайні */
  var bushes = [named(function () { return mdlBush(5, true); }, 'bb5'), named(function () { return mdlBush(17, false); }, 'bu17'), named(function () { return mdlBush(29, false); }, 'bu29')];
  for (i = 0; i < 95; i++) {
    tries = 0; do { x = rr(4, X1 - 4); z = rr(-ZLIM + 1.5, ZLIM - 1.5); tries++; } while (!free(x, z, 1.2) && tries < 40);
    var berry = RNG() < 0.42, s3 = rr(0.8, 1.3);
    if (berry) {
      var nb = addNode('bush', 'bushB', bushes[0], x, z, RNG() * TAU, s3, 22 * 60);
      for (var b = 0; b < 9; b++) { var ab = RNG() * TAU, bb = rr(0.2, 1.0); nb.extra.push(place('berry', mdlBerry, x + Math.cos(ab) * s3 * 0.75 * Math.cos(bb), nb.y + s3 * 0.45 + Math.sin(bb) * s3 * 0.45, z + Math.sin(ab) * s3 * 0.75 * Math.cos(bb), 0, 1)); }
    } else { var v4 = 1 + Math.floor(RNG() * 2); place('bush' + v4, bushes[v4], x, H(x, z), z, RNG() * TAU, s3); }
    addShadow(x, z, 0.9 * s3); occupied.push([x, z, 1.1 * s3]);
  }
  /* гриби, трави */
  for (i = 0; i < 42; i++) { var tr2 = rpick(TREES), a5 = RNG() * TAU, d5 = rr(1.2, 3.5); x = tr2.x + Math.cos(a5) * d5; z = tr2.z + Math.sin(a5) * d5; if (inPond(x, z, 0.5) || Math.abs(z) > ZLIM) continue; var po = RNG() < 0.38; addNode(po ? 'amanita' : 'mush', po ? 'amanita' : 'mush', po ? named(function () { return mdlMush(true); }, 'am') : named(function () { return mdlMush(false); }, 'mu'), x, z, RNG() * TAU, rr(0.9, 1.4), 26 * 60); }
  for (i = 0; i < 45; i++) { x = rr(4, X1 - 4); z = rr(-ZLIM + 1, ZLIM - 1); if (inPond(x, z, 0.5)) continue; addNode('plantain', 'plantain', mdlPlantain, x, z, RNG() * TAU, rr(1, 1.4), 20 * 60); }
  for (i = 0; i < 40; i++) { x = rr(4, X1 - 4); z = rr(-ZLIM + 1, ZLIM - 1); if (inPond(x, z, 0.5)) continue; addNode('chamomile', 'chamomile', mdlChamomile, x, z, RNG() * TAU, rr(1, 1.3), 20 * 60); }
  for (i = 0; i < 3; i++) addNode('plantain', 'plantain', mdlPlantain, SPAWN.x + rr(-9, 9), SPAWN.z + rr(-9, 9), rr(0, 3), 1.2, 20 * 60);
  /* декор: квіти, очерет */
  var fl = [named(function () { return mdlFlowers(1); }, 'fl1'), named(function () { return mdlFlowers(2); }, 'fl2'), named(function () { return mdlFlowers(3); }, 'fl3')];
  var nfl = Math.floor(260 * (0.4 + Q.grass * 0.6));
  for (i = 0; i < nfl; i++) { x = rr(3, X1 - 3); z = rr(-ZLIM, ZLIM); if (inPond(x, z, 1)) continue; var v5 = Math.floor(RNG() * 3); place('flowers' + v5, fl[v5], x, H(x, z), z, RNG() * TAU, rr(0.8, 1.3)); }
  var reed = [named(function () { return mdlReed(4); }, 'rd4'), named(function () { return mdlReed(7); }, 'rd7')];
  PONDS.forEach(function (p) { for (var k = 0; k < 16; k++) { var a6 = RNG() * TAU, d6 = p.r + rr(-0.6, 1.3); var rx = p.x + Math.cos(a6) * d6, rz = p.z + Math.sin(a6) * d6, v6 = k % 2; place('reed' + v6, reed[v6], rx, H(rx, rz), rz, RNG() * TAU, rr(0.8, 1.2)); } });
}

/* ---------- точки сюжету ---------- */
var STORY_OBJ = {};
function makeNoteTexture(seed) {
  var cv = document.createElement('canvas'); cv.width = 128; cv.height = 128; var c = cv.getContext('2d'), r = mulberry32(seed);
  c.fillStyle = '#efe6c8'; c.fillRect(0, 0, 128, 128); c.fillStyle = 'rgba(120,100,60,0.15)'; for (var i = 0; i < 30; i++) c.fillRect(r() * 128, r() * 128, 6, 6);
  c.strokeStyle = '#3a3a52'; c.lineWidth = 2;
  for (var l = 0; l < 9; l++) { var y = 18 + l * 11; c.beginPath(); c.moveTo(12, y); var xx = 12; while (xx < 110 - r() * 25) { xx += 3 + r() * 6; c.lineTo(xx, y + (r() - 0.5) * 3); } c.stroke(); }
  return cv;
}
var NOTE_TEX = null, NOTE_MESH = null;
function buildPOI() {
  /* стовп із пам'яткою на скріпці */
  var p = POI.post; place('post', mdlPost, p.x, H(p.x, p.z), p.z, SPAWN.yaw, 1); addCol(p.x, p.z, 0.18);
  STORY_OBJ.paperRows = new Float32Array(12);
  STORY_OBJ.note1 = addInter({ kind: 'note', n: 1, x: p.x, y: H(p.x, p.z) + 1.5, z: p.z, r: 1.6 });
  /* старий табір: зруйнований курінь, попелище, рюкзак, записка */
  var c = POI.camp;
  place('shelterBroken', named(function () { return mdlShelter(true); }, 'shb'), c.x, H(c.x, c.z), c.z, 2.6, 1); addCol(c.x - 1.2, c.z, 0.2); addCol(c.x + 1.2, c.z, 0.2);
  place('pitBurnt', named(function () { return mdlFirePit(true); }, 'pb'), c.x + 3, H(c.x + 3, c.z - 2), c.z - 2, 0, 1); addCol(c.x + 3, c.z - 2, 0.55);
  STORY_OBJ.bag = place('bag', mdlBag, c.x + 1.2, H(c.x + 1.2, c.z - 3.5), c.z - 3.5, 0.6, 1);
  STORY_OBJ.bagI = addInter({ kind: 'bag', x: c.x + 1.2, y: H(c.x + 1.2, c.z - 3.5) + 0.3, z: c.z - 3.5, r: 1.2 });
  STORY_OBJ.paper2 = place('paper', mdlPaper, c.x + 4.4, H(c.x + 4.4, c.z - 1.2) + 0.03, c.z - 1.2, 0.3, 1);
  STORY_OBJ.note2 = addInter({ kind: 'note', n: 2, x: c.x + 4.4, y: H(c.x + 4.4, c.z - 1.2) + 0.1, z: c.z - 1.2, r: 1, item: STORY_OBJ.paper2 });
  /* великий камінь */
  var s = POI.stone, nx = s.x - 2.6, nz = s.z + 1.5;
  STORY_OBJ.paper3 = place('paper', mdlPaper, nx, H(nx, nz) + 0.03, nz, 1.1, 1); STORY_OBJ.note3 = addInter({ kind: 'note', n: 3, x: nx, y: H(nx, nz) + 0.1, z: nz, r: 1, item: STORY_OBJ.paper3 });
  /* пляшка на березі */
  var b = POI.bottle; STORY_OBJ.bottle = place('bottle', mdlBottle, b.x, H(b.x, b.z) + 0.02, b.z, 0.8, 1); STORY_OBJ.note4 = addInter({ kind: 'note', n: 4, x: b.x, y: H(b.x, b.z) + 0.1, z: b.z, r: 1, item: STORY_OBJ.bottle, bottle: true });
  /* записка на березі в гаю — прибита до найближчої берези */
  var best = null, bd = 1e9; TREES.forEach(function (tr) { if (tr.kind !== 'birch') return; var d = Math.hypot(tr.x - POI.grove.x, tr.z - POI.grove.z); if (d < bd) { bd = d; best = tr; } });
  if (best) { var px = best.x - 0.22, pz = best.z; STORY_OBJ.paper5 = place('paperUp', named(function () { var g = new GB(); g.box(0, -0.12, 0, 0.006, 0.24, 0.18, [0.92, 0.9, 0.8]); return g.build(); }, 'pu'), px, H(best.x, best.z) + 1.35, pz, 0, 1); STORY_OBJ.note5 = addInter({ kind: 'note', n: 5, x: px - 0.3, y: H(px, pz) + 1.3, z: pz, r: 1.4, item: STORY_OBJ.paper5 }); best.noteTree = true; }
  /* край світу */
  var e = POI.edge; STORY_OBJ.paper6 = place('paper', mdlPaper, e.x, H(e.x, e.z) + 0.03, e.z, 2.1, 1); STORY_OBJ.note6 = addInter({ kind: 'note', n: 6, x: e.x, y: H(e.x, e.z) + 0.1, z: e.z, r: 1, item: STORY_OBJ.paper6 });
  place('boulder1', named(function () { return mdlStone(37, true); }, 'b37'), e.x + 1.5, H(e.x + 1.5, e.z + 1) - 0.1, e.z + 1, 0, 0.55); addCol(e.x + 1.5, e.z + 1, 0.55);
  STORY_OBJ.hatch = addInter({ kind: 'hatch', x: X1 - 0.3, y: 1.3, z: 0, r: 2.4 });
  /* ящик (з'являється в подію 4-го дня) */
  STORY_OBJ.crate = place('crate', mdlCrate, 0, -50, 0, 0, 1); STORY_OBJ.crate.hid = true;
  STORY_OBJ.crateI = addInter({ kind: 'crate', x: 0, y: 0, z: 0, r: 1.4, on: false });
  /* текстура записки для стовпа */
  NOTE_TEX = texFromCanvas(makeNoteTexture(5));
  var g = new GB(); g.useUV = true;
  g.tri([-0.17, -0.22, 0], [0.17, -0.22, 0], [0.17, 0.22, 0], [1, 1, 1], null, null, 0, 0, 0, [0, 1], [1, 1], [1, 0]);
  g.tri([-0.17, -0.22, 0], [0.17, 0.22, 0], [-0.17, 0.22, 0], [1, 1, 1], null, null, 0, 0, 0, [0, 1], [1, 0], [0, 0]);
  NOTE_MESH = g.build(); NOTE_MESH.cull = false;
  mat34(STORY_OBJ.paperRows, 0, p.x + Math.sin(SPAWN.yaw) * 0.1, H(p.x, p.z) + 1.45, p.z + Math.cos(SPAWN.yaw) * 0.1, SPAWN.yaw, 1, 1, 1, 0, 0, 1);
}

/* ---------- споруди гравця ---------- */
var FIRES = [], SHELTERS = [], SNARES = [];
var M_FIRELAY = null, M_PIT = null, M_ASH = null, M_SHELTER = null, M_SNARE = null, M_SNARE_C = null;
function addFire(x, z, st, fuel) {
  var f = { x: x, z: z, y: H(x, z), st: st || 'lay', fuel: fuel || 0, coal: false, cook: null, rows: new Float32Array(12), light: 0, flick: 0 };
  mat34(f.rows, 0, x, f.y, z, RNG() * TAU, 1, 1, 1, 0, 0, 1);
  f.col = addCol(x, z, 0.55); f.inter = addInter({ kind: 'fire', ref: f, x: x, y: f.y + 0.3, z: z, r: 1.5 });
  FIRES.push(f); return f;
}
function addShelter(x, z, ry) {
  var s = { x: x, z: z, ry: ry, y: H(x, z), rows: new Float32Array(12) }; mat34(s.rows, 0, x, s.y, z, ry, 1, 1, 1, 0, 0, 1);
  var c = Math.cos(ry), sn = Math.sin(ry);
  s.cols = [addCol(x - c * 1.3, z + sn * 1.3, 0.15), addCol(x + c * 1.3, z - sn * 1.3, 0.15)];
  s.inter = addInter({ kind: 'shelter', ref: s, x: x + sn * 1.1, y: s.y + 0.8, z: z + c * 1.1, r: 1.8 });
  SHELTERS.push(s); return s;
}
function underRoof(x, z) {
  for (var i = 0; i < SHELTERS.length; i++) { var s = SHELTERS[i], dx = x - s.x, dz = z - s.z, c = Math.cos(s.ry), sn = Math.sin(s.ry); var lx = dx * c - dz * sn, lz = dx * sn + dz * c; if (Math.abs(lx) < 1.35 && lz > -0.2 && lz < 2.1) return s; }
  return null;
}
function addSnare(x, z, ry, uses) {
  var s = { x: x, z: z, y: H(x, z), ry: ry, set: G.tot, caught: false, uses: uses || 3, rows: new Float32Array(12) }; mat34(s.rows, 0, x, s.y, z, ry, 1, 1, 1, 0, 0, 1);
  s.inter = addInter({ kind: 'snare', ref: s, x: x, y: s.y + 0.2, z: z, r: 1.1 }); SNARES.push(s); return s;
}
function removeInter(o) { o.on = false; var i = INTER.indexOf(o); if (i >= 0) INTER.splice(i, 1); }
function nearTree(x, z, r) { for (var i = 0; i < TREES.length; i++) { var tr = TREES[i]; if (tr.st === 0 && Math.hypot(tr.x - x, tr.z - z) < r) return tr; } return null; }
